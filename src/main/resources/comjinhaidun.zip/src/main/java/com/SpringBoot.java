package com;


import com.senpure.base.util.BannerShow;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@SpringBootApplication
@RestController
public class SpringBoot implements ApplicationContextAware,BeanNameAware{
    protected static Logger LOG = LogManager.getLogger(SpringBoot.class);
    private static AbstractApplicationContext act;
    private static DefaultListableBeanFactory defaultListableBeanFactory;

    @RequestMapping("/test")
    public String home() {

        return "hello world !";

    }

    public static void main(String[] args) {
        //Ansi.setEnabled(true);
        AnsiConsole.systemInstall();
        AnsiConsole.systemUninstall();
        SpringApplication application = new SpringApplication(SpringBoot.class);
        application.setBannerMode(Banner.Mode.LOG);
        application.run(args);
        BannerShow.show();


    }

    @Override
    public void setApplicationContext(ApplicationContext context) throws BeansException {

        LOG.info("Spring 获取ApplicationContext上下文:applicationName:" + context.getApplicationName() + ",displayName:" + context.getDisplayName() + ",id:" + context.getId());
        act = (AbstractApplicationContext) context;
        defaultListableBeanFactory = (DefaultListableBeanFactory) context.getAutowireCapableBeanFactory();

    }

    public static void regSingleBean(String name, Object bean) {


        act.getBeanFactory().registerSingleton(name, bean);

    }

    public static void removeBean(String beanName) {

        defaultListableBeanFactory.removeBeanDefinition(beanName);
    }

    public static <T> T getBean(Class<T> type) {


        return act.getBean(type);
    }

    public static Object getBean(String name) {

        return act.getBean(name);
    }

    public static <T> Map<String, T> getBeansOfType(Class<T> type) {

        return act.getBeansOfType(type);
    }


    @Override
    public void setBeanName(String s) {

    }
}