package com.jinhaidun;


import com.senpure.base.util.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class AppContext {

    private static Logger log = LogManager.getLogger(AppContext.class);

    /**
     * class 所在包的根绝对路径<br>
     * 如 /class 或/bin
     *
     * @return str
     */
    public static String getClassRootPath() {
        String classRootPath = null;
        try {

            //URL url=AppContext.class.getClassLoader().getResource("");
            URL url = AppContext.class.getResource("");
            log.debug("url{}", url);
            URI uri = url.toURI();
            log.debug("uri{}", uri);
            classRootPath = uri.getPath();
            if (classRootPath == null) {
                Assert.error("jar can not call this method");
                classRootPath = uri.toString();
            }
            log.debug("classrootPath {}", classRootPath);
            if (isWindowsOS()) {
                int index = classRootPath.indexOf("/");
                if (index == 0) {
                    classRootPath = classRootPath.substring(1);
                }
            }
            classRootPath = classRootPath.replace("/", File.separator);
            String packpath = AppContext.class.getPackage().getName();
            packpath = packpath.replace(".", File.separator);
            classRootPath = classRootPath.replace(packpath, "");
            while (classRootPath.charAt(classRootPath.length() - 1) == File.separatorChar) {
                classRootPath = classRootPath.substring(0, classRootPath.length() - 1);
            }
            log.info("classRootPath {}", classRootPath);
        } catch (URISyntaxException e) {


            log.error("", e);
        }

        return classRootPath;
    }

    public static String getRootPath() {
        return AppContext.class.getProtectionDomain().getCodeSource().getLocation().getPath();
    }

    public static boolean isWindowsOS() {

        String os = System.getProperty("os.name").toLowerCase();

        return os.contains("windows");
    }

    public static  boolean inJar()
    {
        return  false;
    }
    public static void main(String[] args) {
        ;

        System.out.println(AppContext.getClassRootPath());
        System.out.println(getRootPath());
        File file = new File("E:\\projects\\comjinhaidun\\target\\classes", "showbanner.txt");
        System.out.println(file.exists());
    }
}
