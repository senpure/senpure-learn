package com.jinhaidun.mahjong;

import com.jinhaidun.mahjong.struct.Tile;

import java.util.List;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public interface Mahjong {

    /**
     * 摸一张牌
     * @return
     */
    Tile getTile();
    List<Tile> getTiles(int count);
    List<Tile> currentTiles();
    /**
     * 洗牌
     */
    void shuffle();
    void nextTime();

}
