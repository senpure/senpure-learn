package com.jinhaidun.mahjong.controller;

import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.io.ChannelUtil;
import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.logic.RoomManager;
import com.jinhaidun.mahjong.struct.Assign;
import com.jinhaidun.mahjong.util.TileUtil;
import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.result.ResultHelper;
import com.senpure.base.result.ResultMap;
import com.senpure.base.spring.BaseController;
import io.netty.channel.Channel;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

/**
 * Created by 罗中正 on 2017/4/21.
 */
@Controller
@RequestMapping("/mahjong")
public class AssignController extends BaseController {


    @RequestMapping(value = "/assign",method = RequestMethod.GET)
    public ModelAndView assign(HttpServletRequest request) {

        return view(request,"game/assign");
    }

    @RequestMapping(value = "/assign",method = RequestMethod.POST)
    @PermissionVerify("麻将调试")
    @MenuGenerator(id = 41,parentId = 20,text = "麻将调试",icon = "glyphicon glyphicon-link faa-float")
    @ResponseBody
    public Object assign(HttpServletRequest request, int playerId, int mahjongValue) {
        logger.debug("{} 下一张牌想要获取{}", playerId, TileUtil.getTile(mahjongValue));
        ResultMap resultMap = ResultMap.getDimResult();
        Channel channel = ChannelUtil.getChannel(playerId);
        if (channel != null) {
            Integer roomId = ChannelAttributeUtil.getRoomId(channel);
            if (roomId != null) {
                GameRoom room = RoomManager.getRoom(roomId);
                if (room != null) {
                    Assign assign = new Assign();
                    assign.playerId = playerId;
                    assign.mahjongValue = mahjongValue;
                    room.assgin(assign);
                    resultMap = ResultMap.getSuccessResult()
                            .put("message", "SUCCESS")
                            .put("mahjong", TileUtil.getTile(mahjongValue).toString())
                    ;
                }
            }


        }
        ResultHelper.wrapMessage(resultMap, Locale.CHINESE);
        return resultMap
                ;
    }

    @RequestMapping("/assign2")
    @ResponseBody
    public Object assign2(HttpServletRequest request, @RequestParam("playerId") int playerId, @RequestParam("mahjongValue") int mahjongValue) {
        logger.debug("{} 下一张牌想要获取{}", playerId, TileUtil.getTile(mahjongValue));
        ResultMap resultMap = ResultMap.getDimResult();
        ResultHelper.wrapMessage(resultMap, Locale.CHINESE);
        return resultMap
                ;
    }
    @RequestMapping("/assign3")
    @ResponseBody
    public Object assign3(HttpServletRequest request) {
        logger.debug("{} 下一张牌想要获取{}", request.getParameter("playerId"));
        ResultMap resultMap = ResultMap.getDimResult();
        ResultHelper.wrapMessage(resultMap, Locale.CHINESE);
        return resultMap
                ;
    }
}
