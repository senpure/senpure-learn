package com.jinhaidun.mahjong.controller;

import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 罗中正 on 2017/6/22.
 */
@Controller

@RequestMapping("/mahjong")
public class GameToolsController  extends BaseController{

    @MenuGenerator(id = 42,parentId = 20,text = "游戏工具",icon = "glyphicon glyphicon-wrench faa-float")
    @RequestMapping("/tools")
    @PermissionVerify("进入游戏工具页面")
    public ModelAndView gameTools(HttpServletRequest request)
    {

        return success(request, "game/tools");
    }
}
