package com.jinhaidun.mahjong.controller;

import com.jinhaidun.mahjong.logic.Config;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 罗中正 on 2017/6/22.
 */
@Controller
@RequestMapping("/mahjong")
public class RoomController extends BaseController {


    @RequestMapping(value = "/roomClose", method = RequestMethod.POST)
    @PermissionVerify("关闭创建房间")
    public ModelAndView closeRoom(HttpServletRequest request) {
        Config.setOpenRoom(false);

        return success(request, "game/tools");
    }

    @RequestMapping(value = "/roomOpen", method = RequestMethod.POST)
    @PermissionVerify("开启创建房间")
    public ModelAndView openRoom(HttpServletRequest request) {
        Config.setOpenRoom(true);

        return success(request, "game/tools");
    }
}
