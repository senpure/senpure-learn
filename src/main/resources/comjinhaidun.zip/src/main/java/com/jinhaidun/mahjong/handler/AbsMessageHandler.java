package com.jinhaidun.mahjong.handler;


import com.google.protobuf.MessageOrBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.ResolvableType;

/**
 * 采用约定的方式 ，消息名等于类全名
 * Created by admin on 2017/3/30.
 *
 */

public abstract class AbsMessageHandler<T extends MessageOrBuilder>  implements InitializingBean ,MessageHandler<T>{

    protected Logger log;
    protected Class messageClass;


    public AbsMessageHandler() {
        log= LogManager.getLogger(getClass());
        ResolvableType resolvableType = ResolvableType.forClass(getClass());
        messageClass = resolvableType.getSuperType().getGeneric(0).resolve();
    }

    @Override
    public String getMessageName() {

        return messageClass.getSimpleName().toUpperCase();
    }


    public T getMessage(T  message) {

       // Descriptors.FieldDescriptor fieldDescriptor=msgAndID.getAllFields().keySet().iterator().next();
       // System.out.println(  fieldDescriptor.getName()+"llll");
        return (T) message.getAllFields().values().iterator().next();
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        MessageHandlerUtil.regMessageHandler(this);
    }

    public static void main(String[] args) {

    }
}
