package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.struct.Seat;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/21.
 */
@Component
public class MessageChatHandler extends SeatHandler<PokerMsgCs.CSRequestChat> {


    @Override
    public void execute(Message data, PokerMsgCs.CSRequestChat message, Seat seat, GameRoom room) {

        room.chat(seat, message);
    }
}
