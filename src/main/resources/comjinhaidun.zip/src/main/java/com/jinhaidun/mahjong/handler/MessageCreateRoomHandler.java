package com.jinhaidun.mahjong.handler;

import com.SpringBoot;
import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.logic.Config;
import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.logic.RoomManager;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerCommon;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.service.DataService;
import com.jinhaidun.mahjong.struct.RoomConfig;
import com.senpure.base.util.RandomUtil;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/6.
 */
@Component
public class MessageCreateRoomHandler extends AbsMessageHandler<PokerMsgCs.CSRequestCreateTable> {

    @Autowired
    private DataService dataService;

    @Override
    public void execute(ChannelHandlerContext ctx, Message data, PokerMsgCs.CSRequestCreateTable message) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(ctx.channel());
        if (playerId == null) {
            log.error("玩家 未登陆 ");
            return;
        }

        if(!Config.isOpenRoom())
        {
            log.error("服务器关闭开启房间功能");
        }
        RoomConfig config = new RoomConfig();
        config.panshu = message.getRound() * 4;
        config.createrId = playerId;
        config.roomId = playerId;
        config.limit = message.getScoreLimit();
        config.meng = message.getMeng();
        config.round = message.getRound();

        if (config.meng == 0) {
            config.meng = message.getJokerNum();
        }

        int dimond = getDaimond(config.round);
        int pdiamond = dataService.playerDiamond(playerId);
        if (dimond == 0 || dimond > pdiamond) {
            log.warn(" 玩家钻石不足 需要{} ，拥有 {}",dimond,pdiamond);
            PokerMsgCs.CSResponseCreateTable returnMessage = PokerMsgCs.CSResponseCreateTable.newBuilder().
                    setResult(PokerCommon.ENMessageError.EN_MESSAGE_INVALID_ACTION)
                    .setTid(config.roomId).build();
            Message m = MessageUtil.getMessage(data).putMessage(MessageUtil.getMessageBuilder().
                    setCsResponseCreateTable(returnMessage).build());
            ctx.writeAndFlush(m);
            return;
        }

        config.diamond = dimond;
        int roomId = RoomManager.getRoomId();
        config.roomId = roomId;
        GameRoom game = SpringBoot.getBean(GameRoom.class);
        game.init(config);
        RoomManager.addRoom(game);
        PokerMsgCs.CSResponseCreateTable returnMessage = PokerMsgCs.CSResponseCreateTable.newBuilder().
                setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK)
                .setTid(config.roomId).build();
        Message m = MessageUtil.getMessage(data).putMessage(MessageUtil.getMessageBuilder().
                setCsResponseCreateTable(returnMessage).build());
        ctx.writeAndFlush(m);

    }

    private int getDaimond(int round) {
        switch (round) {
            case 1:
                return 2;
            case 2:
                return 3;
            case 4:
                return 5;

            default:
                return 0;
        }
    }

    public static void main(String[] args) {

        int roomId = 0;
        do {
            roomId = RandomUtil.random(600000, 1000000);
            System.out.println(roomId);
        }
        while (RoomManager.getRoom(roomId) != null);
    }
}
