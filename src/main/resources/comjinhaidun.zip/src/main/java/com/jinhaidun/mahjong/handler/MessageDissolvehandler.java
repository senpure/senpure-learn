package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.struct.Seat;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/25.
 */
@Component
public class MessageDissolvehandler extends  SeatHandler<PokerMsgCs.CSRequestDissolveTable> {
    @Override
    public void execute(Message data, PokerMsgCs.CSRequestDissolveTable message, Seat seat, GameRoom room) {

        room.dissolveRoom(seat,message.getChoice());
    }
}
