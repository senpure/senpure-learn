package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerCommon;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.struct.Seat;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/19.
 */
@Component
public class MessageDoActionHandler extends SeatHandler<PokerMsgCs.CSRequestDoAction> {
    @Override
    public void execute(Message data, PokerMsgCs.CSRequestDoAction message, Seat seat, GameRoom room) {
        int value = 0;

        if (message.getTilesCount() > 0) {
            value = message.getTiles(0);
        }


        switch (message.getAtype()) {
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_CHUPAI_VALUE:
                room.chuPai(seat, value);
                break;

            case PokerCommon.ENMJActionType.EN_MJ_ACTION_PASS_VALUE:
                room.pass(seat, value, message.getToken());
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_HUPAI_VALUE:
                room.huPai(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_ANGANG_VALUE:
                room.anGang(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_JIA_GANG_VALUE:
                room.jiaGang(seat, value);
                break;

            case PokerCommon.ENMJActionType.EN_MJ_ACTION_SI_XI_FENG_VALUE:
                room.feng(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_SAN_ZHI_JIAN_VALUE:
                room.jian(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_HUI_ER_PI_AN_GANG_VALUE:

                room.anHuierPi(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_GANG_VALUE:
                room.mingGang(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_PENGGANG_VALUE:
                room.pengGang(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_PENG_VALUE:
                room.peng(seat, value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_HUI_ER_PI_MING_GANG_VALUE
                    :
                room.huierpigang(seat, value);
                break;
        }

    }
}
