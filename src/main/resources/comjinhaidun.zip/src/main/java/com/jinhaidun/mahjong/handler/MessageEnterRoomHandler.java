package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.logic.MsgManager;
import com.jinhaidun.mahjong.logic.RoomManager;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerCommon;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/6.
 */
@Component
public class MessageEnterRoomHandler extends AbsMessageHandler<PokerMsgCs.CSRequestEnterTable> {
    @Override
    public void execute(ChannelHandlerContext ctx, Message data, PokerMsgCs.CSRequestEnterTable message) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(ctx.channel());
        if (playerId == null) {
            log.error("玩家 未登陆 ");
            return;
        }
        int roomId = Long.valueOf(message.getTid()).intValue();
        GameRoom room = RoomManager.getRoom(roomId);
        if (room == null) {
            log.warn("{} 房间不存在", roomId);
            MessageWraper messageWraper = MessageUtil.getMessage(data);
            PokerMsgCs.CSResponseEnterTable resET = PokerMsgCs.CSResponseEnterTable.newBuilder().
                    setResult(PokerCommon.ENMessageError.EN_MESSAGE_DB_NOT_FOUND).build();
            messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsResponseEnterTable(resET).build());
            MsgManager.sendMessage(playerId, messageWraper);
            return;
        }
        //ChannelAttributeUtil.setRoomId(ctx.channel(),roomId);
        room.playerEnterRoom( data, message, playerId);
    }
}
