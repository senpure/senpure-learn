package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.struct.Seat;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/5/3.
 */
@Component
public class MessageExitHandler extends SeatHandler<PokerMsgCs.CSRequestExitTable> {

    @Override
    public void execute(Message data, PokerMsgCs.CSRequestExitTable message, Seat seat, GameRoom room) {
        room.exitRoom(seat);
    }
}
