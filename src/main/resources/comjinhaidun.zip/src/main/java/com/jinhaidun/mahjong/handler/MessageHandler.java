package com.jinhaidun.mahjong.handler;


import com.google.protobuf.MessageOrBuilder;
import com.jinhaidun.mahjong.msg.Message;
import io.netty.channel.ChannelHandlerContext;

/**
 * Created by admin on 2017/3/30.
 */
public interface MessageHandler<T extends MessageOrBuilder> {

    public  abstract  String getMessageName();
    public  abstract  T getMessage(T message);
    public  abstract  void  execute(ChannelHandlerContext ctx, Message data, T message);


}
