package com.jinhaidun.mahjong.handler;


import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsg;
import com.senpure.base.util.Assert;
import io.netty.channel.ChannelHandlerContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by admin on 2017/3/30.
 */
public class MessageHandlerUtil {
    protected static Logger log = LogManager.getLogger(MessageHandlerUtil.class);
    private static Map<String, MessageHandler> handlerMap = new HashMap<String, MessageHandler>();
    private static ExecutorService service = Executors.newCachedThreadPool();
    public static void execute(final ChannelHandlerContext ctx, Message message) {
        PokerMsg.PBCSMsg msgAndID = message.getMessage();
        String msgName = msgAndID.getMsgUnionCase().name();
        final MessageHandler handler = handlerMap.get(msgName.replaceAll("_", ""));
      //  log.debug(msgAndID.getAllFields());
        if (handler == null) {
            log.warn("没有找到消息处理程序 {} --- {}", msgAndID.getMsgUnionCase().getNumber(), msgAndID.getMsgUnionCase().name());
            return;
        }
        service.execute(() -> handler.execute(ctx, message, handler.getMessage(msgAndID)));

    }

    public static void regMessageHandler(MessageHandler handler) {

        Assert.notNull(handler.getMessageName(), "消息名不能为空。");
        Assert.isNull(handlerMap.get(handler.getMessageName()), handler.getMessageName() + "  处理程序已经存在");

        handlerMap.put(handler.getMessageName(), handler);
    }
}
