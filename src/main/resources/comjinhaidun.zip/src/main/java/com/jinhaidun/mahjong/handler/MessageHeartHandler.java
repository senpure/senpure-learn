package com.jinhaidun.mahjong.handler;


import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/18.
 */
@Component
public class MessageHeartHandler extends AbsMessageHandler<PokerMsgCs.CSRequestHeartBeat> {

    @Override
    public void execute(ChannelHandlerContext ctx, Message data, PokerMsgCs.CSRequestHeartBeat message) {

        MessageWraper messageWraper = MessageUtil.getMessage(data);
        PokerMsgCs.CSResponseHeartBeat heartBeat = PokerMsgCs.CSResponseHeartBeat.newBuilder().setTime((int) (System.currentTimeMillis() / 1000)).build();
        messageWraper.putMessage(MessageUtil.getMessageBuilder()
                .setCsResponseHeartBeat(heartBeat).build());
        ctx.writeAndFlush(messageWraper);
    }
}
