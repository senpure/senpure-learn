package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.struct.Seat;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/25.
 */
@Component
public class MessageInteractiveHandler extends SeatHandler<PokerMsgCs.CSRequestSendInteractiveProp> {
    @Override
    public void execute(Message data, PokerMsgCs.CSRequestSendInteractiveProp message, Seat seat, GameRoom room) {

        room.interactiveProp(seat, message);
    }
}
