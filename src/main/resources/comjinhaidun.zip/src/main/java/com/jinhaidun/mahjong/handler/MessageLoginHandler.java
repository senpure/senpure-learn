package com.jinhaidun.mahjong.handler;


import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.io.ChannelUtil;
import com.jinhaidun.mahjong.io.OffLineHandler;
import com.jinhaidun.mahjong.io.OffLineListener;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerCommon;
import com.jinhaidun.mahjong.msg.PokerData;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.service.DataService;
import com.jinhaidun.mahjong.struct.Player;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Component
public class MessageLoginHandler extends AbsMessageHandler<PokerMsgCs.CSRequestLogin> implements OffLineListener {

    private static ChannelGroup loginChannel = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);


    static {

        ChannelUtil.setLoginChannelGroup(loginChannel);
    }

    @Autowired
    private DataService dataService;
    private int playerIdCount = 100000;
    private static Map<Integer, Player> players = new HashMap<>();
    //多个地方登陆
    private static Map<Integer, Player> mulitPlayers = new HashMap<>();

    public static Player getPlayer(int playerId) {
        return players.get(playerId);
    }


    public void execute(ChannelHandlerContext ctx, Message data, PokerMsgCs.CSRequestLogin message) {
        Map<String, Object> context = new HashMap<>();
        Player player = dataService.playerLogin(message.getToken(), context);
        if (player == null) {
            PokerMsgCs.CSResponseLogin login = PokerMsgCs.CSResponseLogin.newBuilder().
                    setResult(PokerCommon.ENMessageError.EN_MESSAGE_INVALID_ACC_TOKEN).
                    build();
            Message returnMessage = MessageUtil.getMessage(data).putMessage(MessageUtil.getMessageBuilder().setCsResponseLogin(login).build());
            ctx.writeAndFlush(returnMessage);
            return;
        }


        Integer playerId = player.id;
        Channel oldChannel = ChannelUtil.getChannel(playerId);
        InetSocketAddress insocket = (InetSocketAddress) ctx.channel()
                .remoteAddress();
        if (oldChannel != null && !oldChannel.equals(ctx.channel())) {
            log.debug(oldChannel + "被挤下线,new channel  " + ctx.channel());
            mulitPlayers.put(player.id, player);
            String ip = insocket.getHostName();
            // MessageWraper mw = MessageHelper.buildPushMessage(AUTHORIZE_OTHER).appendData("ip",
            //         insocket.getHostName());
            // oldChannel.writeAndFlush(MessageHelper.ToBinaryWebSocketFrame(mw));
            oldChannel.close();

        }
        players.put(player.id, player);
        // log.info("玩家信息:" + user.getIdBgt() + ",chip:" + user.getChipAmount());
        Integer lastPlayerId = ChannelAttributeUtil.getPlayerId(ctx);
        if (lastPlayerId != null && lastPlayerId.longValue() != playerId.longValue()) {
            log.info("没有断开连接，切换账号，模拟掉线完成处理" + lastPlayerId + " >> " + playerId);
            try {
                ChannelAttributeUtil.getOfflineHandler(ctx.channel()).offLineExecute(ctx);
            } catch (Exception e) {
                log.error(e);
            }
        }
        if (lastPlayerId != null) {
            log.warn("{}重复登录 ", lastPlayerId);
            //重复登录
        } else {
            ChannelAttributeUtil.setPlayerId(ctx, playerId);
            ChannelUtil.addLoginCahnnel(ctx.channel());
            ChannelUtil.setChannel(playerId, ctx.channel());
            OffLineHandler.regChannelOffLineListener(ctx.channel(), this);
        }

        log.debug("player nick {}",player.nick);
        PokerData.PBUser.Builder userBuilder = PokerData.PBUser.newBuilder();
        userBuilder.
                setUid(playerId).
                setAccType(message.getAccType())
                .setNick(player.nick)
                .setCreateTableId(player.roomId)
                .setGender(PokerCommon.ENGender.EN_Gender_Male_VALUE)
                .setChips(player.diamond)
                .setPicUrl(player.head);
        if (player.roomId > 0) {
            userBuilder.setPos(PokerData.PBBPlayerPositionInfo.newBuilder().
                    setPosType(PokerCommon.ENPlayerPositionType.EN_Position_Table)
                    .setTableId(player.roomId));
        } else {
            userBuilder.setPos(PokerData.PBBPlayerPositionInfo.newBuilder().
                    setPosType(PokerCommon.ENPlayerPositionType.EN_Position_Hall).build());
        }
        PokerData.PBUser pbUser = userBuilder.build();
        PokerMsgCs.CSResponseLogin login = PokerMsgCs.CSResponseLogin.newBuilder().
                setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK).
                setHeartBeatInterval(200)
                .setUseHeartBeat(true)
                .setIsCreated(true).
                        setUser(pbUser).
                        build();
        Message returnMessage = MessageUtil.getMessage(data).putMessage(MessageUtil.getMessageBuilder().setCsResponseLogin(login).build());
        ctx.writeAndFlush(returnMessage);


    }

    @Override
    public void executeOffLine(ChannelHandlerContext ctx) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(ctx);
        log.debug(ctx.channel() + ",断开连接，playerId is {}", playerId);
        if (playerId != null) {
            Player mplayer = mulitPlayers.remove(playerId);
            if (mplayer == null) {
                ChannelUtil.removeChannel(playerId);
                players.remove(playerId);
            }


        }
    }

    @Override
    public String getOffLineListenerName() {
        return "关联Channel掉线监听程序";
    }


    public static void main(String[] args) {


    }
}
