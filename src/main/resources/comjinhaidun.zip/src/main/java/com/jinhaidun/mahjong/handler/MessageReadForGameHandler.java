package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.struct.Seat;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/4/18.
 */
@Component
public class MessageReadForGameHandler extends SeatHandler<PokerMsgCs.CSRequestReadyForGame> {

    @Override
    public void execute(Message data, PokerMsgCs.CSRequestReadyForGame message, Seat seat, GameRoom room) {

        room.readyForGame(data,message,seat);
    }
}
