package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerData;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.service.DataService;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by 罗中正 on 2017/5/31.
 */
@Component
public class MessageUserRecordHandler extends AbsMessageHandler<PokerMsgCs.CSRequestUserRecord> {
    @Autowired
    private DataService dataService;
    @Override
    public void execute(ChannelHandlerContext ctx, Message data, PokerMsgCs.CSRequestUserRecord message) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(ctx.channel());
        if (playerId == null) {
            log.error("玩家 未登陆 ");
            return;
        }
        List<PokerData.PBGameRecord> records =dataService.loadGameRecord(playerId);
        PokerMsgCs.CSResponseUserRecord responseUserRecord=PokerMsgCs.CSResponseUserRecord.newBuilder()
                .addAllRecords(records).build();
       MessageWraper mw= MessageUtil.getMessage(data).putMessage(MessageUtil.getMessageBuilder().
               setCsResponseUserRecord(responseUserRecord).build());

        ctx.writeAndFlush(mw);
    }
}
