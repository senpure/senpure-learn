package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsg;

/**
 * Created by 罗中正 on 2017/4/6.
 */
public class MessageUtil {


    public static  MessageWraper getMessage(Message refer){

        MessageWraper message=new MessageWraper();
        message.setHead(refer.getHead());
        return  message;

    }
    public static  MessageWraper getMessage(){

        MessageWraper message=new MessageWraper();
        PokerMsg.PBHead head=PokerMsg.PBHead.getDefaultInstance();
        message.setHead(head);
        return  message;

    }
    public  static  PokerMsg.PBCSMsg.Builder getMessageBuilder()
    {
       return   PokerMsg.PBCSMsg.newBuilder();
    }

}
