package com.jinhaidun.mahjong.handler;

import com.google.protobuf.InvalidProtocolBufferException;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerData;
import com.jinhaidun.mahjong.msg.PokerMsgBasic;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.service.DataService;
import com.jinhaidun.mahjong.struct.Video;
import com.jinhaidun.mahjong.util.DataUtil;
import io.netty.channel.ChannelHandlerContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/6/6.
 */
@Component
public class MessageVideoHandler extends AbsMessageHandler<PokerMsgCs.CSRequestOneRecord> {
    @Autowired
private DataService dataService;

    @Override
    public void execute(ChannelHandlerContext ctx, Message data, PokerMsgCs.CSRequestOneRecord message) {


        log.debug("进入获取回放数据");
        Video video = dataService.loadVideo(Long.parseLong(message.getRecordid()), message.getRoundIndex());

        if(video==null)
        {
            log.warn("没有找到回放数据 {},{}",message.getRecordid(),message.getRoundIndex());
        }
        log.debug(video);
        try {
            PokerMsgCs.CSNotifyGameStart start = PokerMsgCs.CSNotifyGameStart.parseFrom(DataUtil.str2Byte(video.getStart()));
            PokerMsgCs.CSNotifyGameOver gameOver=PokerMsgCs.CSNotifyGameOver.parseFrom(DataUtil.str2Byte(video.getOver()));
            PokerData.PBTableConfig config=PokerData.PBTableConfig.parseFrom(DataUtil.str2Byte(video.getConfig()));
            List<PokerMsgBasic.PBMJAction> actions = new ArrayList<>();
            for (String str : video.getActions()) {
                PokerMsgBasic.PBMJAction action= PokerMsgBasic.PBMJAction.parseFrom(DataUtil.str2Byte(str));
                actions.add(action);
            }
            PokerMsgCs.CSResponseOneRecord record = PokerMsgCs.CSResponseOneRecord.newBuilder()
                    .addAllActions(actions)
                    .setConfig(config)
                    .setGameStart(start)
                    .setGameOver(gameOver)
                    .build();
            MessageWraper mw = MessageUtil.getMessage(data).
                    putMessage(MessageUtil.getMessageBuilder().setCsResponseOneRecord(record).build());
            ctx.writeAndFlush(mw);
        } catch (InvalidProtocolBufferException e) {
            log.error("获取回放数据出错",e);
        }
    }
}
