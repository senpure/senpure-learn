package com.jinhaidun.mahjong.handler;

import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsg;

/**
 * Created by 罗中正 on 2017/4/6.
 */
public class MessageWraper extends Message {

    public  MessageWraper putMessage(PokerMsg.PBCSMsg message) {
        super.setMessage(message);
        return this;
  }
}
