package com.jinhaidun.mahjong.handler;

import com.google.protobuf.MessageOrBuilder;
import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.io.ChannelUtil;
import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.logic.RoomManager;
import com.jinhaidun.mahjong.msg.Message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public abstract class RoomHandler<T extends MessageOrBuilder> extends AbsMessageHandler<T> {
    private static ChannelGroup roomChannel = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    static {

        ChannelUtil.setRoomChannelGroup(roomChannel);
    }

    @Override
    public void execute(ChannelHandlerContext ctx, Message data, T message) {

        Integer playerId = ChannelAttributeUtil.getPlayerId(ctx.channel());
        if (playerId == null) {
            log.error("玩家 未登陆 ");
            return;
        }
        Integer roomId = ChannelAttributeUtil.getRoomId(ctx.channel());
        if (roomId == null) {
            log.error("玩家{} 未进入房间 ", ChannelAttributeUtil.getPlayerId(ctx));
            return;
        }
       GameRoom room = RoomManager.getRoom(roomId);
        if (room == null) {
            log.warn("房间{}不存在 ", roomId);
            //TODO 房间错误
            return;
        }

        execute(ctx, data, message, playerId, room);
    }

    public abstract void execute(ChannelHandlerContext ctx, Message data, T message, Integer playerId, GameRoom room);
}
