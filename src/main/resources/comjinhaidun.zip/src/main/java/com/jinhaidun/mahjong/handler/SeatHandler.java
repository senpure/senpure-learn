package com.jinhaidun.mahjong.handler;

import com.google.protobuf.MessageOrBuilder;
import com.jinhaidun.mahjong.logic.GameRoom;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.struct.Seat;
import io.netty.channel.ChannelHandlerContext;

/**
 * Created by 罗中正 on 2017/4/18.
 */
public abstract class SeatHandler<T extends MessageOrBuilder> extends RoomHandler<T> {

    @Override
    public void execute(ChannelHandlerContext ctx, Message data, T message, Integer playerId, GameRoom room) {

        Seat sit = null;
        for (Seat seat : room.seats) {
            if (seat.player != null && seat.player.id == playerId) {
                sit = seat;
                break;
            }
        }
        if (sit == null) {
            log.error("玩家{} 没有座位 ", playerId);
            return;
        }
        execute(data,message,sit,room);
    }

    public abstract void execute(Message data, T message, Seat seat, GameRoom room);

}
