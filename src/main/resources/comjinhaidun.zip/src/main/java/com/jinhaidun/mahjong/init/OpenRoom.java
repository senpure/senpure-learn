package com.jinhaidun.mahjong.init;

import com.jinhaidun.mahjong.logic.Config;
import com.senpure.base.spring.SpringContextRefreshEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/6/22.
 */
@Component
@Order(100)
public class OpenRoom extends SpringContextRefreshEvent {
    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
       logger.info("打开创建房间的功能");
        Config.setOpenRoom(true);
    }
}
