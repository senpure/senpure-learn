package com.jinhaidun.mahjong.io;

import com.google.protobuf.MessageLite;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsg;
import com.senpure.base.util.Assert;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * Created by 罗中正 on 2017/4/6.
 */
public class ByteBufToMessageDecoder extends ByteToMessageDecoder {
    protected Logger log = LogManager.getLogger(ByteBufToMessageDecoder.class);
    private final MessageLite head = PokerMsg.PBHead.getDefaultInstance();

    private final MessageLite content = PokerMsg.PBCSMsg.getDefaultInstance();

    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, ByteBuf in, List<Object> out) throws Exception {


        in.markReaderIndex();
        int packageLength = in.readInt();
       // log.debug("package长度:" + packageLength);
        if (packageLength == 0) {
            Assert.error("错误，数据包长度不能为0");
        }
        //半包
        if ( packageLength > in.readableBytes()) {
            in.resetReaderIndex();
        } else {

            //跳过标志位
            in.skipBytes(2);
            int headLength = in.readInt();
           // log.debug("head长度:" + headLength);
            byte[] array;
            array = new byte[headLength];
            in.getBytes(in.readerIndex(), array, 0, headLength);
            PokerMsg.PBHead head = PokerMsg.PBHead.newBuilder().mergeFrom(array).build();
           // log.debug("head " + head);
            in.skipBytes(headLength);
            int contentLength = in.readInt();
            array = new byte[contentLength];
            //log.debug("content长度:" + contentLength);
            in.getBytes(in.readerIndex(), array, 0, contentLength);
            //沾包处理
            in.skipBytes(contentLength);
            PokerMsg.PBCSMsg message = PokerMsg.PBCSMsg.newBuilder().mergeFrom(array, 0, contentLength).build();
            Message msg = new Message();
            msg.setHead(head);
            msg.setMessage(message);
            out.add(msg);

        }


    }


}
