package com.jinhaidun.mahjong.io;

import com.jinhaidun.store.entity.Player;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.AttributeKey;

public class ChannelAttributeUtil {
	private static String PLAYER_ID = "playerId";
	private static String PLAYER = "player";

	private static String OFFLINE_HANDLER = "offlineHandler";

	private static  String ROOM_ID="roomId";
	// private static AttributeKey<Map<String, Object>> mapKey =
	// AttributeKey.valueOf("mapkey");


	public static AttributeKey<Integer> playerIdKey = AttributeKey.valueOf(PLAYER_ID);
	public static AttributeKey<Player> playerKey = AttributeKey.valueOf(PLAYER);
	public static AttributeKey<Integer> roomIdKey = AttributeKey.valueOf(ROOM_ID);
	public static AttributeKey<OffLineHandler> offlineHandlerKey = AttributeKey.valueOf(OFFLINE_HANDLER);

	public static void clear(ChannelHandlerContext ctx, AttributeKey<?> key) {

		ctx.channel().attr(key).set(null);

	}

	public static void clear(Channel channel, AttributeKey<?> key) {

		channel.attr(key).set(null);
	}


	public static  Integer getPlayerId(ChannelHandlerContext ctx) {
		if (ctx == null) {
			return null;
		}

		return ctx.channel().attr(playerIdKey).get();

	}

	public static void setPlayerId(ChannelHandlerContext ctx, Integer playerId) {

		ctx.channel().attr(playerIdKey).set(playerId);

	}

	public static Integer getPlayerId(Channel channel) {

		return channel.attr(playerIdKey).get();

	}

	public static void setOfflineHandler(Channel channel, OffLineHandler handler) {

		channel.attr(offlineHandlerKey).set(handler);

	}

	public static OffLineHandler getOfflineHandler(Channel channel) {

		return channel.attr(offlineHandlerKey).get();

	}
	public static void setRoomId(Channel channel, Integer roomId) {

		channel.attr(roomIdKey).set(roomId);

	}

	public static Integer getRoomId(Channel channel) {

		return channel.attr(roomIdKey).get();

	}

	@SuppressWarnings("unchecked")
	public static <T> T get(ChannelHandlerContext ctx, AttributeKey<T> key) {


		return (T) ctx.channel().attr(key);
	}

	public static <T> void set(ChannelHandlerContext ctx, AttributeKey<T> key, T value) {

		ctx.channel().attr(key).set(value);
	}
	// map形式的存取
	// public static Object get(ChannelHandlerContext ctx, String key) {
	//
	// return checkMap(ctx).get(key);
	// }
	//
	// public static void set(ChannelHandlerContext ctx, String key, Object
	// value) {
	//
	// checkMap(ctx).put(key, value);
	// }
	//
	// private static Map<String, Object> checkMap(ChannelHandlerContext ctx) {
	// Attribute<Map<String, Object>> attr = ctx.attr(mapKey);
	// Map<String, Object> map = attr.get();
	//
	// if (map == null) {
	// map = new HashMap<String, Object>();
	//
	// attr.set(map);
	// }
	//
	// return map;
	// }
	//

}
