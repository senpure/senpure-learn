package com.jinhaidun.mahjong.io;

import io.netty.channel.Channel;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.springframework.util.Assert;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ChannelUtil {

	public static String LOGIN = "login";
	public static String CONNECTION = "connection";
	public static  String ROOM="room";
	private static Map<String, ChannelGroup> groups = new ConcurrentHashMap();
	private static Map<Object, Channel> channels = new ConcurrentHashMap();
	public static void setChannel(Object key, Channel channel) {
		channels.put(key, channel);
	}
	public static Channel removeChannel(Object key) {
		return channels.remove(key);
	}

	public static Channel getChannel(Object key) {

		return channels.get(key);
	}

	public static void setChannelGroup(String name, ChannelGroup group) {
		Assert.isNull(groups.get(name), "[" + name + "] is existing !");
		groups.put(name, group);
	}

	public static ChannelGroup getChannelGroup(String name) {
		return groups.get(name);
	}

	public static ChannelGroup getChannelGroup(String name, boolean creat) {
		ChannelGroup group = groups.get(name);
		if (creat && group == null) {
			group = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
			groups.put(name, group);
		}
		return group;
	}

	public static ChannelGroup getLoginChannelGroup() {
		return groups.get(LOGIN);
	}

	public static void setLoginChannelGroup(ChannelGroup group) {
		setChannelGroup(LOGIN, group);
	}

	public static boolean addLoginCahnnel(Channel channel) {

		return getLoginChannelGroup().add(channel);
	}

	public static void setConnectionChannelGroup(ChannelGroup group) {
		setChannelGroup(CONNECTION, group);
	}

	public static ChannelGroup getConnectionChannelGroup() {

		return groups.get(CONNECTION);
	}

	public static boolean addConnectionCahnnel(Channel channel) {

		return getConnectionChannelGroup().add(channel);
	}

	public static void setRoomChannelGroup(ChannelGroup group) {
		setChannelGroup(ROOM, group);
	}

	public static ChannelGroup getRoomChannelGroup() {

		return groups.get(ROOM);
	}

	public static boolean addRoomCahnnel(Channel channel) {

		return getRoomChannelGroup().add(channel);
	}


}
