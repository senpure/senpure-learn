package com.jinhaidun.mahjong.io;


import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by admin on 2017/3/29.
 */
public class GameServerHandler  extends SimpleChannelInboundHandler<String>{


    protected Logger log = LogManager.getLogger(GameServer.class);



    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, String s) throws Exception {

      //  log.debug("收到消息："+msgAndID.getMessageCase().getNumber()+"------"+msgAndID.getMessageCase().name());

       // MessageHandlerUtil.execute(channelHandlerContext,msgAndID);

    }
    public static void main(String[] args) {

    }
}
