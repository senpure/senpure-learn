package com.jinhaidun.mahjong.io;

import com.jinhaidun.mahjong.msg.Message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

/**
 * Created by 罗中正 on 2017/4/18.
 */
public class LogHandler extends LoggingHandler {

    public LogHandler(LogLevel level) {
        super(level);
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {

        if (msg instanceof Message) {
            Message message = (Message) msg;
            if (message.getMessage().hasCsResponseHeartBeat()) {
                ctx.write(msg, promise);
                return;
            }
        }
        super.write(ctx, msg, promise);
    }

    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (msg instanceof Message) {
            Message message = (Message) msg;
            if (message.getMessage().hasCsRequestHeartBeat()) {
                ctx.fireChannelRead(msg);
                return;
            }
        }

        super.channelRead(ctx, msg);
    }

    @Override
    public void flush(ChannelHandlerContext ctx) throws Exception {
        ctx.flush();
    }
}
