package com.jinhaidun.mahjong.io;

import com.google.protobuf.MessageLite;
import com.jinhaidun.mahjong.msg.PokerMsg;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * Created by 罗中正 on 2017/4/5.
 */
public class MessageDecoder  extends ByteToMessageDecoder {
    protected Logger log = LogManager.getLogger(MessageDecoder.class);
    private final MessageLite head= PokerMsg.PBHead.getDefaultInstance();

    private final MessageLite content= PokerMsg.PBCSMsg.getDefaultInstance();


    @Override
    protected void decode(ChannelHandlerContext channelHandlerContext, ByteBuf byteBuf, List<Object> list) throws Exception {

        byteBuf.markReaderIndex();
        int preIndex = byteBuf.readerIndex();
        log.debug("preindex "+preIndex);
     int dpLength=   byteBuf.readInt();
     log.debug("消息长度:"+dpLength+","+byteBuf.readableBytes());


      //  ByteBuf contentByteBuf=Unpooled.buffer(contentLenth);
      //  byteBuf.readBytes(contentByteBuf);

        if(dpLength>byteBuf.readableBytes())
        {
            byteBuf.resetReaderIndex();
        }
        else {
            //跳过标志位
            byteBuf.skipBytes(2);
            int headLength=byteBuf.readInt();
            log.debug("head长度:"+headLength);
            ByteBuf headByteBuf=  Unpooled.buffer(headLength);
            byteBuf.readBytes(headByteBuf,headLength);
            int contentLenth=byteBuf.readInt();
            list.add(byteBuf.readRetainedSlice(contentLenth));
        }


    }
}
