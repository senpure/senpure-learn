package com.jinhaidun.mahjong.io;

import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.MessageLite;
import com.jinhaidun.mahjong.msg.PokerMsg;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

/**
 * Created by 罗中正 on 2017/4/5.
 */
public class MessageEncoder extends MessageToByteEncoder<ByteBuf> {
    private static boolean HAS_PARSER;
    private final MessageLite prototype = PokerMsg.PBHead.getDefaultInstance();
    private ExtensionRegistryLite extensionRegistry;
    PokerMsg.PBHead head = PokerMsg.PBHead.getDefaultInstance();
    static {
        boolean hasParser = false;

        try {
            MessageLite.class.getDeclaredMethod("getParserForType", new Class[0]);
            hasParser = true;
        } catch (Throwable var2) {

        }

        HAS_PARSER = hasParser;
    }

    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext, ByteBuf msg, ByteBuf out) throws Exception {

        int length = msg.readableBytes();
        byte [] array=head.toByteArray() ;
        int headL=array.length;
        int fl=4+2 + 4+array.length+4+length;
        out.ensureWritable(fl);
        out.writeInt(fl-4);
        out.writeByte('X');
        out.writeByte('X');
        out.writeInt(headL).writeBytes(array);

        // out.ensureWritable(6 + bodyLen);

        out.writeInt(length);
        // out.writeInt()
         out.writeBytes(msg, msg.readerIndex(), length);

    }
}
