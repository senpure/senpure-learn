package com.jinhaidun.mahjong.io;

import com.jinhaidun.mahjong.handler.MessageHandlerUtil;
import com.jinhaidun.mahjong.msg.Message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * Created by 罗中正 on 2017/4/6.
 */
public class MessageServerHandler extends SimpleChannelInboundHandler<com.jinhaidun.mahjong.msg.Message> {

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, Message message) throws Exception {
        MessageHandlerUtil.execute(ctx,message);

    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
        ctx.flush();
    }
}
