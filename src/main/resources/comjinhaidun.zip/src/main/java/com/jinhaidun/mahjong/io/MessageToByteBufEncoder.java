package com.jinhaidun.mahjong.io;

import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerMsg;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by 罗中正 on 2017/4/6.
 */
public class MessageToByteBufEncoder extends MessageToByteEncoder<Message> {
    protected Logger log = LogManager.getLogger(MessageToByteBufEncoder.class);
    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext, Message message, ByteBuf out) throws Exception {


       // log.debug("编码message");
        PokerMsg.PBHead head = message.getHead();
        PokerMsg.PBCSMsg msg = message.getMessage();
        byte hb[] = head.toByteArray();
        byte mb[] = msg.toByteArray();
        int length =2 + 4 + hb.length + 4 + mb.length;
        out.ensureWritable(length + 4);
        out.writeInt(length);
        out.writeByte('X');
        out.writeByte('X');
        out.writeInt(hb.length);
        out.writeBytes(hb);
        out.writeInt(mb.length);
        out.writeBytes(mb);

    }
}
