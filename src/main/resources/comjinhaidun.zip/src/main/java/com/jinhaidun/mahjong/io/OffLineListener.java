package com.jinhaidun.mahjong.io;

import io.netty.channel.ChannelHandlerContext;

public interface OffLineListener {

	public void executeOffLine(ChannelHandlerContext ctx);
	
	public  String getOffLineListenerName();
	
}
