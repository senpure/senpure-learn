package com.jinhaidun.mahjong.io;

import com.jinhaidun.mahjong.msg.PokerMsg;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by 罗中正 on 2017/4/5.
 */
public class PokerMessageServerHandler extends SimpleChannelInboundHandler<PokerMsg.PBCSMsg> {
    protected Logger log = LogManager.getLogger(PokerMessageServerHandler.class);
    @Override
    protected void channelRead0(ChannelHandlerContext channelHandlerContext, PokerMsg.PBCSMsg pbcsMsg) throws Exception {


        log.debug("收到消息："+pbcsMsg.getMsgUnionCase().getNumber()+"------"+pbcsMsg.getMsgUnionCase().name());

       // MessageHandlerUtil.execute(channelHandlerContext,pbcsMsg);
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
       super.channelReadComplete(ctx);
    }
}
