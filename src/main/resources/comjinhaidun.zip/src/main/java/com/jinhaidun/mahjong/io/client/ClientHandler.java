/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.jinhaidun.mahjong.io.client;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.io.*;

/**
 * Handler implementation for the echo client.  It initiates the ping-pong
 * traffic between the echo client and server by sending the first message to
 * the server.
 */
public class ClientHandler extends ChannelInboundHandlerAdapter {

    private final ByteBuf firstMessage;

    /**
     * Creates a client-side handler.
     */
    public ClientHandler() {
        firstMessage = Unpooled.buffer(Client.SIZE);
        for (int i = 0; i < firstMessage.capacity(); i++) {
            firstMessage.writeByte((byte) i);
        }
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws UnsupportedEncodingException {


        //  Message.Book book = Message.Book.newBuilder().setEmail("e").build();

        // Message.Person person=Message.Person.newBuilder().setEmail("em").build();
       // MessageAndID.MsgAndID.Builder builder = MessageAndID.MsgAndID.newBuilder();
        // MessageAndID.MsgAndID msgAndID =builder .setBook(book).build();
        // msgAndID =builder.setPeron(person).build();
        //ctx.writeAndFlush(msgAndID);
//        PokerMsgCs.CSNOtifyPlayerConnectionState s=   PokerMsgCs.CSNOtifyPlayerConnectionState.newBuilder().setConnectionState(1).setSeatIndex(2).build();
//        PokerMsgCs.CSRequestLogin login=   PokerMsgCs.CSRequestLogin.getDefaultInstance();
//        Object pbcsMsg=  PokerMsg.PBCSMsg.newBuilder().setCsRequestLogin(login);

        File file = new File("E:\\array\\array.txt");
        InputStream in = null;
        ByteBuf buf= Unpooled.buffer();
        try {
            System.out.println("以字节为单位读取文件内容，一次读一个字节：");
            // 一次读一个字节
            in = new FileInputStream(file);
            int tempbyte;
            while ((tempbyte = in.read()) != -1) {
                buf.writeByte(tempbyte);
               // System.out.println(tempbyte);
            }
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
       // buf.writeInt(16).writeByte(1).writeByte(2).writeInt(20);
        for(int i=0;i<1;i++)
        {
            buf.retain();
         ctx.writeAndFlush(buf);
        }

        ctx.flush();
        //Object pbcsMsg=buf;
       // System.out.println("发送消息:"+pbcsMsg);

       // ctx.writeAndFlush(pbcsMsg);

    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {

        System.out.println("收到消息 +"+msg);

       // ctx.write(msg);
    }

    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        // Close the connection when an exception is raised.
        cause.printStackTrace();
        ctx.close();
    }
}
