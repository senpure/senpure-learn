package com.jinhaidun.mahjong.logic;

/**
 * Created by 罗中正 on 2017/6/22.
 */
public class Config {

    private static boolean openRoom=false;

    public static boolean isOpenRoom() {
        return openRoom;
    }

    public static void setOpenRoom(boolean openRoom) {
        Config.openRoom = openRoom;
    }
}
