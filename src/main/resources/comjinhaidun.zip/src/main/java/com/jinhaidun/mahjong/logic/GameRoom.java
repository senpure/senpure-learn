package com.jinhaidun.mahjong.logic;


import com.jinhaidun.mahjong.handler.MessageLoginHandler;
import com.jinhaidun.mahjong.handler.MessageUtil;
import com.jinhaidun.mahjong.handler.MessageWraper;
import com.jinhaidun.mahjong.io.ChannelAttributeUtil;
import com.jinhaidun.mahjong.io.ChannelUtil;
import com.jinhaidun.mahjong.io.OffLineHandler;
import com.jinhaidun.mahjong.io.OffLineListener;
import com.jinhaidun.mahjong.msg.Message;
import com.jinhaidun.mahjong.msg.PokerCommon;
import com.jinhaidun.mahjong.msg.PokerData;
import com.jinhaidun.mahjong.msg.PokerMsgCs;
import com.jinhaidun.mahjong.service.DataService;
import com.jinhaidun.mahjong.struct.*;
import com.jinhaidun.mahjong.util.TileUtil;
import com.jinhaidun.store.em.LOGOUT_TYPE;
import com.senpure.base.util.Assert;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import javax.annotation.PreDestroy;
import java.util.*;

/**
 * Created by 罗中正 on 2017/4/14.
 */
@Service
@Scope("prototype")
public class GameRoom implements OffLineListener, BeanNameAware {
    protected ChannelGroup channelGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    @Autowired
    protected DataService dataService;
    protected RenQiuMahjong mahjong;
    protected Logger log;
    protected Seat turnSeat;
    public List<Seat> seats;
    protected int huiPiValue;
    protected int baidaValue;
    protected int bankerIndex;
    protected int baseScore = 2;
    protected boolean canEnter = true;
    //这局正在进行。
    protected boolean panPlaying = false;
    protected List<Choice> choices;

    protected int choiceTokenCount;
    //当前打出的牌
    protected int outValue;
    protected boolean genZhuang;
    protected int genZhuangCount = 0;
    protected Tile outTile;

    protected boolean lianZhuang = true;
    protected boolean liuju = false;

    protected long firstTime = 0;
    /**
     * 正在打的盘数
     */
    protected int playedPanShu = 0;
    protected int changeBankerCount = 0;
    protected ROOM_STATE roomState;
    protected int playerCount = 0;
    protected int roomId;
    protected int round = 1;
    protected RoomConfig config;
    protected int seatSize = 4;
    protected boolean waitChoice = false;

    protected long noPlayerTime;

    protected ROOM_STATE noPlayerBefore;
    protected long createTime;

    protected long currentStartTime;
    // protected List<Record> records;
    // protected Record currentRecord;
    protected Set<Integer> dissolve;
    List<Assign> assigns;
    protected Map<String, Object> contextMap;

    /*
    战绩相关
     */

    protected List<PokerData.PBRoundResult> roundResults = new ArrayList<>();
    protected List<PokerData.PBUserScoreInfo> finalyScore = new ArrayList<>();
    protected List<Video> videos = new ArrayList<>();
    protected Video currentVideo;

    public int getRoomId() {
        return roomId;
    }

    public void init(RoomConfig config) {

        this.config = config;
        this.roomId = config.roomId;
        this.round = config.round;
        this.baseScore = 2;

        seats = new ArrayList<>();
        for (int i = 0; i < seatSize; i++) {
            Seat seat = new Seat();
            seat.index = i;
            seat.state = SEAT_STATE.NO_PLAYER;
            seat.online = false;
            seats.add(seat);
        }
        bankerIndex = 0;
        choices = new ArrayList<>();
        lianZhuang = true;
        mahjong = TileUtil.generateRenQiuMahjion();
        mahjong.nextTime();
        roomState = ROOM_STATE.READY_START;
        contextMap = new HashMap<>();
        log = Logger.getLogger(roomId);
        choiceTokenCount = 1;
        assigns = new ArrayList<>();
        dissolve = new LinkedHashSet<>();
        createTime = System.currentTimeMillis();
        firstTime = createTime;
        // records = new ArrayList<>();
        log.debug("创建房间\n" + config);
    }


    public int getToken() {
        return choiceTokenCount++;
    }

    public String getSeatLogInfo(Seat seat) {
        return "[" + seat.index + "][" + seat.player.id + "][" + seat.player.nick + "]";
    }

    public void assgin(Assign assign) {

        log.debug(assign.toString());
        assigns.add(assign);
    }

    public void startMahjong() {

        if (roomState == ROOM_STATE.ROUND_OVER) {
            log.error("牌局已经打完，不可再开始 round =" + round + " playedPanShu =" + playedPanShu);
            return;
        }
        log.debug("====================开始牌局==========================");
        log.debug("====================开始牌局==========================");
        log.debug("====================开始牌局==========================");
        log.debug("麻将数量" + mahjong.currentTiles().size());
        roomState = ROOM_STATE.PLAYING;
        playedPanShu++;
        long now = System.currentTimeMillis();
        currentStartTime = now;
        if (playedPanShu == 1) {
            firstTime = now;
        }
        for (Seat seat : seats) {
            seat.state = SEAT_STATE.PLAYING;
            seat.hand.addAll(mahjong.getTiles(13));
            if (seat.index == bankerIndex) {
                seat.hand.add(mahjong.getTile());
            }
            Collections.sort(seat.hand);
        }
        Tile huiPi = mahjong.currentTiles().get(mahjong.currentTiles().size() - 1);
        huiPiValue = huiPi.getIntValue();
        if (huiPi.getSuit().ordinal() < 3) {
            baidaValue = huiPi.getIntValue() + 1;
            if (baidaValue % 10 == 0) {
                baidaValue = baidaValue - 9;
            }
        } else {
            if (huiPiValue == 34) {
                baidaValue = 41;
            }
            if (huiPiValue == 43) {
                baidaValue = 31;
            }
        }
        log.debug("会儿皮[" + TileUtil.getTile(huiPiValue) + "],会牌 [" + TileUtil.getTile(baidaValue) + "]");
        Seat seat = seats.get(bankerIndex);
        // currentRecord = new Record();
        currentVideo = new Video();
        currentVideo.setIndex(playedPanShu);


        MsgManager.doStarGameMessage(this);
        seat.thisGang = false;
        seat.lianXuGangCount = 0;
        seat.firstTurnTime = System.currentTimeMillis();
        afterMoPai(seat, true, true);

    }


    public synchronized void playerEnterRoom(Message data, PokerMsgCs.CSRequestEnterTable message, int playerId) {
        if (roomState == ROOM_STATE.CLOSED) {
            log.error("房间关闭有人进入[" + playerId + "]");
            return;
        }
        if (playerCount >= 4) {
            log.debug("牌局人数达到上限");
            MessageWraper messageWraper = MessageUtil.getMessage(data);
            PokerMsgCs.CSResponseEnterTable resET = PokerMsgCs.CSResponseEnterTable.newBuilder().
                    setResult(PokerCommon.ENMessageError.EN_MESSAGE_NO_EMPTY_SEAT).build();
            messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsResponseEnterTable(resET).build());

            MsgManager.sendMessage(playerId, messageWraper);
            return;
        }
        playerCount++;
        boolean firstEnter = true;
        Seat sitseat = null;
        for (Seat seat : seats) {
            if (seat.player != null && seat.player.id == playerId) {
                firstEnter = false;
                sitseat = seat;
                seat.online = true;
                MsgManager.doChangeConnState(seat, this, true);
                log.debug(getSeatLogInfo(sitseat) + "重连进入房间");
                if (roomState == ROOM_STATE.NO_PLAYER) {
                    roomState = noPlayerBefore;
                }

            }
        }
        Player player = MessageLoginHandler.getPlayer(playerId);
        if (firstEnter) {
            for (Seat seat : seats) {
                if (seat.player == null) {
                    seat.player = player;
                    seat.online = true;
                    seat.state = SEAT_STATE.WAIT_FOR_GAME;
                    sitseat = seat;
                    break;
                }
            }
            log.debug(getSeatLogInfo(sitseat) + "进入房间");
        }
        dataService.updatePlayerRoom(playerId, roomId);
        Channel channel = ChannelUtil.getChannel(playerId);
        if (channel != null) {
            channelGroup.add(channel);
            ChannelAttributeUtil.setRoomId(channel, getRoomId());
            OffLineHandler.regChannelOffLineListener(channel, this);
        }
        log.debug("roomstate is " + roomState);
        MsgManager.doEnterMessage(data, this, player, sitseat);

        if (!firstEnter) {
            log.debug("可选操作 :" + sitseat.choices);
            //轮到自己时的掉线
            if (turnSeat != null && turnSeat.index == sitseat.index) {
                if (sitseat.choices != null) {
                    MsgManager.doChoicesMessage(sitseat, sitseat.choices, roomId, true, false, this, true);
                }
            } else {
                if (sitseat.choices != null && sitseat.choices.size() > 0) {
                    MsgManager.doChoicesMessage(sitseat, sitseat.choices, roomId, false, true, this, true);
                }

            }
        }

    }

    public void readyForGame(Message data, PokerMsgCs.CSRequestReadyForGame message, Seat seat) {

        if (roomState != ROOM_STATE.READY_START && roomState != ROOM_STATE.READY_NEXT) {
            log.warn("房间状态不对，不能准备" + roomState);
            return;
        }
        seat.readyForGame = message.getState();
        seat.state = seat.readyForGame ? SEAT_STATE.READY_FOR_GAME : SEAT_STATE.WAIT_FOR_GAME;
        log.debug(getSeatLogInfo(seat) + "准备游戏" + seat.readyForGame);
        MsgManager.doReadForGameMessage(this, seat);
        if (message.getState()) {
            int ready = 0;
            for (Seat s : seats) {
                if (s.readyForGame) {
                    ready++;
                }
            }
            if (ready == 4) {
                startMahjong();
            }
        }
    }

    public void turn(Seat seat) {
        if (waitChoice) {
            boolean check = true;
            boolean loginfo = true;
            while (check) {
                int size = choices.size();
                if (size == 0) {
                    log.debug("有人做了碰杠胡操作[" + size + "]");
                    return;
                }
                check = false;
                for (int i = 0; i < size; i++) {
                    Choice choice = choices.get(i);
                    if (choice.execute) {
                        log.debug(getSeatLogInfo(seat) + "有人做了碰杠胡操作[" + size + "] 不能摸排");
                        return;
                    }
                    if (!choice.pass && choice.expire > System.currentTimeMillis()) {
                        check = true;
                    }
                }
                try {
                    if (loginfo) {
                        log.debug(getSeatLogInfo(seat) + "轮到摸排，但是 等待别人做出操作\n" + choices);
                        loginfo = false;
                    }

                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    log.error("", e);
                }
            }
        }
        if (mahjong.currentTiles().size() == 0) {
            log.debug("流局");
            //todo liuju\
            liuju();
            //MsgManager.doHuPaiMessage(this);
            // finishMahjong(seat);
            return;
        }
        seat.thisGang = false;
        seat.lianXuGangCount = 0;
        seat.firstTurnTime = System.currentTimeMillis();
        moPai(seat, true);
    }

    /**
     * @param turn 是否是正常位置轮到的
     */
    public void moPai(Seat seat, boolean turn) {
        Tile tile = null;
        log.debug(assigns.toString());
        for (int i = 0; i < assigns.size(); i++) {
            Assign assign = assigns.get(i);
            if (assign.playerId == seat.player.id) {
                tile = mahjong.getTile(assign.mahjongValue);
                log.debug(getSeatLogInfo(seat) + "想要获得牌 [" + TileUtil.getTile(assign.mahjongValue) + "] 实际获得 [" + tile + "]");
                assigns.remove(i);
                break;
            }

        }
        if (tile == null) {
            tile = mahjong.getTile();
        }
        seat.hand.add(tile);
        seat.moPaiCount++;

        seat.moPaiValue = tile.getIntValue();
        seat.turnMoPai = turn;
        log.debug(getSeatLogInfo(seat) + "摸排 [" + tile + "]");

        MsgManager.doMoPaiMessage(seat, tile.getIntValue(), this);

        afterMoPai(seat, turn, true);


    }

    public void markSeat(Seat seat) {
        turnSeat = seat;
        PokerMsgCs.CSNotifyNextOperation operation = PokerMsgCs.CSNotifyNextOperation.newBuilder()
                .setOperationIndex(seat.index)
                .setLeftTileNum(mahjong.currentTiles().size()).build();
        MessageWraper messageWraper = MessageUtil.getMessage();
        messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsNotifyNextOperation(operation).build());
        // MsgManager.sendMessage(seat.player.id, messageWraper);
        channelGroup.writeAndFlush(messageWraper);
    }

    /**
     * 应该是获得一张牌后
     *
     * @param seat
     * @param turn self 自己摸得牌如杠
     */

    public void afterMoPai(Seat seat, boolean turn, boolean self) {
        log.debug(getSeatLogInfo(seat) + "当前手牌 " + seat.hand);
        seat.turnMoPai = turn;
        List<Choice> choices = new ArrayList<>();

        int token = getToken();
        seat.choiceToken = token;
        if (self) {
            HuPai huPai = huPaiCheck(seat);
            if (huPai.isHu()) {
                // 可胡
                Choice choice = createChoice(seat.index, Choice.CHOICE.HU, huPai.getHuValue(), 1, token);
                choices.add(choice);
            }
        }

        Map<Integer, Integer> valueCountMap = new HashMap<>();
        seat.hand.forEach(value -> {
            valueCountMap.computeIfPresent(value.getIntValue(), (key, count) -> ++count);
            valueCountMap.putIfAbsent(value.getIntValue(), 1);

        });

        Iterator<Map.Entry<Integer, Integer>> iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            int value = entry.getValue();
            if (value == 4) {
                Choice choice = createChoice(seat.index, Choice.CHOICE.AN_GANG, entry.getKey(), 4, token);
                choices.add(choice);
                if (entry.getKey() == baidaValue) {
                    choice = createChoice(seat.index, Choice.CHOICE.HUI_ER_PI_AN_GANG, baidaValue, 7, token);
                    choices.add(choice);

                }

            } else if (value == 3) {
                if (entry.getKey() == baidaValue) {
                    Choice choice = createChoice(seat.index, Choice.CHOICE.HUI_ER_PI_AN_GANG, baidaValue, 7, token);
                    choices.add(choice);
                }
                //
                //
            }
        }
        //加杠
        if (turn) {//第一次摸排才算
            HashMap<Integer, Integer> vmap = new HashMap<>();
            seat.peng.forEach(value -> {
                vmap.computeIfPresent(value.getIntValue(), (key, count) -> ++count);
                vmap.putIfAbsent(value.getIntValue(), 1);
            });
            iterator = vmap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<Integer, Integer> entry = iterator.next();
                int count = TileUtil.countTile(seat.hand, entry.getValue());
                if (count == 1) {
                    Choice choice = createChoice(seat.index, Choice.CHOICE.JIA_GANG, entry.getKey(), 4, token);
                    choices.add(choice);
                }
            }
        }

        if (TileUtil.canFeng(seat.hand)) {
            Choice choice = createChoice(seat.index, Choice.CHOICE.SI_XI_FENG, 0, 4, token);
            choices.add(choice);
        }
        if (TileUtil.canJian(seat.hand)) {
            Choice choice = createChoice(seat.index, Choice.CHOICE.SAN_ZHI_JIAN, 0, 7, token);
            choices.add(choice);
        }

        if (choices.size() > 0) {
            seat.choices = choices;
            log.debug(getSeatLogInfo(seat) + " 可选操作\n" + choices);
        }
        MsgManager.doChoicesMessage(seat, choices, roomId, true, false, this);
        //表示可以操作出牌，等
        markSeat(seat);
    }

    public HuPai huPaiCheck(Seat seat) {
        HuPai huPai = TileUtil.checkHuPai(seat.hand, baidaValue);
        huPaiCheck(seat, huPai);
        return huPai;
    }

    public HuPai huPaiCheck(Seat seat, HuPai huPai) {
        if (huPai.isHu()) {
            if (seat.chuPaiCount == 1) {
                if (seat.index == bankerIndex) {
                    huPai.getPai().add(HuPai.PAI.TIAN_HU);
                } else {
                    huPai.getPai().add(HuPai.PAI.DI_HU);
                }
            }
        }
        if (seat.thisGang) {
            for (int i = 0; i < seat.lianXuGangCount; i++) {
                huPai.getPai().add(HuPai.PAI.GANG_SHANG_KAI_FA);
            }
        }

        return huPai;
    }


    public void huPai(Seat seat) {
        HuPai huPai = huPaiCheck(seat);
        if (huPai.isHu()) {
            log.debug(getSeatLogInfo(seat) + "自摸\n" + huPai);
            huPai.getPai().add(0, HuPai.PAI.ZI_MO);
            huPai.setEndValue(seat.moPaiValue);
            MsgManager.doActionMessage(seat, Choice.CHOICE.HU, huPai.getHuValue(), this);
            huPai(seat, huPai, -1);
            //   finishChoice(seat, Choice.CHOICE.HU);
        } else {

            log.warn(getSeatLogInfo(seat) + ",没有胡牌却发送了胡牌操作");
        }

    }

    public void anGang(Seat seat, int value) {
        if (TileUtil.countTile(seat.hand, value) == 4) {
            TileUtil.moveTiles(seat.hand, seat.anGang, value, 4);

            seat.thisGang = true;
            seat.lianXuGangCount++;
            MsgManager.doActionMessage(seat, Choice.CHOICE.AN_GANG, value, this);
            moPai(seat, false);
        } else {
            log.warn(getSeatLogInfo(seat) + ",没有牌可杠却发送了杠牌操作");
        }
    }

    public void jiaGang(Seat seat, int value) {
        if (TileUtil.countTile(seat.peng, value) == 3) {
            TileUtil.moveTiles(seat.hand, seat.mingGang, value, 1);
            TileUtil.moveTiles(seat.peng, seat.mingGang, value, 3);
            seat.thisGang = true;
            seat.lianXuGangCount++;
            MsgManager.doActionMessage(seat, Choice.CHOICE.JIA_GANG, value, this);
            moPai(seat, false);
        } else {
            log.warn(getSeatLogInfo(seat) + ",没有牌可杠却发送了杠牌操作");
        }
    }

    public void markScore(Seat seat, SHOW_PAI pai) {
        markScore(seat, pai, -1);
    }

    public void markScore(Seat seat, SHOW_PAI pai, int targetIndex) {
        int nextIndex = seat.index + 1;
        nextIndex = nextIndex == 4 ? 0 : nextIndex;
        nextIndex = targetIndex == -1 ? nextIndex : targetIndex;
        while (nextIndex != seat.index) {
            Score win = new Score();
            win.setWin(true);
            win.setSeatIndex(seat.index);
            win.setTargetIndex(nextIndex);
            win.setPai(pai);
            win.setScore(pai.getScore());
            seat.scores.add(win);

            Score lose = new Score();
            lose.setSeatIndex(nextIndex);
            lose.setTargetIndex(seat.index);
            lose.setPai(pai);
            lose.setWin(false);
            lose.setScore(-pai.getScore());
            seats.get(nextIndex).scores.add(lose);
            if (targetIndex != -1) {
                return;
            }
            nextIndex++;
            nextIndex = nextIndex == 4 ? 0 : nextIndex;
        }

    }

    public void feng(Seat seat, int value) {
        if (TileUtil.canFeng(seat.hand)) {
            TileUtil.moveTiles(seat.hand, seat.sixifeng, Tile.SUIT.FENG.ordinal() * 10 + 1, 1);
            TileUtil.moveTiles(seat.hand, seat.sixifeng, Tile.SUIT.FENG.ordinal() * 10 + 2, 1);
            TileUtil.moveTiles(seat.hand, seat.sixifeng, Tile.SUIT.FENG.ordinal() * 10 + 3, 1);
            TileUtil.moveTiles(seat.hand, seat.sixifeng, Tile.SUIT.FENG.ordinal() * 10 + 4, 1);

            seat.thisGang = true;
            seat.lianXuGangCount++;
            MsgManager.doActionMessage(seat, Choice.CHOICE.SI_XI_FENG, value, this);
            markScore(seat, SHOW_PAI.SI_XI_FENG);

            moPai(seat, false);
        } else {
            log.warn(getSeatLogInfo(seat) + ",没有牌可风却发送了风牌操作");
        }
    }


    public void jian(Seat seat, int value) {
        if (TileUtil.canJian(seat.hand)) {
            TileUtil.moveTiles(seat.hand, seat.sanzhijian, Tile.SUIT.JIAN.ordinal() * 10 + 1, 1);
            TileUtil.moveTiles(seat.hand, seat.sanzhijian, Tile.SUIT.JIAN.ordinal() * 10 + 2, 1);
            TileUtil.moveTiles(seat.hand, seat.sanzhijian, Tile.SUIT.JIAN.ordinal() * 10 + 3, 1);

            MsgManager.doActionMessage(seat, Choice.CHOICE.SAN_ZHI_JIAN, value, this);
            markScore(seat, SHOW_PAI.SAN_ZHI_JIAN);
            afterMoPai(seat, false, true);
        } else {
            log.warn(getSeatLogInfo(seat) + ",没有牌可箭却发送了箭牌操作");
        }
    }

    public void anHuierPi(Seat seat, int value) {
        if (TileUtil.countTile(seat.hand, baidaValue) >= 3) {
            TileUtil.moveTiles(seat.hand, seat.huierAnGang, baidaValue, 3);

            MsgManager.doActionMessage(seat, Choice.CHOICE.HUI_ER_PI_AN_GANG, value, this);
            markScore(seat, SHOW_PAI.HUI_ER_PI_AN_GANG);
            afterMoPai(seat, false, true);
        } else {
            log.warn(getSeatLogInfo(seat) + ",没有牌可会儿却发送了会儿牌操作");
        }
    }

    public void pass(Seat seat, int value, int token) {
        log.debug(getSeatLogInfo(seat) + "放弃" + seat.choiceToken);
        if (choices != null) {
            for (int i = 0; i < this.choices.size(); i++) {
                Choice choice = this.choices.get(i);
                if (choice.token == seat.choiceToken) {
                    log.debug(getSeatLogInfo(seat) + "放弃" + choice);
                    choice.pass = true;
                }
            }
        }
        if (value > 0) {
            chuPai(seat, value);
        }
    }

    public void chuPai(Seat seat, int value) {
        if (TileUtil.canChu(seat.hand, value) && turnSeat.index == seat.index) {
            choices.clear();
            waitChoice = false;
            TileUtil.moveTiles(seat.hand, seat.out, value, 1);
            log.debug(getSeatLogInfo(seat) + "出牌 [" + TileUtil.getTile(value) + "]");
            if (genZhuang) {
                if (outValue == value) {
                    genZhuangCount++;
                    if (genZhuangCount == 4) {
                        for (Seat s : seats) {
                            if (s.index != bankerIndex) {
                                markScore(s, SHOW_PAI.GEN_ZHUANG, bankerIndex);
                            }
                        }
                    }

                } else {
                    genZhuang = false;
                    genZhuangCount = 0;
                }
            }
            outValue = value;
            outTile = seat.out.get(seat.out.size() - 1);
            MsgManager.doChuPaiMessage(seat, value, this);
            afterChuPai(seat, value);
        } else {

            log.warn(getSeatLogInfo(seat) + "不可出牌");
        }
    }

    protected boolean waitChoice(Seat seat, int arg) {
        int chuPaiIndex = turnSeat.index;
        int distance = seat.index - chuPaiIndex;
        if (seat.index < chuPaiIndex) {
            distance += 4;
        }
        int priority = distance + arg;
        boolean check = true;
        boolean loginfo = true;
        while (check) {
            check = false;

            for (int i = 0; i < choices.size(); i++) {
                Choice choice = choices.get(i);
                if (choice.execute && choice.priority < priority) {
                    log.debug(getSeatLogInfo(seat) + "有优先级高的做了操作,取消该次操作");
                    return false;
                }
                if (choice.token != seat.choiceToken && !choice.pass && choice.expire > System.currentTimeMillis() && choice.priority < priority) {
                    check = true;
                }
            }
            try {
                if (check && loginfo) {
                    log.debug(getSeatLogInfo(seat) + "等待别人做出操作\n" + choices);
                    loginfo = false;
                }
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    protected void finishChoice(Seat seat, Choice.CHOICE ch) {
        if (seat.choiceToken != 0) {
            for (int i = 0; i < choices.size(); i++) {
                Choice choice = choices.get(i);
                if (choice.token == seat.choiceToken) {
                    if (choice.choice == ch) {
                        choice.execute = true;
                    } else {
                        choice.pass = true;
                    }
                }

            }
        }
    }

    public void huPai(Seat seat, int value) {
        if (seat.hand.size() % 3 == 2) {
            huPai(seat);
            return;
        }
        HuPai huPai =
                TileUtil.checkHuPai(seat, outValue, baidaValue);
        if (huPai.isHu()) {
            seat.out.add(outTile);
            log.debug(getSeatLogInfo(seat) + " 胡 [" + TileUtil.getTile(outValue) + "]");
            if (waitChoice(seat, 0)) {
                finishChoice(seat, Choice.CHOICE.HU);
                log.debug(getSeatLogInfo(seat) + " 胡 [" + TileUtil.getTile(outValue) + "] 成功\n" + huPai);
                huPai.getPai().add(0, HuPai.PAI.DIAN_PAO);
                huPai.setEndValue(outValue);
                huPaiCheck(seat, huPai);
                seat.huPai = huPai;
                MsgManager.doActionMessage(seat, Choice.CHOICE.HU, value, this);
                huPai(seat, huPai, turnSeat.index);
            } else {
                log.debug(getSeatLogInfo(seat) + " 胡 [" + TileUtil.getTile(outValue) + "] 失败 -> 优先级");
            }

        }

    }


    public void mingGang(Seat seat, int value) {
        if (TileUtil.canGang(seat.hand, value) && value == outValue) {
            log.debug(getSeatLogInfo(seat) + " 明杠 [" + TileUtil.getTile(value) + "]");
            if (waitChoice(seat, 3)) {
                log.debug(getSeatLogInfo(seat) + " 明杠 [" + TileUtil.getTile(value) + "] 成功");
                finishChoice(seat, Choice.CHOICE.MING_GANG);
                TileUtil.moveTiles(seat.hand, seat.mingGang, value, 3);
                Tile tile = turnSeat.out.remove(turnSeat.out.size() - 1);
                Assert.isTrue(tile.getIntValue() == outTile.getIntValue());
                seat.mingGang.add(outTile);
                seat.thisGang = true;
                seat.lianXuGangCount++;
                genZhuang = false;
                MsgManager.doActionMessage(seat, Choice.CHOICE.MING_GANG, value, this);
                moPai(seat, false);

            } else {
                log.debug(getSeatLogInfo(seat) + " 明杠 [" + TileUtil.getTile(value) + "] 失败 -> 优先级");
            }
        }

    }

    public void pengGang(Seat seat, int value) {
        if (TileUtil.countTile(seat.peng, value) == 3 && value == outValue) {

            log.debug(getSeatLogInfo(seat) + " 碰杠 [" + TileUtil.getTile(value) + "]");
            if (waitChoice(seat, 3)) {
                log.debug(getSeatLogInfo(seat) + " 碰杠 [" + TileUtil.getTile(value) + "] 成功");
                TileUtil.moveTiles(seat.peng, seat.mingGang, value, 3);
                Tile tile = turnSeat.out.remove(turnSeat.out.size() - 1);
                Assert.isTrue(tile.getIntValue() == outTile.getIntValue());
                seat.mingGang.add(outTile);
                finishChoice(seat, Choice.CHOICE.MING_GANG);

                seat.thisGang = true;
                seat.lianXuGangCount++;
                genZhuang = false;
                MsgManager.doActionMessage(seat, Choice.CHOICE.PENG_GANG, value, this);
                moPai(seat, false);

            } else {
                log.debug(getSeatLogInfo(seat) + " 碰杠 [" + TileUtil.getTile(value) + "] 失败 -> 优先级");
            }
        }

    }

    public void peng(Seat seat, int value) {
        if (TileUtil.canPeng(seat.hand, value) && value == outValue) {
            log.debug(getSeatLogInfo(seat) + " 碰 [" + TileUtil.getTile(value) + "]");
            if (waitChoice(seat, 6)) {
                log.debug(getSeatLogInfo(seat) + " 碰 [" + TileUtil.getTile(value) + "] 成功");
                finishChoice(seat, Choice.CHOICE.PENG);
                log.debug(choices.toString());
                Tile tile = turnSeat.out.remove(turnSeat.out.size() - 1);
                Assert.isTrue(tile.getIntValue() == outTile.getIntValue());
                TileUtil.moveTiles(seat.hand, seat.peng, value, 2);
                genZhuang = false;
                seat.peng.add(outTile);
                MsgManager.doActionMessage(seat, Choice.CHOICE.PENG, value, this);
                // MsgManager.doChoicesMessage(seat, new ArrayList<Choice>(), roomId, true, false);
                // markSeat(seat);
                afterMoPai(seat, false, false);
            } else {
                log.debug(getSeatLogInfo(seat) + " 碰 [" + TileUtil.getTile(value) + "] 失败 -> 优先级");
            }

        }
    }

    public void huierpigang(Seat seat, int value) {
        if (TileUtil.canPeng(seat.hand, value) && value == outValue && value == baidaValue) {
            log.debug(getSeatLogInfo(seat) + " 碰 [" + TileUtil.getTile(value) + "]");
            if (waitChoice(seat, 6)) {
                log.debug(getSeatLogInfo(seat) + " 碰 [" + TileUtil.getTile(value) + "] 成功");
                finishChoice(seat, Choice.CHOICE.HUI_ER_PI_MING_GANG);
                TileUtil.moveTiles(seat.hand, seat.huierMingGang, value, 2);
                Tile tile = turnSeat.out.remove(turnSeat.out.size() - 1);
                Assert.isTrue(tile.getIntValue() == outTile.getIntValue());
                seat.huierAnGang.add(outTile);
                genZhuang = false;
                MsgManager.doActionMessage(seat, Choice.CHOICE.HUI_ER_PI_MING_GANG, value, this);
                markScore(seat, SHOW_PAI.HUI_ER_PI_MING_GANG, turnSeat.index);
                // MsgManager.doChoicesMessage(seat, new ArrayList<Choice>(), roomId, true, false);
                // markSeat(seat);
                afterMoPai(seat, false, false);
            } else {
                log.debug(getSeatLogInfo(seat) + " 碰 [" + TileUtil.getTile(value) + "] 失败 -> 优先级");
            }
        }
    }

    protected Choice createChoice(int seatIndex, Choice.CHOICE ch, int value, int priority, int token) {
        Choice choice = new Choice();
        choice.expire = System.currentTimeMillis() + 3600000;
        choice.execute = false;
        choice.has = true;
        choice.pass = false;
        choice.value = value;

        choice.seatIndex = seatIndex;
        choice.choice = ch;
        choice.priority = priority;
        choice.token = token;

        return choice;
    }

    public void afterChuPai(Seat lastSeat, int value) {
        log.debug(getSeatLogInfo(lastSeat) + "当前手牌 " + lastSeat.hand);
        int nextIndex = lastSeat.index == 3 ? 0 : lastSeat.index + 1;
        int distance = 0;
        int checkIndex = nextIndex;
        do {
            distance++;
            Seat seat = seats.get(checkIndex);
            List<Choice> choices = otherCheck(seat, distance, value);
            seat.choices = choices;
            checkIndex = checkIndex == 3 ? 0 : checkIndex + 1;
            this.choices.addAll(choices);
        }
        while (checkIndex != lastSeat.index);
        if (choices.size() > 0) {
            waitChoice = true;
        }
        log.debug("");
        log.debug("轮到下一位" + getSeatLogInfo(seats.get(nextIndex)));
        log.debug("");
        turn(seats.get(nextIndex));
    }

    private List<Choice> otherCheck(Seat seat, int distance, int value) {

        List<Choice> choices = new ArrayList<>();
        int token = getToken();
        seat.choiceToken = token;
        //只能自摸
//        HuPai huPai = TileUtil.checkHuPai(seat, value, baidaValue);
//
//        if (huPai.isHu()) {
//            huPaiCheck(seat, huPai);
//            Choice choice = createChoice(seat.index, Choice.CHOICE.HU, value, distance, token);
//            choices.add(choice);
//            //todo 可胡
//        }
        List<Tile> sources = new ArrayList<>();
        sources.addAll(seat.hand);
//            sources.addAll(seat.peng);
//            sources.addAll(seat.huierAnGang);
//            sources.addAll(seat.huierMingGang);
        if (TileUtil.canGang(sources, value)) {
            Choice choice = createChoice(seat.index, Choice.CHOICE.MING_GANG, value, distance + 3, token);
            choices.add(choice);
            // 可杠
        }
        if (TileUtil.canPeng(seat.hand, value)) {
            Choice choice = null;
            if (value == baidaValue) {
                //todo 会儿皮杠
                choice = createChoice(seat.index, Choice.CHOICE.HUI_ER_PI_MING_GANG, value, distance + 6, token);
            } else {
                //todo 可碰
                choice = createChoice(seat.index, Choice.CHOICE.PENG, value, distance + 6, token);
            }
            choices.add(choice);
        }
        if (choices.size() > 0) {
            log.debug(getSeatLogInfo(seat) + "可选择\n" + choices);
            MsgManager.doChoicesMessage(seat, choices, roomId, false, true, this);
        }
        return choices;
    }

    /**
     * @param seat
     * @param huPai
     * @param targetSeatIndex 自摸传-1
     */
    public void huPai(Seat seat, HuPai huPai, int targetSeatIndex) {
        for (int i = 0; i < seatSize; i++) {
            Seat currentSeat = seats.get(i);
            currentSeat.readyForGame = false;
            currentSeat.state = SEAT_STATE.WAIT_FOR_GAME;
            for (Score score : currentSeat.scores) {
                currentSeat.score += score.getScore();
            }
            if (seat.index == currentSeat.index) {
                continue;
            }
            if (targetSeatIndex > -1 && targetSeatIndex != currentSeat.index) {
                continue;
            }
            int beishu = huPai.getHu().getbeiShu();
            for (HuPai.PAI pai : huPai.getPai()) {
                beishu *= pai.getbeiShu();
            }
            if (seat.index == bankerIndex || currentSeat.index == bankerIndex) {
                beishu <<= 1;//*2
            }
            int finalScore = beishu * baseScore;
            seat.score += finalScore;
            currentSeat.score -= finalScore;

        }
        for (int i = 0; i < seatSize; i++) {
            Seat currentSeat = seats.get(i);
            currentSeat.rounScore += currentSeat.score;
        }

        roomState = ROOM_STATE.READY_NEXT;
        MsgManager.doHuPaiMessage(this);
        finishMahjong(seat);
    }

    public void liuju() {
        for (int i = 0; i < seatSize; i++) {
            Seat currentSeat = seats.get(i);
            currentSeat.readyForGame = false;
            currentSeat.state = SEAT_STATE.WAIT_FOR_GAME;
            for (Score score : currentSeat.scores) {
                currentSeat.score += score.getScore();
            }
        }
        for (int i = 0; i < seatSize; i++) {
            Seat currentSeat = seats.get(i);
            currentSeat.rounScore += currentSeat.score;
        }

        roomState = ROOM_STATE.READY_NEXT;
        MsgManager.doHuPaiMessage(this);
        finishMahjong(seats.get(bankerIndex));

    }

    public void finishMahjong(Seat seat) {
        finalyScore.clear();
        videos.add(currentVideo);
        for (int i = 0; i < seats.size(); i++) {
            Seat currentSeat = seats.get(i);
            PokerData.PBUserScoreInfo scoreInfo = PokerData.PBUserScoreInfo.newBuilder()
                    .setRolePicUrl(currentSeat.player.head)
                    .setNick(currentSeat.player.nick)
                    .setScore(currentSeat.score)
                    .setUid(currentSeat.player.id)
                    .build();
            PokerData.PBRoundResult roundResult = PokerData.PBRoundResult.newBuilder()
                    .setRoundIndex(playedPanShu)
                    .setStamp(currentStartTime)
                    .addScores(scoreInfo)
                    .build();
            roundResults.add(roundResult);
            PokerData.PBUserScoreInfo finallyScore = PokerData.PBUserScoreInfo.newBuilder()
                    .setRolePicUrl(currentSeat.player.head)
                    .setNick(currentSeat.player.nick)
                    .setScore(currentSeat.rounScore)
                    .setUid(currentSeat.player.id)
                    .build();
            this.finalyScore.add(finallyScore);
            currentSeat.clear();
            currentSeat.scores.clear();
        }
        int nextBanker;
        if (seat.index == bankerIndex) {
            nextBanker = bankerIndex;
        } else {
            nextBanker = bankerIndex == 3 ? 0 : bankerIndex + 1;
        }
        if (bankerIndex != nextBanker) {
            changeBankerCount++;
        }
        bankerIndex = nextBanker;
        mahjong.nextTime();
        // MsgManager.doOverRoundMessage(this);
        if (playedPanShu == 1) {
            log.debug("完成第一盘扣除 [" + config.createrId + "] 钻石 [" + config.diamond + "]");
            dataService.userDiamond(config.createrId, config.diamond, config.roomId);
        }
        if (changeBankerCount > 0 && changeBankerCount % 4 == 0 && changeBankerCount >> 2 == round) {
            roomState = ROOM_STATE.ROUND_OVER;

            closeRoom(true, "玩家圈数完成");
        }
    }


    public void chat(Seat seat, PokerMsgCs.CSRequestChat message) {

        log.debug(getSeatLogInfo(seat) + "聊天\n" + message.getMessage() + "\n" + message.getBigFaceChannel() + " " + message.getBigFaceID());
        PokerMsgCs.CSResponseChat chat = PokerMsgCs.CSResponseChat.newBuilder()
                .setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK).build();
        MessageWraper returnMessage = MessageUtil.getMessage();
        returnMessage.putMessage(MessageUtil.getMessageBuilder().setCsResponseChat(chat).build());
        MsgManager.sendMessage(seat.player.id, returnMessage);
        PokerMsgCs.CSNotifyChat.Builder builder = PokerMsgCs.CSNotifyChat.newBuilder()
                .setBigFaceChannel(message.getBigFaceChannel())
                .setCtype(message.getCtype())
                .setBigFaceID(message.getBigFaceID())
                .setUid(seat.player.id)
                .setNick(seat.player.nick);

        if (message.getMessage() != null) {
            builder.setMessage(message.getMessage());
        }

        MessageWraper messageWraper = MessageUtil.getMessage();
        messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsNotifyChat(builder).build());
        channelGroup.writeAndFlush(messageWraper);
    }

    public void interactiveProp(Seat seat, PokerMsgCs.CSRequestSendInteractiveProp message) {
        MsgManager.doInteractiveMessage(seat, this, message);
    }

    public void dissolveRoom(Seat seat, boolean dissolve) {
        ROOM_STATE pre = roomState;
        seat.dissolve = dissolve;
        if (dissolve) {
            this.dissolve.add(seat.index);
        }
        MsgManager.doDissolveMessage(seat, this, pre);
        int onlineSize = 0;
        for (int i = 0; i < seatSize; i++) {
            if (seats.get(i).online) {
                onlineSize++;
            }
        }

        if (this.dissolve.size() >= (onlineSize >> 1)) {
            closeRoom(true, "玩家投票[" + this.dissolve.size() + "]");
        }
    }

    public void exitRoom(Seat seat) {
        if (roomState == ROOM_STATE.READY_START) {

            if (config.createrId == seat.player.id) {
                closeRoom(true, "房间创建者离开房间");
            } else {

                MsgManager.doExitRoomMessage(seat, this);
                seat.player = null;
                playerCount--;
            }
        } else {

            seat.dissolve = true;
            MsgManager.dostartDissolveMessage(seat, this);
        }

    }

    public void closeRoom(boolean dissolve, String message) {

        MsgManager.doOverRoundMessage(this);
        if (dissolve) {
            closeRoom(message);
        }
    }

    @Override
    public void executeOffLine(ChannelHandlerContext ctx) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(ctx.channel());
        if (playerId != null) {
            for (int i = 0; i < seatSize; i++) {
                Seat seat = seats.get(i);
                if (seat.player != null && seat.player.id == playerId) {
                    log.debug(getSeatLogInfo(seat) + "掉线");
                    playerCount--;
                    if (playerCount <= 0) {
                        noPlayerBefore = roomState;
                        roomState = ROOM_STATE.NO_PLAYER;
                        noPlayerTime = System.currentTimeMillis();

                    }
                    seat.online = false;
                    seat.offTime = System.currentTimeMillis();
                    dataService.playerOffline(playerId, LOGOUT_TYPE.OFF_LINE.toString());
                    MsgManager.doChangeConnState(seat, this, false);
                }
            }
        }
    }

    @Override
    public String getOffLineListenerName() {
        return "麻将牌局掉线处理器";
    }


    private String beanName;

    @Override
    public void setBeanName(String s) {

        // log.debug("bean name is "+s);
        beanName = s;
    }

    @PreDestroy
    public void destoryRoom() {
        log.debug("移除房间Java 对象" + roomId);
    }

    public void closeRoom(String message) {

        log.debug("关闭房间 [" + message + "]");
        //  SpringBoot.removeBean(beanName);
        if (finalyScore.size() > 0) {
            log.debug("保存游戏战绩数据");
            try {
                dataService.saveGameRecord(roomId, firstTime, finalyScore, roundResults, videos);
            } catch (Exception e) {
               log.debug("保存战绩数据失败\n"+e.toString());
            }

            // dataService.saveGameRecord(r);
        }

        roomState = ROOM_STATE.CLOSED;
        RoomManager.removeRoom(roomId);
        log.debug("关闭房间完成 ");
        Logger.closeLogger(log);
    }
}
