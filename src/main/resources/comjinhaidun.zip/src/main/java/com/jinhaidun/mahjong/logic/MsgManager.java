package com.jinhaidun.mahjong.logic;


import com.jinhaidun.mahjong.handler.MessageUtil;
import com.jinhaidun.mahjong.handler.MessageWraper;
import com.jinhaidun.mahjong.io.ChannelUtil;
import com.jinhaidun.mahjong.msg.*;
import com.jinhaidun.mahjong.struct.*;
import com.jinhaidun.mahjong.util.DataUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/18.
 */
public class MsgManager {

    public static PokerCommon.ENTableState getTableState(ROOM_STATE state) {
        switch (state) {
            case READY_START:
                return PokerCommon.ENTableState.EN_TABLE_STATE_READY_TO_START;
            case PLAYING:
                return PokerCommon.ENTableState.EN_TABLE_STATE_PLAYING;
            case READY_NEXT:
                return PokerCommon.ENTableState.EN_TABLE_STATE_PLAYING;
        }
        return PokerCommon.ENTableState.EN_TABLE_STATE_PLAYING;
    }


    public static PokerCommon.ENSeatState getTableState(SEAT_STATE state) {

        switch (state) {
            case NO_PLAYER:
                return PokerCommon.ENSeatState.EN_SEAT_STATE_NO_PLAYER;
            case WAIT_FOR_GAME:
                return PokerCommon.ENSeatState.EN_SEAT_STATE_WAIT_FOR_NEXT_ONE_GAME;
            case READY_FOR_GAME:
                return PokerCommon.ENSeatState.EN_SEAT_STATE_READY_FOR_NEXT_ONE_GAME;
            case PLAYING:
                return PokerCommon.ENSeatState.EN_SEAT_STATE_PLAYING;
        }
        return PokerCommon.ENSeatState.EN_SEAT_STATE_NO_PLAYER;
    }

    public static int getActionType(Choice.CHOICE choice) {
        switch (choice) {
            case CHU_PAI:
                return 1;
            case PENG:
                return 4;
            case MING_GANG:
                return 5;
            case AN_GANG:
                return 6;
            case HU:
                return 7;

            case PENG_GANG:
                return 10;
            case PASS:
                return 11;
            case JIA_GANG:
                return 12;

            case SI_XI_FENG:
                return 13;
            case SAN_ZHI_JIAN:
                return 14;
            case HUI_ER_PI_AN_GANG:
                return 15;
            case HUI_ER_PI_MING_GANG:
                return 16;
        }
        return choice.ordinal();
    }

    public static void doEnterMessage(Message data, GameRoom room, Player player, Seat sitSeat) {
        List<PokerMsgBasic.PBTableSeat> tableSeats = getSeatsInfo(room.seats, room.roomId);
        PokerData.PBTableConfig config = PokerData.PBTableConfig.newBuilder()
                .setTtype(PokerCommon.ENTableType.EN_Table_LZMJ)
                .setName("任丘麻将")
                .setHunPai(room.baidaValue)
                .setHunPi(room.huiPiValue)
                .setMeng(room.config.meng)
                .setRound(room.config.round)
                .setScoreLimit(room.config.limit)
                .build();
        //  PokerData.PBTableConfig config = PokerData.PBTableConfig.getDefaultInstance();
        PokerMsgCs.CSNotifyTableInfo.Builder csNotifyTableInfo = PokerMsgCs.CSNotifyTableInfo.newBuilder()
                .addAllSeats(tableSeats).
                        setState(getTableState(room.roomState)).
                        setConf(config)
                .setDealer(room.bankerIndex)
                .setRound(room.round)
                .setLeftTileNum(room.mahjong.currentTiles().size())
                .setOwner(room.config.createrId)
                .setTid(room.roomId)
                .setHunPi(room.huiPiValue)
                .setHunPai(room.baidaValue);
        if (room.turnSeat != null) {
            csNotifyTableInfo.setActionSeatIndex(room.turnSeat.index);
        }
        PokerMsgCs.CSNotifyActionFlow.Builder flow = (PokerMsgCs.CSNotifyActionFlow.Builder) room.contextMap.get(sitSeat.index + "last_action");
        if (flow != null) {
            csNotifyTableInfo.setLastAction(flow);
        }
        MessageWraper messageWraper = MessageUtil.getMessage(data);
        PokerMsgCs.CSResponseEnterTable ok = PokerMsgCs.CSResponseEnterTable.newBuilder().
                setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK).
                setTableInfo(csNotifyTableInfo).
                build();
        messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsResponseEnterTable(ok)
                .build());
        ChannelUtil.getChannel(player.id).writeAndFlush(messageWraper);
        PokerMsgBasic.PBTableSeat pbTableSeat = getSeatInfo(sitSeat, room.roomId);
        MessageWraper mw = MessageUtil.getMessage().putMessage(MessageUtil.getMessageBuilder()
                .setCsNotifySitDown(PokerMsgCs.CSNotifySitDown.newBuilder().setSeat(pbTableSeat))
                .build());

        room.channelGroup.writeAndFlush(mw);
    }

    public static PokerMsgBasic.PBTableSeat getSeatInfo(Seat seat, int roomId) {
        PokerMsgBasic.PBTableSeat.Builder seatBuilder = PokerMsgBasic.PBTableSeat.newBuilder();

        PokerMsgBasic.PBMJAction action = PokerMsgBasic.PBMJAction.newBuilder()
                .setTid(roomId)
                .setSeatid(seat.index)
                .setMeld(PokerMsgBasic.PBMJMeld.newBuilder().addTiles(1).build())
                .build();
        PokerMsgBasic.PBMJActionFlow actionFlow = PokerMsgBasic.PBMJActionFlow.newBuilder()
                .setFlowtoken(seat.choiceToken)
                .setAction(action)
                .build();
        //  seatBuilder.addActionFlows(actionFlow);
        if (seat.player != null) {
            PokerMsgBasic.PBTableUser tableUser = PokerMsgBasic.PBTableUser.newBuilder().
                    setIsOffline(!seat.online)
                    .setUid(seat.player.id)
                    .setNick(seat.player.nick)
                    .setRolePictureUrl(seat.player.head)
                    .build();
            seatBuilder
                    .setUser(tableUser);


        }
        seat.hand.forEach(tile -> seatBuilder.addTilesOnHand(tile.getIntValue()));

        List<PokerMsgBasic.PBMJMeld> melds = new ArrayList<>();
        for (int i = 0; i < seat.peng.size(); i = i + 3) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.peng.get(i).getIntValue(), getActionType(Choice.CHOICE.PENG));
            melds.add(meld);
        }
        for (int i = 0; i < seat.huierMingGang.size(); i = i + 3) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.huierMingGang.get(i).getIntValue(), getActionType(Choice.CHOICE.HUI_ER_PI_MING_GANG));
            melds.add(meld);
        }
        for (int i = 0; i < seat.huierAnGang.size(); i = i + 3) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.huierAnGang.get(i).getIntValue(), getActionType(Choice.CHOICE.HUI_ER_PI_AN_GANG));
            melds.add(meld);
        }
        for (int i = 0; i < seat.sanzhijian.size(); i = i + 3) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.sanzhijian.get(i).getIntValue(), getActionType(Choice.CHOICE.SAN_ZHI_JIAN));
            melds.add(meld);
        }
        for (int i = 0; i < seat.sixifeng.size(); i = i + 4) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.sixifeng.get(i).getIntValue(), getActionType(Choice.CHOICE.SI_XI_FENG));
            melds.add(meld);
        }
        for (int i = 0; i < seat.mingGang.size(); i = i + 4) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.mingGang.get(i).getIntValue(), getActionType(Choice.CHOICE.MING_GANG));
            melds.add(meld);
        }
        for (int i = 0; i < seat.anGang.size(); i = i + 4) {
            PokerMsgBasic.PBMJMeld meld = getMeld(seat, seat.anGang.get(i).getIntValue(), getActionType(Choice.CHOICE.AN_GANG));
            melds.add(meld);
        }
        if (melds.size() > 0) {
            seatBuilder.addAllOutMeld(melds);
        }
        seat.out.forEach(tile -> {

            seatBuilder.addOut(tile.getIntValue());

        });
        seatBuilder.setState(getTableState(seat.state))
                .setIndex(seat.index);
        seatBuilder.setFinalScore(seat.rounScore);
        PokerMsgBasic.PBSeatWinInfo.Builder win = PokerMsgBasic.PBSeatWinInfo.newBuilder();
        win.setScore(seat.score);
        for (Score score : seat.scores) {
            PokerData.PBScoreInfo scoreInfo = PokerData.PBScoreInfo.newBuilder()
                    .setName(score.getPai().toString())
                    .setSeatIndex(score.getSeatIndex())
                    .setTargetSeatIndex(score.getTargetIndex())
                    .setScore(score.getScore()).build();
            win.addScoreInfo(scoreInfo);
        }

        if (seat.huPai != null) {
            win.setHu(true);
            win.setHuValue(seat.huPai.getEndValue());
            if (seat.huPai.getChangeTos() != null) {
                for (Integer to : seat.huPai.getChangeTos()) {
                    PokerData.PBChangeInfo changeInfo = PokerData.PBChangeInfo.newBuilder()
                            .setReally(seat.huPai.getBaida())
                            .setTo(to)
                            .build();
                    win.addChangeInfo(changeInfo);
                }

            }
            for (HuPai.PAI pai : seat.huPai.getPai()) {
                win.addHuInfo(pai.toString());
            }
        }
        return seatBuilder.build();
    }

    public static List<PokerMsgBasic.PBTableSeat> getSeatsInfo(List<Seat> seats, int roomId) {
        List<PokerMsgBasic.PBTableSeat> tableSeats = new ArrayList<>(4);
        for (int i = 0, size = seats.size(); i < size; i++) {
            Seat seat = seats.get(i);
            tableSeats.add(getSeatInfo(seat, roomId));
        }
        return tableSeats;
    }

    public static void doReadForGameMessage(GameRoom room, Seat seat) {
        PokerMsgCs.CSResponseReadyForGame responseReadyForGame = PokerMsgCs.CSResponseReadyForGame.newBuilder().
                setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK)
                .setState(seat.readyForGame).build();
        MessageWraper mw = MessageUtil.getMessage();
        mw.putMessage(MessageUtil.getMessageBuilder().setCsResponseReadyForGame(responseReadyForGame).build());
        sendMessage(seat.player.id, mw);
        MessageWraper messageWraper = MessageUtil.getMessage();
        messageWraper.putMessage(MessageUtil.getMessageBuilder()
                .setCsNotifyReadyForGame(PokerMsgCs.CSNotifyReadyForGame.newBuilder().
                        setSeatIndex(seat.index).setState(seat.readyForGame).build()).build());
        room.channelGroup.writeAndFlush(messageWraper);
    }

    public static void doStarGameMessage(GameRoom room) {
//        Record record=room.currentRecord;
//        record.setDealer(room.bankerIndex);
//        record.setRound(room.playedPanShu);
//        record.setLeftTile(room.mahjong.currentTiles().size());
//        record.setHunPai(room.huiPiValue);
//        record.setHunPai(room.baidaValue);

        List<PokerMsgBasic.PBTableSeat> tableSeats = getSeatsInfo(room.seats, room.roomId);
        room.log.debug("in msg mahjong size is " + room.mahjong.currentTiles().size());
        PokerMsgCs.CSNotifyGameStart gameStart = PokerMsgCs.CSNotifyGameStart.newBuilder().
                setDealer(room.bankerIndex).setRound(room.playedPanShu)
                .setLeftTileNum(room.mahjong.currentTiles().size())
                .setHunPi(room.huiPiValue)
                .setHunPai(room.baidaValue)
                .addAllSeats(tableSeats).build();
        MessageWraper messageWraper = MessageUtil.getMessage().putMessage(MessageUtil.getMessageBuilder().
                setCsNotifyGameStart(gameStart).build());
       // record.setStart(tableSeats);
        room.channelGroup.writeAndFlush(messageWraper);


        Video video=room.currentVideo;
        String start = DataUtil.byte2Str(gameStart.toByteArray());
        video.setStart(start);
        PokerData.PBTableConfig config = PokerData.PBTableConfig.newBuilder()
                .setTtype(PokerCommon.ENTableType.EN_Table_LZMJ)
                .setName("任丘麻将")
                .setHunPai(room.baidaValue)
                .setHunPi(room.huiPiValue)
                .setMeng(room.config.meng)
                .setRound(room.config.round)
                .setScoreLimit(room.config.limit)
                .build();
        video.setConfig(DataUtil.byte2Str(config.toByteArray()));

    }

    public static void doMoPaiMessage(Seat seat, int value, GameRoom room) {


        PokerMsgCs.CSNotifyPlayerDealMJ mj = PokerMsgCs.CSNotifyPlayerDealMJ.newBuilder().setIndex(seat.index).setValue(value).build();
        MessageWraper messageWraper = MessageUtil.getMessage().putMessage(MessageUtil.getMessageBuilder().setCsNotifyPlayerDealMj(mj).build());
        //sendMessage(seat.player.id, messageWraper);

        PokerMsgBasic.PBMJActionFlow flow = PokerMsgBasic.PBMJActionFlow
                .newBuilder().setAction(getMJAction(seat, value, 2, room.roomId)).build();
        String key = seat.index + "last_action_flow";
        room.contextMap.put(key, flow);
        room.channelGroup.writeAndFlush(messageWraper);
        Video video=room.currentVideo;
        video.getActions().add(DataUtil.byte2Str(flow.getAction().toByteArray()));
    }


    public static PokerMsgBasic.PBMJMeld getMeld(Seat seat, int value, int atype) {
        PokerMsgBasic.PBMJMeld.Builder builder = PokerMsgBasic.PBMJMeld.newBuilder().
                setActAfterGang(!seat.turnMoPai)
                .setAtype(atype)
                .setRealTile(value);
        List<Integer> values = new ArrayList<>();
        switch (atype) {
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_CHUPAI_VALUE:
                values.add(value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_PENGGANG_VALUE:
                builder.setIsPenggang(true);

                values.add(value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_JIA_GANG_VALUE:
                values.add(value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_GANG_VALUE:
                values.add(value);
                values.add(value);
                values.add(value);

                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_ANGANG_VALUE:
                values.add(value);
                values.add(value);
                values.add(value);
                values.add(value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_SI_XI_FENG_VALUE:
                values.add(31);
                values.add(32);
                values.add(33);
                values.add(34);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_SAN_ZHI_JIAN_VALUE:
                values.add(41);
                values.add(42);
                values.add(43);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_HUI_ER_PI_AN_GANG_VALUE:
                values.add(value);
                values.add(value);
                values.add(value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_PENG_VALUE:
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_HUI_ER_PI_MING_GANG_VALUE:
                values.add(value);
                values.add(value);
                break;
            case PokerCommon.ENMJActionType.EN_MJ_ACTION_HUPAI_VALUE:
                break;
            default:
                values.add(value);

        }
        builder.addAllTiles(values);
        return builder.build();
    }

    public static PokerMsgBasic.PBMJAction getMJAction(Seat seat, int value, int atype, int roomId) {

        return PokerMsgBasic.PBMJAction.newBuilder()
                .setMeld(getMeld(seat, value, atype))
                .setSeatid(seat.index)
                .setTid(roomId)
                .build();

    }

    public static void doChuPaiMessage(Seat seat, int value, GameRoom room) {
        doActionMessage(seat, Choice.CHOICE.CHU_PAI, value, room);
    }

    public static void doActionMessage(Seat seat, Choice.CHOICE choice, int value, GameRoom room) {

        PokerMsgBasic.PBMJAction action = getMJAction(seat, value, getActionType(choice), room.roomId);
        PokerMsgCs.CSResponseDoAction ms = PokerMsgCs.CSResponseDoAction.newBuilder().
                setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK)
                .setAction(action).build();
        MessageWraper messageWraper = MessageUtil.getMessage();
        messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsResponseDoAction(ms).build());
        sendMessage(seat.player.id, messageWraper);

        PokerMsgBasic.PBMJActionFlow thisFlow = PokerMsgBasic.PBMJActionFlow.newBuilder()
                .setAction(action)
                .setFlowtoken(seat.choiceToken).build();
        room.contextMap.put(seat.index + "last_action_flow", thisFlow);
        for (Seat s : room.seats) {
            PokerMsgCs.CSNotifyActionFlow.Builder builder = PokerMsgCs.CSNotifyActionFlow.newBuilder();
            builder.setNewActionFlow(thisFlow);
            String key = s.index + "last_action_flow";
            PokerMsgBasic.PBMJActionFlow last = (PokerMsgBasic.PBMJActionFlow) room.contextMap.get(key);
            if (last != null) {
                builder.setPreActionFlow(last);
            }
            room.contextMap.put(seat.index + "last_action", builder);
            MessageWraper mw = MessageUtil.getMessage();
            mw.putMessage(MessageUtil.getMessageBuilder().setCsNotifyActionFlow(builder).build());
            sendMessage(s.player.id, mw);
        }

        Video video=room.currentVideo;
        room.log.debug("action to str start");
        byte [] data=action.toByteArray();
        room.log.debug(data.length+",=========================");
        video.getActions().add(DataUtil.byte2Str(data));
        room.log.debug("action to str end");
    }

    public static void doChoicesMessage(Seat seat, List<Choice> choices, int roomId, boolean haveChuPai, boolean havePass, GameRoom room) {
        doChoicesMessage(seat, choices, roomId, haveChuPai, havePass, room, false);
    }

    public static void doChoicesMessage(Seat seat, List<Choice> choices, int roomId, boolean haveChuPai, boolean havePass,
                                        GameRoom room, boolean last) {
        int token = seat.choiceToken;
        List<PokerMsgBasic.PBMJAction> actions = new ArrayList<>();
        for (Choice choice : choices) {
            PokerMsgBasic.PBMJAction action = getMJAction(seat, choice.value, getActionType(choice.choice), roomId);
            actions.add(action);
        }
        if (haveChuPai) {
            PokerMsgBasic.PBMJAction action = getMJAction(seat, 0, getActionType(Choice.CHOICE.CHU_PAI), roomId);
            actions.add(action);
        }
        if (havePass) {
            PokerMsgBasic.PBMJAction pass = getMJAction(seat, 0, getActionType(Choice.CHOICE.PASS), roomId);
            actions.add(pass);
        }
        PokerMsgCs.CSNotifySeatOperationChoice.Builder cb = PokerMsgCs.CSNotifySeatOperationChoice.newBuilder();
        cb.setActionToken(token);
        cb.addAllChoices(actions);
        MessageWraper messageWraper = MessageUtil.getMessage();
        messageWraper.putMessage(MessageUtil.getMessageBuilder().setCsNotifySeatOperationChoice(cb).build());
        sendMessage(seat.player.id, messageWraper);

    }

    public static void doChangeConnState(Seat seat, GameRoom room, boolean online) {

        PokerMsgCs.CSNOtifyPlayerConnectionState state = PokerMsgCs.CSNOtifyPlayerConnectionState.newBuilder()
                .setConnectionState(online ? 1 : 0)
                .setSeatIndex(seat.index).build();
        MessageWraper messageWraper = MessageUtil.getMessage();

        messageWraper.putMessage(MessageUtil.getMessageBuilder().
                setCsNotifyPlayerConnectionState(state).build());
        room.channelGroup.writeAndFlush(messageWraper);

    }

    public static void doHuPaiMessage(GameRoom room) {
        PokerMsgCs.CSNotifyGameOver.Builder builder = PokerMsgCs.CSNotifyGameOver.newBuilder();
        builder.addAllSeats(getSeatsInfo(room.seats, room.roomId));
        List<PokerData.PBUserScoreInfo> scoreInfos = new ArrayList<>();
        for (Seat seat : room.seats) {
            PokerData.PBUserScoreInfo scoreInfo = PokerData.PBUserScoreInfo.newBuilder()
                    .setUid(seat.player.id)
                    .setScore(seat.score)
                    .setNick(seat.player.nick)
                    .setRolePicUrl(seat.player.head)
                    .build();
            scoreInfos.add(scoreInfo);

        }
        builder.addAllFinalUserScores(scoreInfos);

        MessageWraper messageWraper = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsNotifyGameOver(builder).build());
        room.channelGroup.writeAndFlush(messageWraper);

        Video video=room.currentVideo;
        video.setOver(DataUtil.byte2Str(builder.build().toByteArray()));

    }

    public static void doOverRoundMessage(GameRoom room) {

        PokerMsgCs.CSNotifyDissolveTable.Builder table = PokerMsgCs.CSNotifyDissolveTable.newBuilder();
        if (room.playedPanShu > 0) {
            table.setTime(room.firstTime);

            table.setRoomId(room.roomId);
            List<PokerData.PBUserScoreInfo> scoreInfos = new ArrayList<>();
            List<Integer> bigWin = new ArrayList<>();
            int win = 0;
            for (Seat seat : room.seats) {
                PokerData.PBUserScoreInfo scoreInfo = PokerData.PBUserScoreInfo.newBuilder()
                        .setUid(seat.player.id)
                        .setScore(seat.rounScore)
                        .setNick(seat.player.nick)
                        .setRolePicUrl(seat.player.head)
                        .build();
                if (win < seat.rounScore) {
                    win = seat.rounScore;
                    bigWin.clear();
                    bigWin.add(seat.rounScore);
                } else if (win == seat.rounScore) {
                    bigWin.add(seat.rounScore);
                }

                scoreInfos.add(scoreInfo);
            }
            table.addAllBigWin(bigWin);
            table.addAllScores(scoreInfos);
        }
        MessageWraper messageWraper = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsNotifyDissolveTable(table).build());
        room.channelGroup.writeAndFlush(messageWraper);
    }

    public static void doInteractiveMessage(Seat seat, GameRoom room, PokerMsgCs.CSRequestSendInteractiveProp message) {

        PokerMsgCs.CSResponseSendInteractiveProp resp = PokerMsgCs.CSResponseSendInteractiveProp.newBuilder()
                .setPrice(0)
                .setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK)
                .build();
        MessageWraper respMessage = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsResponseSendInteractiveProp(resp).build());
        sendMessage(seat.player.id, respMessage);
        PokerMsgCs.CSNotifyInteractionMessage notifyMessage = PokerMsgCs.CSNotifyInteractionMessage.newBuilder()
                .setDestinaionIndex(message.getDestinaionIndex())
                .setInteractionId(message.getInteractionId())
                .setSourceIndex(seat.index)
                .build();
        MessageWraper notify = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsNotifyInteractionMessage(notifyMessage).build());
        room.channelGroup.writeAndFlush(notify);


    }

    public static void doDissolveMessage(Seat seat, GameRoom room, ROOM_STATE pre) {
        PokerMsgCs.CSResponseDissolveTable dissolveTable =
                PokerMsgCs.CSResponseDissolveTable.newBuilder()
                        .setResult(PokerCommon.ENMessageError.EN_MESSAGE_ERROR_OK)
                        .setUid(seat.player.id)
                        .setState(seat.dissolve)
                        .build();
        MessageWraper messageWraper
                = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsResponseDissolveTable(dissolveTable).build());
        // sendMessage(seat.player.id, messageWraper);
        room.channelGroup.writeAndFlush(messageWraper);
        int first = room.dissolve.iterator().next();
        List<Long> agree = new ArrayList<>();
        room.dissolve.forEach(integer -> agree.add(Long.valueOf(integer)));
        PokerMsgBasic.PBDissolveInfo dissolveInfo = PokerMsgBasic.PBDissolveInfo.
                newBuilder()
                .setPreState(getTableState(pre))
                .setStartUid(first)
                .addAllAgreeUidList(agree)
                .build();
        PokerMsgCs.CSNotifyDissolveTableOperation operation = PokerMsgCs.CSNotifyDissolveTableOperation.
                newBuilder()
                .setDissolveInfo(dissolveInfo)
                .setUid(seat.player.id)
                .setVoteDown(!seat.dissolve)
                .build();
        MessageWraper mw = MessageUtil
                .getMessage().putMessage(
                        MessageUtil.getMessageBuilder()
                                .setCsNotifyDissolveTableOperation(operation)
                                .build()
                );
        //  room.channelGroup.writeAndFlush(mw);


    }

    public static void dostartDissolveMessage(Seat seat, GameRoom room) {
        PokerMsgCs.CSNotifyDissolveTableOperation.Builder operation = PokerMsgCs.CSNotifyDissolveTableOperation.
                newBuilder();
        PokerMsgBasic.PBDissolveInfo start = PokerMsgBasic.PBDissolveInfo.newBuilder()
                .setUid(seat.player.id)
                .setNick(seat.player.nick)
                .setState(true)
                .build();
        operation.setStart(start);
        for (Seat s : room.seats) {
            if (s.index == seat.index) {
                continue;
            }
            operation.addOther(PokerMsgBasic.PBDissolveInfo.newBuilder()
                    .setUid(s.player.id)
                    .setNick(s.player.nick)
                    .setState(s.dissolve)
                    .build());
        }

        MessageWraper messageWraper = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsNotifyDissolveTableOperation(operation).build());
        room.channelGroup.writeAndFlush(messageWraper);
    }

    public static void doExitRoomMessage(Seat seat, GameRoom room) {
        PokerMsgCs.CSNotifyDissolveTable table = PokerMsgCs.CSNotifyDissolveTable.getDefaultInstance();

        MessageWraper messageWraper = MessageUtil.getMessage()
                .putMessage(MessageUtil.getMessageBuilder().setCsNotifyDissolveTable(table).build());
        sendMessage(seat.player.id, messageWraper);

        PokerMsgBasic.PBTableSeat pbTableSeat = getSeatInfo(seat, room.roomId);
        MessageWraper mw = MessageUtil.getMessage().putMessage(MessageUtil.getMessageBuilder()
                .setCsNotifySitDown(PokerMsgCs.CSNotifySitDown.newBuilder().setSeat(pbTableSeat))
                .build());

        room.channelGroup.writeAndFlush(mw);

    }

    public static void sendMessage(int playerId, Message message) {
        io.netty.channel.Channel channel = ChannelUtil.getChannel(playerId);
        if (channel != null) {
            channel.writeAndFlush(message);
        }


    }
}
