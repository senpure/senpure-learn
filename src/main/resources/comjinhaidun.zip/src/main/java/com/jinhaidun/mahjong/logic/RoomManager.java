package com.jinhaidun.mahjong.logic;


import com.jinhaidun.mahjong.struct.ROOM_STATE;
import com.jinhaidun.store.scheduler.SchedulerSupport;
import com.senpure.base.util.RandomUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by 罗中正 on 2017/4/5.
 */
@Component
public class RoomManager extends SchedulerSupport {


    private static Map<Integer, GameRoom> rooms = new ConcurrentHashMap<>();

    public static void addRoom(GameRoom room) {
        rooms.putIfAbsent(room.getRoomId(), room);
    }

    public static void removeRoom(int roomId) {
        rooms.remove(roomId);
        EasyRoomManager.back(roomId);
    }

    public static int getRoomId() {
        int roomId = EasyRoomManager.getRoomId();
        if (roomId == 0) {
            roomId = RandomUtil.random(600000, 1000000);
        }
        while (getRoom(roomId) != null) {
            roomId = RandomUtil.random(600000, 1000000);
        }
        return roomId;
    }

    public static GameRoom getRoom(Integer roomId) {
        return rooms.get(roomId);
    }

    public static long NO_PLAYER_TIME = 1000 * 60 * 5;

    @Scheduled(cron = "0/30 * *  * * ? ")
    public void closeRoom() {
        //  List<Integer> removes=new ArrayList<>();
        rooms.forEach((roomId, room) -> {
            try {
                if (room.roomState == ROOM_STATE.NO_PLAYER) {
                    if (System.currentTimeMillis() - room.noPlayerTime > NO_PLAYER_TIME) {
                        log.debug("房间{}没有玩家超过{}秒，关闭房间", roomId, NO_PLAYER_TIME / 1000);
                        room.closeRoom("房间没有玩家 [" + NO_PLAYER_TIME / 1000 + "秒]");
                        // rooms.remove(roomId);
                    }
                } else if (room.roomState == ROOM_STATE.READY_START) {
                    if (room.playerCount == 0) {
                        if (System.currentTimeMillis() - room.noPlayerTime > NO_PLAYER_TIME) {
                            log.debug("房间{}没有玩家超过{}秒，关闭房间", roomId, NO_PLAYER_TIME / 1000);
                            room.closeRoom("房间创建后没有玩家 [" + NO_PLAYER_TIME / 1000 + "秒]");
                            //rooms.remove(roomId);
                        }
                    }
                }
            } catch (Exception e) {
                log.error(e,e);
            }
        });


    }


    public static void main(String[] args) {

    }
}
