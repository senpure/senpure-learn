package com.jinhaidun.mahjong.model;

/**
 * Created by 罗中正 on 2017/4/10.
 */
public class Action {

    public  static  String ACTION_MO_PAI="MO_PAI";
    public  static  String ACTION_CHU_PAI="CHU_PAI";
    public  static  String ACTION_PENG="PENG";
    public  static  String ACTION_MING_GANG="MING_GANG";
    public  static  String ACTION_AN_GANG="AN_GANG";

    private String name;
    private int value;
    private int realValue;
    private int seatIndex;
    private int targetSeatIndex;
    private boolean online;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getSeatIndex() {
        return seatIndex;
    }

    public void setSeatIndex(int seatIndex) {
        this.seatIndex = seatIndex;
    }

    public int getRealValue() {
        return realValue;
    }

    public void setRealValue(int realValue) {
        this.realValue = realValue;
    }

    public int getTargetSeatIndex() {
        return targetSeatIndex;
    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public void setTargetSeatIndex(int targetSeatIndex) {
        this.targetSeatIndex = targetSeatIndex;
    }
}
