package com.jinhaidun.mahjong.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/14.
 */
public class ActionFlow {

    public  int flowToken;
    public List<Action> actions=new ArrayList<>();
}
