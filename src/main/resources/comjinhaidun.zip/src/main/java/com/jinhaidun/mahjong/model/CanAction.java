package com.jinhaidun.mahjong.model;

/**
 * Created by 罗中正 on 2017/4/13.
 */
public class CanAction {

    public static enum TYPE {
        PASS,
        HU,
        AN_GANG,
        MING_GANG,
        PENG,
        FENG,
        JIAN,

    }

    public TYPE type;
    public int value;

}
