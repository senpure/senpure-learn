package com.jinhaidun.mahjong.model;

/**
 * Created by 罗中正 on 2017/4/12.
 */
public class ChangeTo {

    public int changeTo;
}
