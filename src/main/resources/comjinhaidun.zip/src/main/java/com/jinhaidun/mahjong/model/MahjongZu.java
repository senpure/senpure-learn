package com.jinhaidun.mahjong.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/12.
 */
public class MahjongZu {

    public static MahjongZu getInstance(List<Integer> tiles) {
        MahjongZu zu = new
                MahjongZu();
        for (int i = 0, size = tiles.size(); i < size; i++) {
            Integer tile = tiles.get(i);
            if (tile.intValue() < 10) {
                zu.tong.add(tile);
            } else if (tile.intValue() < 20) {
                zu.tiao.add(tile);
            } else if (tile.intValue() < 30) {
                zu.wan.add(tile);
            } else if (tile.intValue() < 40) {
                zu.feng.add(tile);
            } else if (tile.intValue() < 50) {
                zu.jian.add(tile);
            }
        }
        return zu;
    }

    public List<Integer> tong = new ArrayList<>();
    public List<Integer> tiao = new ArrayList<>();
    public List<Integer> wan = new ArrayList<>();
    public List<Integer> feng = new ArrayList<>();
    public List<Integer> jian = new ArrayList<>();


}
