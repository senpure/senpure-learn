package com.jinhaidun.mahjong.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/13.
 */
public class OneGame {

    private int baida;
   private  List<Seat> seats;

   private  List<Action> actions=new ArrayList<>();

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }

    public List<Action> getActions() {
        return actions;
    }

    public void setActions(List<Action> actions) {
        this.actions = actions;
    }

    public int getBaida() {
        return baida;
    }

    public void setBaida(int baida) {
        this.baida = baida;
    }
}
