package com.jinhaidun.mahjong.model;

/**
 * Created by 罗中正 on 2017/4/5.
 */
public class Peng {


}
