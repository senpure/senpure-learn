package com.jinhaidun.mahjong.model;

import com.jinhaidun.mahjong.struct.Choice;
import com.jinhaidun.mahjong.struct.Tile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/4/5.
 */
public class Player {
    private int id;
    private String ip;
    private String nick;
    private String head;
    private boolean banker;
    private int seatIndex = -1;
    private int moPaiValue;
    private Choice choice;

   // 统计杠上开花
    private int lianxuGang;
    //开杠不算
    private int moPaiCount;
    private List<Tile> hand = new ArrayList<>();
    //三个一组
    private List<Tile> peng = new ArrayList<>();
    private List<Tile> mingGang = new ArrayList<>();
    private List<Tile> anGang = new ArrayList<>();

    private List<Tile> huierMingGang= new ArrayList<>();
    private List<Tile> huierAnGang= new ArrayList<>();

    private List<Tile> sanzhijian = new ArrayList<>();
    private List<Tile> sixifeng = new ArrayList<>();
    private Map<String ,Integer> ignore=new HashMap<>();
    //打出的牌
    private List<Tile> out = new ArrayList<>();
    private List<Action> action = new ArrayList<>();

    public void clear() {
        hand.clear();
        peng.clear();
        mingGang.clear();
        anGang.clear();
        action.clear();
        sanzhijian.clear();
        sixifeng.clear();
        ignore.clear();
        moPaiCount = 0;
        moPaiValue=0;
    }

    public void moPaiCountIncr() {
        moPaiCount++;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public boolean isBanker() {
        return banker;
    }

    public void setBanker(boolean banker) {
        this.banker = banker;
    }

    public List<Tile> getHand() {
        return hand;
    }

    public void setHand(List<Tile> hand) {
        this.hand = hand;
    }

    public List<Tile> getPeng() {
        return peng;
    }

    public void setPeng(List<Tile> peng) {
        this.peng = peng;
    }

    public List<Tile> getMingGang() {
        return mingGang;
    }

    public void setMingGang(List<Tile> mingGang) {
        this.mingGang = mingGang;
    }

    public List<Tile> getAnGang() {
        return anGang;
    }

    public void setAnGang(List<Tile> anGang) {
        this.anGang = anGang;
    }

    public List<Tile> getOut() {
        return out;
    }

    public void setOut(List<Tile> out) {
        this.out = out;
    }

    public List<Action> getAction() {
        return action;
    }

    public void setAction(List<Action> action) {
        this.action = action;
    }

    public int getSeatIndex() {
        return seatIndex;
    }

    public void setSeatIndex(int seatIndex) {
        this.seatIndex = seatIndex;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public int getMoPaiValue() {
        return moPaiValue;
    }

    public void setMoPaiValue(int moPaiValue) {
        this.moPaiValue = moPaiValue;
    }

    public int getMoPaiCount() {
        return moPaiCount;
    }

    public void setMoPaiCount(int moPaiCount) {
        this.moPaiCount = moPaiCount;
    }

    public List<Tile> getHuierMingGang() {
        return huierMingGang;
    }

    public void setHuierMingGang(List<Tile> huierMingGang) {
        this.huierMingGang = huierMingGang;
    }

    public List<Tile> getHuierAnGang() {
        return huierAnGang;
    }

    public void setHuierAnGang(List<Tile> huierAnGang) {
        this.huierAnGang = huierAnGang;
    }

    public int getLianxuGang() {
        return lianxuGang;
    }

    public void setLianxuGang(int lianxuGang) {
        this.lianxuGang = lianxuGang;
    }

    public List<Tile> getSanzhijian() {
        return sanzhijian;
    }

    public void setSanzhijian(List<Tile> sanzhijian) {
        this.sanzhijian = sanzhijian;
    }

    public List<Tile> getSixifeng() {
        return sixifeng;
    }

    public void setSixifeng(List<Tile> sixifeng) {
        this.sixifeng = sixifeng;
    }

    public Map<String, Integer> getIgnore() {
        return ignore;
    }

    public void setIgnore(Map<String, Integer> ignore) {
        this.ignore = ignore;
    }

    public Choice getChoice() {
        return choice;
    }

    public void setChoice(Choice choice) {
        this.choice = choice;
    }
}
