package com.jinhaidun.mahjong.model;

/**
 * Created by 罗中正 on 2017/4/7.
 */
public class Seat {
    public int index;
    public Player player;
    public boolean online;
    public boolean banker;


}
