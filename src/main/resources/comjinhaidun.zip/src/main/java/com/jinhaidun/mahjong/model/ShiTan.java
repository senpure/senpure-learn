package com.jinhaidun.mahjong.model;

/**
 * Created by 罗中正 on 2017/4/12.
 */
public class ShiTan {

    public boolean success;
    public int use;
    public int change;
}
