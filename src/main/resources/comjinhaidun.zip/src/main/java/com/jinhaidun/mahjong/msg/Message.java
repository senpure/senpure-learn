package com.jinhaidun.mahjong.msg;

/**
 * Created by 罗中正 on 2017/4/6.
 */
public class Message {

  private  PokerMsg.PBHead head;
  private  PokerMsg.PBCSMsg message;

    public PokerMsg.PBHead getHead() {
        return head;
    }

    public void setHead(PokerMsg.PBHead head) {
        this.head = head;
    }

    public PokerMsg.PBCSMsg getMessage() {
        return message;
    }

    public void setMessage(PokerMsg.PBCSMsg message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "Message{\n" +
                "head=" + head +
                "message=" + message +
                '}';
    }
}
