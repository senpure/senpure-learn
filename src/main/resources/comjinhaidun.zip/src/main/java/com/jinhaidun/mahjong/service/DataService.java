package com.jinhaidun.mahjong.service;

import com.jinhaidun.mahjong.msg.PokerData;
import com.jinhaidun.mahjong.struct.Player;
import com.jinhaidun.mahjong.struct.Video;

import java.util.List;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/4/20.
 */
public interface DataService {

    Player playerLogin(String token,Map<String,Object> context);
    void updatePlayerRoom(int playerId,int roomId);
    void  playerOffline(int playerId,String type);
    void saveGameRecord(int roomId,long firstTime,List<PokerData.PBUserScoreInfo> finallyScore, List<PokerData.PBRoundResult> roundResults, List<Video> videos);

    int playerDiamond(int playerId);
   void userDiamond(int playerId,int diamond,int roomId);
    List<PokerData.PBGameRecord> loadGameRecord(int playerId);
    Video loadVideo(long recordId,int index);
}
