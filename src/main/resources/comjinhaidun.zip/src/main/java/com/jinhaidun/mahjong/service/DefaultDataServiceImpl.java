package com.jinhaidun.mahjong.service;

import com.alibaba.fastjson.JSON;
import com.google.protobuf.InvalidProtocolBufferException;
import com.jinhaidun.AppConstant;
import com.jinhaidun.mahjong.msg.PokerData;
import com.jinhaidun.mahjong.struct.Player;
import com.jinhaidun.mahjong.struct.Video;
import com.jinhaidun.store.criterion.RoundResultCriteria;
import com.jinhaidun.store.entity.PlayerRoundResult;
import com.jinhaidun.store.entity.RoundResult;
import com.jinhaidun.store.service.DiamondService;
import com.jinhaidun.store.service.GameRecordService;
import com.jinhaidun.store.service.PlayerService;
import com.jinhaidun.store.vo.PlayerVo;
import com.jinhaidun.store.vo.RoundResultVo;
import com.jinhaidun.store.vo.VideoVo;
import com.senpure.base.util.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/4/25.
 */
@Service

public class DefaultDataServiceImpl implements DataService {
    protected Logger logger = LogManager.getLogger(DefaultDataServiceImpl.class);
    @Autowired
    private PlayerService playerService;
    @Autowired
    private GameRecordService recordService;

    @Autowired
    private DiamondService diamondService;

    @Override
    public Player playerLogin(String token, Map<String, Object> context) {
        PlayerVo vo = playerService.playerLogin(token, context);
        if (vo != null) {
            Player player = new Player();
            player.id = vo.getId();
            player.nick = vo.getNick();
            player.head = vo.getHead();
            player.roomId = vo.getRoomId();
            player.diamond=vo.getDiamond();
            return player;

        }
        return null;
    }

    @Override
    public void updatePlayerRoom(int playerId, int roomId) {
        PlayerVo vo = new PlayerVo();
        vo.setId(playerId);
        vo.setRoomId(roomId);
        playerService.updatePlayer(vo);

    }


    @Override
    public void playerOffline(int playerId, String type) {
        PlayerVo vo = new PlayerVo();
        vo.setId(playerId);
        vo.setOnline(false);
        Date now = new Date();
        vo.setLogoutDate(now);
        vo.setLogoutTime(now.getTime());
        vo.setLogoutType(type);
        playerService.updatePlayer(vo);

    }

    @Override
    public void saveGameRecord(int roomId, long firstTime, List<PokerData.PBUserScoreInfo> finallyScore, List<PokerData.PBRoundResult> roundResults, List<Video> videos) {


        RoundResult roundResult = new RoundResult();
        String date = AppConstant.DFM_COMPACT.format(new Date(firstTime));
        date += roomId;

        List<String> fsStr = new ArrayList<>();
        finallyScore.forEach(s -> {
            fsStr.add(Base64.encode(s.toByteArray()));
        });
        List<String> dsStr = new ArrayList<>();
        roundResults.forEach(r ->
                dsStr.add(Base64.encode(r.toByteArray()))
        );
        String fs = JSON.toJSONString(fsStr);

        String ds = JSON.toJSONString(dsStr);

        logger.debug("fs length {} ,ds length {}", fs.length(), ds.length());
        long recordId=Long.parseLong(date);
        roundResult.setRecordId(recordId);
        long now = System.currentTimeMillis();
        roundResult.setCreateTime(now);
        roundResult.setCreateDate(new Date(now));
        roundResult.setRoomId(roomId);
        roundResult.setFinallyScore(fs);
        roundResult.setDeatilScore(ds);
        List<PlayerRoundResult> playerRoundResults = new ArrayList<>();
        for (PokerData.PBUserScoreInfo scoreInfo : finallyScore) {
            PlayerRoundResult playerRoundResult = new PlayerRoundResult();
            playerRoundResult.setPlayerId((int) scoreInfo.getUid());
            playerRoundResult.setRoundResult(roundResult);
            playerRoundResults.add(playerRoundResult);
        }
        List<com.jinhaidun.store.entity.Video> videoList = new ArrayList<>();
        for (Video video : videos) {
            video.setRecordId(recordId);
            com.jinhaidun.store.entity.Video videoEntity = new com.jinhaidun.store.entity.Video();
            videoEntity.setRecordId(recordId);
            videoEntity.setRoundIndex(video.getIndex());

           String data=  JSON.toJSONString(video);
            logger.debug("data lengt {}",data.length());
           videoEntity.setData(data);
            videoList.add(videoEntity);
        }

        recordService.savePlayerRecord(playerRoundResults,videoList);
    }

    @Override
    public int playerDiamond(int playerId) {
       PlayerVo playerVo= playerService.loadPlayer(playerId);
        return playerVo.getDiamond();
    }

    @Override
    public void userDiamond(int playerId, int diamond,int roomId) {

        diamondService.useDiamon(playerId, diamond, roomId);

    }

    @Override
    public List<PokerData.PBGameRecord> loadGameRecord(int playerId) {

        RoundResultCriteria criteria = new RoundResultCriteria();
        criteria.setPlayerId(playerId);

        logger.debug("playerId {}", playerId);

        List<RoundResultVo> list = recordService.loadRoundResult(criteria);
        logger.debug("list is {}", list);
        List<PokerData.PBGameRecord> recordlist = new ArrayList<>();
        list.forEach(vo -> {

            PokerData.PBGameRecord.Builder record = PokerData.PBGameRecord.newBuilder();
            record.setRecordid(""+vo.getRecordId());
            record.setStamp(vo.getCreateTime());
            record.setTid(vo.getRoomId());
            List<PokerData.PBUserScoreInfo> scoreInfo = new ArrayList<>();
            List<PokerData.PBRoundResult> scoreInfo2 = new ArrayList<>();
            List<String> fslist = JSON.parseObject(vo.getFinallyScore(), List.class);
            List<String> dslist = JSON.parseObject(vo.getDeatilScore(), List.class);
            fslist.forEach(s -> {
                        try {
                            scoreInfo.add(PokerData.PBUserScoreInfo.parseFrom(Base64.decode(s)));
                        } catch (InvalidProtocolBufferException e) {
                            e.printStackTrace();
                        }

                    }
            );
            dslist.forEach(s -> {
                        try {
                            scoreInfo2.add(PokerData.PBRoundResult.parseFrom(Base64.decode(s)));
                        } catch (InvalidProtocolBufferException e) {
                            e.printStackTrace();
                        }
                    }

            );

            record.addAllFinalUserScores(scoreInfo);
            record.addAllRoundResults(scoreInfo2);
            recordlist.add(record.build());

        });
        return recordlist;
    }

    public Video loadVideo(long recordId,int index)
    {

       // logger.debug("date service11111111111111");
      VideoVo videoVo=  recordService.loadVideo(recordId, index);
      if(videoVo==null)
      {
          return null;
      }
       // logger.debug("date service22222222222");
      Video video= JSON.parseObject(videoVo.getData(),Video.class);
       // logger.debug("date service333333333333333333");
      return  video;
    }

    public static void main(String[] args) throws InvalidProtocolBufferException {
        List<PokerData.PBUserScoreInfo> scoreInfos = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            PokerData.PBUserScoreInfo scoreInfo = PokerData.PBUserScoreInfo.newBuilder()
                    .setUid(123 + i)
                    .setNick("nick").build();
            scoreInfos.add(scoreInfo);
        }


        List<String> strs = new ArrayList<>();

        scoreInfos.forEach(s ->

                strs.add(Base64.encode(s.toByteArray()))
        );
        String json = JSON.toJSONString(strs);
        System.out.println(scoreInfos);
        System.out.println(json);
        List<String> stringList = JSON.parseObject(json, List.class);

        System.out.println(stringList);
        stringList.forEach((String s) -> {
            try {
                System.out.println(PokerData.PBUserScoreInfo.parseFrom(Base64.decode(s)));
            } catch (InvalidProtocolBufferException e) {
                e.printStackTrace();
            }
        });
        //String str= "CHsSBG5pY2s=";
        // System.out.println( PokerData.PBUserScoreInfo.parseFrom(Base64.decode(str)));

    }

}
