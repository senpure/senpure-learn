package com.jinhaidun.mahjong.struct;

import com.jinhaidun.mahjong.Mahjong;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public class AbsMahjong implements Mahjong {
    List<Tile> tiles;
    private List<Tile> removes = new LinkedList<>();

    @Override
    public Tile getTile() {
        return getTiles(1).get(0);
    }

    @Override
    public List<Tile> getTiles(int count) {
        List<Tile> ct = new ArrayList<>(count);
        for (int j = 0; j < count; ) {
            Tile tile = tiles.remove(0);
            ct.add(tile);
            removes.add(tile);
            j++;
        }
        return ct;

    }

    public Tile getTile(int value) {
        for (int i = 0; i < tiles.size(); i++) {
            if (tiles.get(i).getIntValue() == value) {
                Tile tile = tiles.remove(i);
                removes.add(tile);
                return tile;
            }

        }
        return getTile();
    }

    @Override
    public List<Tile> currentTiles() {
        return tiles;
    }


    @Override
    public void shuffle() {
        Collections.shuffle(tiles);
    }

    @Override
    public void nextTime() {
        tiles.addAll(removes);
        removes.clear();
        shuffle();
    }
}
