package com.jinhaidun.mahjong.struct;

import com.jinhaidun.mahjong.util.TileUtil;

/**
 * Created by 罗中正 on 2017/4/21.
 */
public class Assign {

    public int playerId;
    public int mahjongValue;

    @Override
    public String toString() {
        return "Assign{" +
                "playerId=" + playerId +
                ", mahjongValue=" + TileUtil.getTile(mahjongValue)+
                '}';
    }
}
