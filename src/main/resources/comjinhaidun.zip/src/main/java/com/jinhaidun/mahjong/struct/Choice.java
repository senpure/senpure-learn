package com.jinhaidun.mahjong.struct;

import com.jinhaidun.mahjong.util.TileUtil;

/**
 * Created by 罗中正 on 2017/4/11.
 */
public class Choice {

//    public static String CHOICE_HU = "HU";
//    public static String CHOICE_PENG = "PENG";
//    public static String CHOICE_MING_PENG = "MING_PENG";
//    public static String CHOICE_MING_GNAG = "MING_GANG";
//    public static String CHOICE_AN_GNAG = "AN_GANG";

    public static enum CHOICE {
        PASS,
        MO_PAI,
        CHU_PAI,
        HU,
        PENG,
        HUI_ER_PI_MING_GANG,
        HUI_ER_PI_AN_GANG,
        SI_XI_FENG,
        SAN_ZHI_JIAN,
        AN_GANG, MING_GANG, JIA_GANG,PENG_GANG;

    }

    public boolean has = false;
    public boolean pass = false;
    public boolean execute = false;
    public  int  seatIndex;
    public boolean done = false;
    public long expire;
    public String typeStr;
    public CHOICE choice;
    public int value;
    public int priority = 0;
    public int token;


    @Override
    public String toString() {
        return "Choice{" +
                "pass=" + pass +
                ", execute=" + execute +
                ", seatIndex=" + seatIndex +
                ", choice=" + choice +
                ", value=" + value + "  "+ (value>0? TileUtil.getTile(value):value )+
                ", priority=" + priority +
                ", token=" + token +
                '}';
    }
}
