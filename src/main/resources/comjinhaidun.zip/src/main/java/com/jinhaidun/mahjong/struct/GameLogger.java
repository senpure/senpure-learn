package com.jinhaidun.mahjong.struct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;

/**
 * Created by 罗中正 on 2017/4/27.
 */
public class GameLogger {

public  static  String LOGGER_CLASS_MAME="MAHJONG";
    public static org.apache.logging.log4j.Logger getLogger(int roomId) {
        final LoggerContext ctx = (LoggerContext) LogManager.getContext();
        ctx.getLogger(LOGGER_CLASS_MAME);

        return null;
    }

}
