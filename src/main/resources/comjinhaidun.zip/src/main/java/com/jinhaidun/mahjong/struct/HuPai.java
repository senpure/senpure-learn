package com.jinhaidun.mahjong.struct;

import com.jinhaidun.mahjong.util.TileUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/10.
 */
public class HuPai {

    public static enum HU {
        NONE(0),
        HU(1),
        MEI_HUI_ER(2),
        HUI_ER_GUI_WEI(2),
        SI_GE_HUI_ER(2),
        QI_DUI(1),
        QIN_QI_DUI(4),
        HAO_HUA_QI_DUI(8),
        CHAO_HAO_HUA_QI_DUI(16),
        CHAO_CHAO_HAO_HUA_QI_DUI(32),;

        HU(int beiShu) {
            this.beiShu = beiShu;
        }

        int beiShu;

        public int getbeiShu() {
            return beiShu;
        }
    }

    public static enum PAI {
        ONOE(1),
        ZI_MO(1),
        DIAN_PAO(1),
        GANG_SHANG_KAI_FA(2),
        TIAN_HU(2),
        DI_HU(2),
        ZHUANG_JIA(2),;

        PAI(int beiShu) {
            this.beiShu = beiShu;
        }

        int beiShu;

        public int getbeiShu() {
            return beiShu;
        }
    }


    private HU hu;
    private List<PAI> pai = new ArrayList<>();
    private int huValue;

    private int baida;
    private List<Tile> hand;
    private List<Integer> changeTos = new ArrayList<>();
    private int targetIndex = -1;
private int endValue;
    public void addChangeTo(int changeTo) {
        changeTos.add(changeTo);
    }

    public boolean isHu() {
        return hu != HU.NONE;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(hand).append(" -> [").append(hu).append("]");

        if (pai != null&&pai.size()>0) {
            sb.append("|");
            pai.forEach(p -> {

                sb.append("[").append(p).append("]");
            });
        }
        if (hu != HU.NONE && changeTos.size() > 0) {
            Tile tile = TileUtil.getTile(baida);
            for (Integer value : changeTos) {
                sb.append("\n");
                sb.append("[").append(tile).append(" ->  ").append(TileUtil.getTile(value));
                sb.append("]");
            }

        }
        return sb.toString();
    }

    public List<Integer> getChangeTos() {
        return changeTos;
    }

    public void setChangeTos(List<Integer> changeTos) {
        this.changeTos = changeTos;
    }


    public void setHand(List<Tile> hand) {
        this.hand = hand;
    }

    public HU getHu() {
        return hu;
    }

    public void setHu(HU hu) {
        this.hu = hu;
    }

    public List<PAI> getPai() {
        return pai;
    }

    public void setPai(List<PAI> pai) {
        this.pai = pai;
    }


    public int getBaida() {
        return baida;
    }

    public void setBaida(int baida) {
        this.baida = baida;
    }

    /**
     * 将牌
     *
     * @return
     */
    public int getHuValue() {
        return huValue;
    }

    public void setHuValue(int huValue) {
        this.huValue = huValue;
    }

    public int getTargetIndex() {
        return targetIndex;
    }

    public void setTargetIndex(int targetIndex) {
        this.targetIndex = targetIndex;
    }

    public int getEndValue() {
        return endValue;
    }

    public void setEndValue(int endValue) {
        this.endValue = endValue;
    }
}
