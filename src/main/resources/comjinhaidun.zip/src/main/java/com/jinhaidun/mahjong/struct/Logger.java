package com.jinhaidun.mahjong.struct;

import com.jinhaidun.AppConstant;
import com.jinhaidun.mahjong.logic.GameRoom;
import org.apache.log4j.*;

import java.io.File;
import java.util.Date;
import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by 罗中正 on 2017/4/7.
 */
public class Logger {
    static Map<Integer, org.apache.log4j.Logger> loggers = new ConcurrentHashMap<>();
    public static Logger getLogger(int roomId) {
        org.apache.log4j.Logger logger = null;


            logger = org.apache.log4j.Logger.getLogger(GameRoom.class + "" + roomId);
            logger.removeAllAppenders();
            logger.setLevel(Level.DEBUG);
            FileAppender appender = new DailyRollingFileAppender();
            PatternLayout layout = new PatternLayout();
            appender.setFile(getLogFilePath()  + roomId + ".log");
            // log的输出形式
            String conversionPattern = "%d{HH:mm:ss} [%p]- %m%n";
            layout.setConversionPattern(conversionPattern);
            appender.setLayout(layout);
            // log输出路径
            // log的文字码
            appender.setEncoding("GB2312");
            if (isWindowSOS()) {
                appender.setEncoding("GB2312");
            } else {
                appender.setEncoding("utf-8");

            }
        appender.setEncoding("utf-8");
            // true:在已存在log文件后面追加 false:新log覆盖以前的log
            appender.setAppend(true);
            // 适用当前配置
            appender.activateOptions();
            // 設定是否繼承父Logger。
            // 默認為true。繼承root輸出。
            // 設定false後將不輸出root。
            logger.setAdditivity(false);
            // 将新的Appender加到Logger中
            logger.addAppender(appender);
            FileAppender warnappender = new DailyRollingFileAppender();
            warnappender.setThreshold(Level.WARN);
            warnappender.setFile(getLogFilePath()  + roomId + "_warn.log");
            // log的输出形式
            warnappender.setLayout(layout);
            // log输出路径
            // log的文字码
            if (isWindowSOS()) {
                warnappender.setEncoding("GB2312");
            } else {
                warnappender.setEncoding("utf-8");
            }
            // true:在已存在log文件后面追加 false:新log覆盖以前的log
            warnappender.setAppend(true);
            // 适用当前配置
            // warnappender.activateOptions();
            //  logger.addAppender(warnappender);
            if(isWindowSOS())
            {
                ConsoleAppender gameDebug = new ConsoleAppender();
                layout = new PatternLayout();
                conversionPattern = "%d{HH:mm:ss} [%p]- %m%x%n";
                layout.setConversionPattern(conversionPattern);
                gameDebug.setLayout(layout);
                gameDebug.setTarget("System.out");
                gameDebug.activateOptions();
                logger.addAppender(gameDebug);
            }

        Logger log = new Logger();
        log.log = logger;
        return log;
    }

    public static void closeLogger(Logger logger) {
        Enumeration enumeration = logger.log.getAllAppenders();
        while (enumeration.hasMoreElements()) {
            Appender appender = (Appender) enumeration.nextElement();
            appender.close();
            loggers.remove(logger);
        }

    }

    private static String getLogFilePath() {
        String os = System.getProperty("os.name").toLowerCase();

        String date= AppConstant.DFD_COMPACT.format(new Date());
        if (os.contains("linux")) {
            return "/data/logs/mahjong/"+date+"/";
        }

        return "E:\\data\\logs\\mahjong\\"+date+"\\";
    }

    public static boolean isWindowSOS() {
        String os = System.getProperty("os.name").toLowerCase();

        return os.contains("windows");
    }

    private org.apache.log4j.Logger log;

    public void debug(String message) {

        log.debug(message);
    }

    public void info(String message) {
        log.info(message);
    }

    public void warn(String message) {
        log.warn(message);

    }

    public void error(String message) {
        log.error(message);
    }

    public void error(String message, Exception e) {
        log.error(message, e);
    }

    public static void main(String[] args) {

    Logger logger= getLogger(123);
    File file =new File(getLogFilePath());
        System.out.println(file.getAbsolutePath()+" , "+file.exists());
    logger.debug("123888888");
    }
}
