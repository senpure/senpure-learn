package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/4/14.
 */
public class Player {
    public int id;
    public String nick="";
    public String head="";
    public int roomId;
    public int diamond;


}
