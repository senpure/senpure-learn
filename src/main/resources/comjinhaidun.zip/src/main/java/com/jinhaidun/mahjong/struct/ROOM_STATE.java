package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/4/18.
 */
public enum  ROOM_STATE {
    READY_START,
    READY_NEXT,
    PLAYING,
    ROUND_OVER,
    NO_PLAYER,
    CLOSED
    ;

}
