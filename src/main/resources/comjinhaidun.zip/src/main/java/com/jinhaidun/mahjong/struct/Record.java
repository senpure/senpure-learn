package com.jinhaidun.mahjong.struct;

import com.jinhaidun.mahjong.msg.PokerMsgBasic;

import java.util.List;

/**
 * Created by 罗中正 on 2017/5/31.
 */
public class Record {
   private List<PokerMsgBasic.PBTableSeat>  start;
    private int leftTile;
    private int dealer;
    private int round;
    private int hunPi;
    private int hunPai;
    private List<Choice> choices;

    public int getLeftTile() {
        return leftTile;
    }

    public void setLeftTile(int leftTile) {
        this.leftTile = leftTile;
    }

    public int getDealer() {
        return dealer;
    }

    public void setDealer(int dealer) {
        this.dealer = dealer;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getHunPi() {
        return hunPi;
    }

    public void setHunPi(int hunPi) {
        this.hunPi = hunPi;
    }

    public int getHunPai() {
        return hunPai;
    }

    public void setHunPai(int hunPai) {
        this.hunPai = hunPai;
    }

    public List<Choice> getChoices() {
        return choices;
    }

    public void setChoices(List<Choice> choices) {
        this.choices = choices;
    }

    public List<PokerMsgBasic.PBTableSeat> getStart() {
        return start;
    }

    public void setStart(List<PokerMsgBasic.PBTableSeat> start) {
        this.start = start;
    }
}
