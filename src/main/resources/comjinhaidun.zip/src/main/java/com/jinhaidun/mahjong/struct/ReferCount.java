package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/4/12.
 */
public class ReferCount {
    public int count=0;
}
