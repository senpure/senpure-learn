package com.jinhaidun.mahjong.struct;

import java.util.List;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public class RenQiuMahjong  extends AbsMahjong {

    public RenQiuMahjong(List<Tile> tiles) {
        this.tiles = tiles;
    }
}
