package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public class RoomConfig {
    public int roomId;
    public int createrId;
    public  int panshu;
    //圈数
    public int round;
    public int diamond;
    /**
     * 封顶倍数
     */
    public  int limit;
    public int playedPanshu;
    public int meng;
    public String password;
    @Override
    public String toString() {
        return "RoomConfig{" +
                "roomId=" + roomId +
                ", createrId=" + createrId +
                ", panshu=" + panshu +
                ", round=" + round +
                ", limit=" + limit +
                ", playedPanshu=" + playedPanshu +
                ", meng=" + meng +
                ", password='" + password + '\'' +
                '}';
    }
}
