package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/4/18.
 */
public enum SEAT_STATE {

    NO_PLAYER,

    WAIT_FOR_GAME,//取消状态
    READY_FOR_GAME,//准备状态
    PLAYING
}
