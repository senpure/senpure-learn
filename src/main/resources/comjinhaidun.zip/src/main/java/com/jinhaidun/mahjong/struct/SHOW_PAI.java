package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/4/17.
 */
public enum SHOW_PAI {

    SI_XI_FENG(1),
    SAN_ZHI_JIAN(1),
    HUI_ER_PI_AN_GANG(1),
    HUI_ER_PI_MING_GANG(1),
    GEN_ZHUANG(1);

    private int score;

    SHOW_PAI(int score) {
        this.score = score;
    }

    public int getScore() {
        return score;
    }
}
