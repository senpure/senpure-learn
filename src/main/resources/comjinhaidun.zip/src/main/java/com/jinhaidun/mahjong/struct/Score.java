package com.jinhaidun.mahjong.struct;

/**
 * Created by 罗中正 on 2017/4/11.
 */
public class Score {

    private int seatIndex;
    private int targetIndex;
    private SHOW_PAI pai;
    private boolean win;

    private int score;

    public int getSeatIndex() {
        return seatIndex;
    }

    public void setSeatIndex(int seatIndex) {
        this.seatIndex = seatIndex;
    }

    public int getTargetIndex() {
        return targetIndex;
    }

    public void setTargetIndex(int targetIndex) {
        this.targetIndex = targetIndex;
    }


    public boolean isWin() {
        return win;
    }

    public void setWin(boolean win) {
        this.win = win;
    }

    public SHOW_PAI getPai() {
        return pai;
    }

    public void setPai(SHOW_PAI pai) {
        this.pai = pai;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
