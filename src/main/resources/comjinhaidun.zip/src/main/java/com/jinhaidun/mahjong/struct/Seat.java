package com.jinhaidun.mahjong.struct;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/14.
 */
public class Seat {

    public Player player;
    public  int choiceToken;
    public int index;
    public int chuPaiCount = 0;
    public int moPaiCount = 0;
    public int lianXuGangCount = 0;
    public boolean thisGang = false;
    public long firstTurnTime = 0;
    public boolean dissolve=false;
    public List<Choice> choices;
    public HuPai huPai;
    public int moPaiValue;

    public int score;
    /**
     * 掉线时间
     */
    public long offTime=0;
    /**
     * 是否是自然轮子，碰 杠等 为false
     */
    public boolean turnMoPai;
    public boolean online;
    public int rounScore;
    /**
     * true
     * 准备好了。
     */
    public boolean readyForGame;
    public SEAT_STATE state;
    public List<Tile> hand = new ArrayList<>();
    //三个一组
    public List<Tile> peng = new ArrayList<>();
    public List<Tile> mingGang = new ArrayList<>();
    public List<Tile> anGang = new ArrayList<>();

    public List<Tile> huierMingGang = new ArrayList<>();
    public List<Tile> huierAnGang = new ArrayList<>();

    public List<Tile> sanzhijian = new ArrayList<>();
    public List<Tile> sixifeng = new ArrayList<>();
    //打出的牌
    public List<Tile> out = new ArrayList<>();

    public List<Score> scores = new ArrayList<>();

    public void clear() {
        hand.clear();
        peng.clear();
        mingGang.clear();
        anGang.clear();
        huierAnGang.clear();
        huierMingGang.clear();
        sanzhijian.clear();
        sixifeng.clear();
        out.clear();
        choices=null;
        moPaiCount = 0;
        chuPaiCount = 0;
        firstTurnTime = 0;
        huPai=null;
        moPaiValue=0;
        scores.clear();

    }
}
