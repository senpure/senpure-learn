package com.jinhaidun.mahjong.struct;


import com.jinhaidun.mahjong.util.TileUtil;
import com.senpure.base.util.ReadNumber;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

/**
 * Created by 罗中正 on 2017/3/31.
 * <p>
 * 用拼音表示<br>
 * 所有牌按顺序从 1 开始到最高9 结束
 */
public class Tile implements Comparable<Tile> {
    protected static Logger log = LogManager.getLogger(Tile.class);

    @Override
    public int compareTo(Tile o) {
        return Integer.compare(this.getIntValue(), o.getIntValue());
    }

    public static enum SUIT {
        WAN,
        TIAO,
        TONG,
        FENG,
        JIAN,
        HUAN,
        BAI;
    }

    public static enum RANK {
        ONE(1), TWO(2), THREE(3), FOUR(4), FIVE(5), SIX(6), SEVEN(7), EIGHT(8), NINE(9);
        // 数值
        private int value = 0;

        private RANK(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        public static RANK getRank(int value) {
            if (value > NINE.getValue() || value < ONE.getValue()) {
                // throw new Exception("点数不合法");
                log.warn("点数不合法" + value + "->>" + ONE.getValue());
                return ONE;
            }
            return RANK.values()[value - 1];
        }
    }

    private SUIT suit;
    private RANK rank;

    private int id;

    public Tile(SUIT suit, RANK rank) {
        this.suit = suit;
        this.rank = rank;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIntValue() {
        return (suit.ordinal()) * 10 + rank.getValue();
    }

    @Override
    public String toString() {
        if (suit == SUIT.TONG) {
            return ReadNumber.read(rank.getValue()) + "筒";
        }
        if (suit == SUIT.TIAO) {
            return ReadNumber.read(rank.getValue()) + "条";
        }
        if (suit == SUIT.WAN) {
            return ReadNumber.read(rank.getValue()) + "万";
        }
        if (suit == SUIT.FENG) {
            return READ_FENG[rank.getValue() - 1] + "风";
        }
        if (suit == SUIT.JIAN) {
            return READ_JIAN[rank.getValue() - 1];
        }
        return ReadNumber.read(rank.getValue()) + suit.toString();
    }


    public SUIT getSuit() {
        return suit;
    }

    public void setSuit(SUIT suit) {
        this.suit = suit;
    }

    public RANK getRank() {
        return rank;
    }

    public void setRank(RANK rank) {
        this.rank = rank;
    }

    private static String[] READ_FENG = {"东", "南", "西", "北"};
    private static String[] READ_JIAN = {"中", "发", "白"};

    public static void main(String[] args) {

        RenQiuMahjong renQiuMahjong = TileUtil.generateRenQiuMahjion();
        // renQiuMahjong.shuffle();
        List<Tile> tiles = renQiuMahjong.currentTiles();
        System.out.println(tiles.size());
        tiles.forEach(tile -> {
            System.out.println(tile.toString() + " " + tile.getIntValue() + " " + tile.getId());
        });
    }
}
