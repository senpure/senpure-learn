package com.jinhaidun.mahjong.struct;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/6/2.
 */
public class Video {
    private long recordId;
    private int index;
    private String start;
    private String over;
    private List<String> actions=new ArrayList<>();
    private String config;

    public long getRecordId() {
        return recordId;
    }

    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getOver() {
        return over;
    }

    public void setOver(String over) {
        this.over = over;
    }

    public List<String> getActions() {
        return actions;
    }

    public void setActions(List<String> actions) {
        this.actions = actions;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }
}
