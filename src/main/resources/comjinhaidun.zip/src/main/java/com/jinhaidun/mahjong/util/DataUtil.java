package com.jinhaidun.mahjong.util;

import com.senpure.base.util.Base64;

/**
 * Created by 罗中正 on 2017/6/6.
 */
public class DataUtil {

    public static String byte2Str(byte[] data) {

        return Base64.encode(data);
    }

    public static byte[] str2Byte(String str) {
        return Base64.decode(str);
    }
}
