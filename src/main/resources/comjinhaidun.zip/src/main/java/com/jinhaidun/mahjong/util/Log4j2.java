package com.jinhaidun.mahjong.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.rolling.SizeBasedTriggeringPolicy;
import org.apache.logging.log4j.core.appender.rolling.TriggeringPolicy;
import org.apache.logging.log4j.core.config.Configuration;

/**
 * Created by 罗中正 on 2017/4/27.
 */
public class Log4j2 {

    public static void main(String[] args) {



        LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
        final Configuration config = ctx.getConfiguration();

        TriggeringPolicy tp = SizeBasedTriggeringPolicy.createPolicy("10MB");



    }
}
