package com.jinhaidun.mahjong.util;

import com.jinhaidun.mahjong.io.ChannelUtil;
import com.jinhaidun.mahjong.msg.Message;
import io.netty.channel.Channel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * Created by 罗中正 on 2017/4/13.
 */
public class MessageHelper {
    protected static Logger log = LogManager.getLogger(TileUtil.class);
    public static void pushMessage(Integer playerId, Message message) {
        Channel channel = ChannelUtil.getChannel(playerId);
        if (channel != null) {
            channel.writeAndFlush(message);
        }

    }

}
