package com.jinhaidun.mahjong.util;

import com.jinhaidun.mahjong.struct.Seat;

/**
 * Created by 罗中正 on 2017/5/31.
 */
public class SeatUtil {

    public void copySeat(Seat source)
    {
        Seat seat=new Seat();
    }
}
