package com.jinhaidun.mahjong.util;


import com.jinhaidun.mahjong.model.MahjongZu;
import com.jinhaidun.mahjong.struct.HuPai;
import com.jinhaidun.mahjong.struct.ReferCount;
import com.jinhaidun.mahjong.struct.RenQiuMahjong;
import com.jinhaidun.mahjong.struct.Tile;
import com.senpure.base.util.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;

/**
 * 目前自有数字牌能组成顺子
 * Created by 罗中正 on 2017/3/31.
 */
public class TileUtil {

    private static Map<Integer, Tile> tileMap = new HashMap<>();
    protected static Logger log = LogManager.getLogger(TileUtil.class);

    static {

        RenQiuMahjong renQiuMahjong = generateRenQiuMahjion();
        renQiuMahjong.currentTiles().forEach(tile ->
                tileMap.putIfAbsent(tile.getIntValue(), tile)
        );
    }

    public static RenQiuMahjong generateRenQiuMahjion() {
        List<Tile> tiles = new LinkedList<>();
        for (int j = 1; j < 5; j++) {
            for (int i = 1; i < 10; i++) {
                Tile tile = new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(i));


                tiles.add(tile);
                tile = new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(i));

                tiles.add(tile);

                tile = new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(i));

                tiles.add(tile);
            }
            for (int i = 1; i < 5; i++) {
                Tile tile = new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(i));

                tiles.add(tile);
            }
            for (int i = 1; i < 4; i++) {
                Tile tile = new Tile(Tile.SUIT.JIAN, Tile.RANK.getRank(i));

                tiles.add(tile);
            }
        }
        int id = 1;
        for (Tile tile : tiles) {
            tile.setId(id++);
        }
        RenQiuMahjong renQiuMahjong = new RenQiuMahjong(tiles);
        return renQiuMahjong;
    }

    public static Tile getTile(int value) {

        Tile tile = tileMap.get(value);

        Assert.notNull(tile);
        return tile;

    }

    public static boolean canChu(List<Tile> tiles, int value) {
        return countTile(tiles, value) >= 1;
    }

    public static boolean canPeng(List<Tile> tiles, int value) {

        return countTile(tiles, value) >= 2;
    }

    public static boolean canGang(List<Tile> tiles, int value) {
        return countTile(tiles, value) >= 3;
    }


    public static void moveTiles(List<Tile> source, List<Tile> target, int value, int num) {
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < source.size(); j++) {
                if (source.get(j).getIntValue() == value) {
                    target.add(source.remove(j));
                    break;
                }
            }

        }
    }

    public static int countTile(List<Tile> source, int value) {
        int count = 0;

        for (int i = 0, size = source.size(); i < size; i++) {
            if (source.get(i).getIntValue() == value) {
                count++;
            }
        }

        return count;
    }

    public static boolean canFeng(List<Tile> source) {

        return countTile(source, 31) >= 1
                && countTile(source, 32) >= 1
                && countTile(source, 33) >= 1
                && countTile(source, 34) >= 1;
    }

    public static boolean canJian(List<Tile> source) {

        return countTile(source, 41) >= 1
                && countTile(source, 42) >= 1
                && countTile(source, 43) >= 1;

    }

    public static void tingPai(List<Tile> tiles, int baida) {


    }

    public static Map<Integer, Integer> count(List<Integer> tiles) {
        Map<Integer, Integer> valueCountMap = new HashMap<>();
        tiles.forEach(value -> {
            valueCountMap.computeIfPresent(value, (key, count) -> ++count);
            valueCountMap.putIfAbsent(value, 1);

        });
        return valueCountMap;
    }

    /**
     * @param tiles 必须排序后的list,且有这么多值
     * @param value
     * @param count
     */
    public static void remove(List<Integer> tiles, int value, int count) {

        for (int i = 0; i < tiles.size(); i++) {
            int cv = tiles.get(i);
            if (cv == value) {
                for (int j = 0; j < count; j++) {
                    tiles.remove(i);
                }
                break;
            }


        }
    }

    public static boolean check3n(List<Integer> tiles) {

        return check3n(tiles, true);

    }

    public static boolean check3n(List<Integer> tiles, boolean canShun) {

        Collections.sort(tiles);
        Map<Integer, Integer> valueCountMap = count(tiles);
        List<Integer> kezi = new ArrayList<>();
        valueCountMap.forEach((key, count) -> {
            if (count >= 3) {
                kezi.add(key);
            }
        });
        // System.out.println(tiles);

        //移除刻子
        for (int i = 0; i < kezi.size(); i++) {
            int value = kezi.get(i);
            remove(tiles, value, 3);
        }

        if (!canShun && tiles.size() > 0) {
            return false;
        }
        //System.out.println(tiles);
        if (tiles.size() % 3 != 0) {
            return false;
        }

        //判断顺子
        int zu = tiles.size() / 3;
        for (int i = 1; i <= zu; i++) {
            int first = tiles.get(i * 3 - 3);
            // System.out.println("first "+first+", "+tiles.get(i * 3 - 2)+", "+tiles.get(i * 3 - 1));
            if (first != tiles.get(i * 3 - 2) - 1 || first != tiles.get(i * 3 - 1) - 2) {
                return false;
            }
        }
        return true;
    }

    public static boolean check3nSetpOne(List<Integer> tiles) {
        List<Integer> tong = new ArrayList<>();
        List<Integer> tiao = new ArrayList<>();
        List<Integer> wan = new ArrayList<>();
        List<Integer> feng = new ArrayList<>();
        List<Integer> jian = new ArrayList<>();
        //  List<Tile> =new ArrayList<>();
        for (int i = 0, size = tiles.size(); i < size; i++) {
            Integer tile = tiles.get(i);
            if (tile.intValue() < 10) {
                tong.add(tile);
            } else if (tile.intValue() < 20) {
                tiao.add(tile);
            } else if (tile.intValue() < 30) {
                wan.add(tile);
            } else if (tile.intValue() < 40) {
                feng.add(tile);
            } else if (tile.intValue() < 50) {
                jian.add(tile);
            }
        }
        //  System.out.println("--------");
        return check3n(tong) && check3n(tiao) && check3n(wan) &&
                check3n(feng, false) && check3n(jian, false);
    }

    public static boolean checkHuPai(List<Integer> tiles, Map<Integer, Integer> valueCountMap, HuPai huPai) {
        Iterator<Map.Entry<Integer, Integer>> iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            int value = entry.getValue();
            if (value >= 2) {
                List<Integer> pai = new ArrayList<>();
                pai.addAll(tiles);
                Collections.sort(pai);
                remove(pai, entry.getKey(), 2);
//                pai.forEach(integer ->
//                        System.out.print(getTile(integer) + "  ")
//                );
//                System.out.println();
//                if(entry.getKey()==12)
//                {
//                    System.out.println(pai);
//                }
                if (check3nSetpOne(pai)) {
                    // log.debug(getTile(entry.getKey()) + "  胡牌");
                    huPai.setHuValue(entry.getKey());
                    return true;
                }
            }
        }
        //log.debug("不胡");
        return false;
    }

    /**
     * 七对
     *
     * @param tiles
     */
    public static void checkQiDui(List<Integer> tiles, Map<Integer, Integer> valueCountMap, HuPai huPai, int baidacount) {

        if (tiles.size() != 14) {
            return;
        }
        Iterator<Map.Entry<Integer, Integer>> iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            int value = entry.getValue();
            if (value % 2 > 0) {
                return;
            }
        }

        huPai.setHu(HuPai.HU.QIN_QI_DUI);
        if (baidacount > 0) {
            huPai.setHu(HuPai.HU.QI_DUI);
            return;
        }
        int keySize = valueCountMap.keySet().size();
        if (keySize == 4) {
            huPai.setHu(HuPai.HU.CHAO_CHAO_HAO_HUA_QI_DUI);
        } else if (keySize == 5) {
            huPai.setHu(HuPai.HU.CHAO_HAO_HUA_QI_DUI);
        } else if (keySize == 6) {
            huPai.setHu(HuPai.HU.HAO_HUA_QI_DUI);
        }
    }

    public static void removeKezi(List<Integer> tiles, List<Integer> kezi) {
        //移除刻子
        for (int i = 0; i < kezi.size(); i++) {
            int value = kezi.get(i);
            remove(tiles, value, 3);
        }
    }

    public static int removeShuzi(List<Integer> tiles, List<Integer> all) {
        Set<Integer> temp = new HashSet<>();
        List<Integer> single = new ArrayList<>();
        for (Integer tile : tiles) {
            if (temp.add(tile)) {
                single.add(tile);
            }
        }

        int nowSize = single.size();
        int zu = nowSize / 3;
        int count = 0;
        if (nowSize < 3) {
            return count;
        }
        for (int i = 2; i < nowSize; i++) {
            int first = single.get(i - 2);
            int sencond = single.get(i - 1);
            int third = single.get(i);
            if (first == sencond - 1 && first == third - 2) {
                remove(tiles, first, 1);
                remove(tiles, sencond, 1);
                remove(tiles, third, 1);
                remove(all, first, 1);
                remove(all, sencond, 1);
                remove(all, third, 1);
                i += 2;
                count++;
            }
        }

        return count * 3;
    }


    private static int useBaida(List<Integer> pai, int havaBaida, boolean canShun, ReferCount referCount, HuPai huPai) {
        int tempSize = pai.size();
        int useBaida = 0;
        if (havaBaida < 0) {
            return useBaida;
        }
        if (tempSize == 1) {
            useBaida = 2;
            huPai.addChangeTo(pai.get(0));
            huPai.addChangeTo(pai.get(0));
            referCount.count += 2;
            return useBaida;
        } else if (tempSize > 1) {
            Integer last = pai.get(0);
            Integer now = pai.get(1);
            int num = now - last;
            if (canShun && num < 3) {

                useBaida = 1;
                referCount.count += 2;
                if (num == 0) {
                    huPai.addChangeTo(last);
                } else if (num == 1) {
                    if (last % 10 < 2) {
                        huPai.addChangeTo(last + 2);
                    } else {

                        huPai.addChangeTo(last - 1);
                    }
                } else {
                    huPai.addChangeTo(last + 1);
                }

            } else if (num == 0) {
                huPai.addChangeTo(last);
                useBaida = 1;
                referCount.count += 2;
            } else {
                useBaida = 2;

                huPai.addChangeTo(last);
                huPai.addChangeTo(last);
                referCount.count++;
            }
            if (useBaida >= havaBaida) {
                return useBaida;
            }
            pai.remove(0);
            if (useBaida == 1) {
                pai.remove(0);
            }
            return useBaida += useBaida(pai, havaBaida - useBaida, canShun, referCount, huPai);
        }
        return useBaida;
    }

    public static int useBaida(MahjongZu zu, int haveBaida, ReferCount referCount, HuPai huPai) {
        int useBaida = 0;
        useBaida = useBaida(zu.tiao, haveBaida, true, referCount, huPai);
        useBaida += useBaida(zu.wan, haveBaida - useBaida, true, referCount, huPai);
        useBaida += useBaida(zu.tong, haveBaida - useBaida, true, referCount, huPai);
        useBaida += useBaida(zu.feng, haveBaida - useBaida, false, referCount, huPai);
        useBaida += useBaida(zu.jian, haveBaida - useBaida, false, referCount, huPai);
        return useBaida;
    }

    /*
    肯定要变换才能组成胡牌了。
     */
    public static void checkHuPai(List<Integer> tiles, int baida, int baidaCount, HuPai huPai) {
        Collections.sort(tiles);
        //log.debug("移除百搭牌前：" + tiles);
        remove(tiles, baida, baidaCount);
        //log.debug("移除百搭牌后：" + tiles);
        Map<Integer, Integer> valueCountMap = count(tiles);

        //先检查七对
        if (tiles.size() + baidaCount == 14) {
            List<Integer> pai = new ArrayList<>();
            pai.addAll(tiles);
            checkQidui(pai, valueCountMap, baida, baidaCount, huPai);
            if (huPai.getHu() != HuPai.HU.NONE) {
                return;
            }
        }
        huPai.getChangeTos().clear();
        List<Integer> kezi = new ArrayList<>();
        valueCountMap.forEach((key, count) -> {
            if (count >= 3) {
                kezi.add(key);
            }
        });
        removeKezi(tiles, kezi);
        // log.debug("没有3n的pai" + tiles);
        MahjongZu mz = MahjongZu.getInstance(tiles);
        removeShuzi(mz.wan, tiles);
        removeShuzi(mz.tong, tiles);
        removeShuzi(mz.tiao, tiles);
        valueCountMap = count(tiles);
        //log.debug("没有3n的pai" + tiles);
        //原牌一对
        Iterator<Map.Entry<Integer, Integer>> iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            int value = entry.getValue();
            if (value >= 2) {
                List<Integer> pai = new ArrayList<>();
                pai.addAll(tiles);
                Collections.sort(pai);
                remove(pai, entry.getKey(), 2);
                MahjongZu zu = MahjongZu.getInstance(pai);
                int haveBaida = baidaCount;
                ReferCount referCount = new ReferCount();
                huPai.getChangeTos().clear();

                int useBaida = useBaida(zu, haveBaida, referCount, huPai);
                if (useBaida == baidaCount && pai.size() - referCount.count == 0) {
                    huPai.setHu(HuPai.HU.HU);
                    if (baidaCount == 4) {
                        huPai.setHu(HuPai.HU.SI_GE_HUI_ER);
                    }
                    return;
                }
            }
        }

        //原牌出一个奖牌
        iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
           // int value = entry.getValue();
            List<Integer> pai = new ArrayList<>();
            pai.addAll(tiles);
            Collections.sort(pai);
            remove(pai, entry.getKey(), 1);
            MahjongZu zu = MahjongZu.getInstance(pai);
            int haveBaida = baidaCount - 1;
            ReferCount referCount = new ReferCount();
            huPai.getChangeTos().clear();
            huPai.addChangeTo(entry.getKey());
            int useBaida = useBaida(zu, haveBaida, referCount, huPai);
            if (useBaida == baidaCount-1 && pai.size() - referCount.count == 0) {
                if (baidaCount == 4) {
                    huPai.setHu(HuPai.HU.SI_GE_HUI_ER);
                }
                huPai.setHu(HuPai.HU.HU);
                return;
            }
        }
        //原牌不出将牌
        iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            int value = entry.getValue();
            List<Integer> pai = new ArrayList<>();
            pai.addAll(tiles);
            Collections.sort(pai);
            remove(pai, entry.getKey(), 1);
            MahjongZu zu = MahjongZu.getInstance(pai);
            int haveBaida = baidaCount - 2;
            ReferCount referCount = new ReferCount();
            huPai.getChangeTos().clear();
            int useBaida = useBaida(zu, haveBaida, referCount, huPai);
            if (useBaida == baidaCount-2 && pai.size() - referCount.count == 0) {
                if (baidaCount == 4) {
                    huPai.setHu(HuPai.HU.SI_GE_HUI_ER);
                } else {
                    huPai.setHu(HuPai.HU.HU);
                }
                return;
            }
        }

    }


    public static void checkQidui(List<Integer> tiles, Map<Integer, Integer> valueCountMap, int baida, int baidaCount, HuPai huPai) {
        Iterator<Map.Entry<Integer, Integer>> iterator = valueCountMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, Integer> entry = iterator.next();
            int value = entry.getValue();
            if (value % 2 == 0) {
                remove(tiles, entry.getKey(), value);
            } else if (value > 2) {
                remove(tiles, entry.getKey(), 2);
            }
        }
        if (tiles.size() == baidaCount) {
            huPai.setHu(HuPai.HU.QI_DUI);
            for (Integer value : tiles) {
                huPai.addChangeTo(value);
            }

        }

    }

    public static HuPai checkHuPai(List<Tile> hand, int baida) {
        //List<Tile> hand = player.getHand();
        Collections.sort(hand);
        //  log.debug("玩家手牌:\n" + hand);
        Assert.isTrue(hand.size() % 3 == 2 && hand.size() <= 14, "手牌数量不对");
        List<Integer> tiles = new ArrayList<>();
        hand.forEach(tile ->
                tiles.add(tile.getIntValue()));
        Map<Integer, Integer> valueCountMap = count(tiles);
        HuPai huPai = new HuPai();
        huPai.setHu(HuPai.HU.NONE);

        huPai.setHand(hand);
        Integer o = valueCountMap.get(baida);
        int baidaCount = o == null ? 0 : o;
        //先处理没有百搭牌的情况
        checkQiDui(tiles, valueCountMap, huPai, baidaCount);
        if (huPai.getHu() != HuPai.HU.NONE) {
            return huPai;
        }
        if (checkHuPai(tiles, valueCountMap, huPai)) {
            huPai.setHu(HuPai.HU.HU);
            if (baidaCount == 0) {
                huPai.setHu(HuPai.HU.MEI_HUI_ER);
            } else if (baidaCount == 4) {
                huPai.setHu(HuPai.HU.SI_GE_HUI_ER);
            } else {
                huPai.setHu(HuPai.HU.HUI_ER_GUI_WEI);
            }
        }
        if (huPai.getHu() != HuPai.HU.NONE) {
            return huPai;
        }
        huPai.setBaida(baida);
        //log.debug("处理百搭牌 " + getTile(baida) + " baidaCount =" + baidaCount);
        if (baidaCount > 0) {
            checkHuPai(tiles, baida, baidaCount, huPai);
        }
        return huPai;
    }

    public static HuPai checkHuPai(com.jinhaidun.mahjong.struct.Seat seat, int value, int baida) {

        List<Tile> hand = new ArrayList<>();
        hand.addAll(seat.hand);
        hand.add(getTile(value));
        HuPai huPai = checkHuPai(hand, baida);
        return huPai;

    }

    public static void main(String[] args) {

        RenQiuMahjong renQiuMahjong = generateRenQiuMahjion();

        Collections.sort(renQiuMahjong.currentTiles());
        Map<Integer, Tile> tileMap = new HashMap<>();
        renQiuMahjong.currentTiles().forEach(tile -> {

            tileMap.putIfAbsent(tile.getIntValue(), tile);
        });

        tileMap.values().forEach(tile -> System.out.println(tile.getIntValue() + " -> " + tile));
    }
}
