package com.jinhaidun.store.criterion;


import com.senpure.base.criterion.Criteria;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Digits;

/**
 * Created by 罗中正 on 2017/5/9.
 */
public class ClientResourceCriteria extends Criteria {

    @NotEmpty(message = "{not.blank}")
    private String cp="";
    @Digits(integer= 1,fraction = 20000000,message = "{not.number}")
    private int clientVersion;

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public int getClientVersion() {
        return clientVersion;
    }

    public void setClientVersion(int clientVersion) {
        this.clientVersion = clientVersion;
    }
}
