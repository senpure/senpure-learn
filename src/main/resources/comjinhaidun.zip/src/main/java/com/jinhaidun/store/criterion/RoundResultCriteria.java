package com.jinhaidun.store.criterion;

import com.senpure.base.criterion.Criteria;

/**
 * Created by 罗中正 on 2017/5/31.
 */
public class RoundResultCriteria extends Criteria {

    private int playerId;

    public int getPlayerId() {
        return playerId;
    }

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public RoundResultCriteria() {
     //  putSort("createTime", AppConstant.ORDER_DESC);

    }
}
