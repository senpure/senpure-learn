package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.ClientResourceVersion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Repository
public interface ClientResourceDao extends JpaRepository<ClientResourceVersion,Integer> ,JpaSpecificationExecutor {


   ClientResourceVersion findByChannelPackage(String cp);
   List<ClientResourceVersion> findByChannelPackageAndResourceVersionGreaterThanEqual(String cp,int version);




}
