package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.DiamondRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/6/7.
 */
@Repository
public interface DiamondRecordDao extends JpaRepository<DiamondRecord,Integer> {
}
