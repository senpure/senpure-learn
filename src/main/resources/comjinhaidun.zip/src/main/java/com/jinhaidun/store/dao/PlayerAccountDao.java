package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.PlayerAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Repository
public interface PlayerAccountDao extends JpaRepository<PlayerAccount,Integer> {

    PlayerAccount findPlayerAccountByTypeAndAccount(String type,String account);


}
