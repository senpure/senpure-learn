package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.Player;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Repository
public interface PlayerDao extends JpaRepository<Player,Integer> ,JpaSpecificationExecutor {


   public Player findPlayerByLoginSession(String loginSession);



}
