package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.PlayerRoundResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/5/31.
 */
@Repository
public interface PlayerRoundResountDao extends JpaRepository<PlayerRoundResult,Integer>,JpaSpecificationExecutor<PlayerRoundResult> {


}
