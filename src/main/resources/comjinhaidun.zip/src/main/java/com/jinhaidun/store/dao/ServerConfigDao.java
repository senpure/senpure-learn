package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.ServerConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Repository
public interface ServerConfigDao extends JpaRepository<ServerConfig,Integer> {

   public ServerConfig findByConfigKey(String key);



}
