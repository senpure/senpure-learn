package com.jinhaidun.store.dao;

import com.jinhaidun.store.entity.Video;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by 罗中正 on 2017/6/6.
 */
public interface VideoDao  extends JpaRepository<Video,Integer> {

    public Video findByRecordIdAndRoundIndex(long recordId,int index);
}
