package com.jinhaidun.store.em;

/**
 * Created by 罗中正 on 2017/4/25.
 */
public enum  ACCOUNT_TYPE {
    WECHAT,
    VISITOR
}
