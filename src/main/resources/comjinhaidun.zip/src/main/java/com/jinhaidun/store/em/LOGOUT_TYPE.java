package com.jinhaidun.store.em;

/**
 * Created by 罗中正 on 2017/4/26.
 */
public enum LOGOUT_TYPE {
    NORMAL,
    OFF_LINE
}
