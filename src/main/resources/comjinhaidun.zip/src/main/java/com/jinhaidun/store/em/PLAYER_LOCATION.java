package com.jinhaidun.store.em;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public enum PLAYER_LOCATION {
    HALL(0),//大厅
    ROOM(1)//房间
    ;
    private int value;

    PLAYER_LOCATION(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
