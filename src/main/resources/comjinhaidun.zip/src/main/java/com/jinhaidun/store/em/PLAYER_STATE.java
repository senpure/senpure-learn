package com.jinhaidun.store.em;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public enum  PLAYER_STATE {

    OFF(0),

    ;
    private int value;

    PLAYER_STATE(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }


}
