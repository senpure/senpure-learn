package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import com.senpure.base.entity.IntEntity;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/5/8.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_client_resource")
public class ClientResourceVersion extends IntEntity {

    private String channelPackage;
    private String url;
    private Date updateDate;
    private Long updateTime;

    private Integer resourceVersion=0;

    public String getChannelPackage() {
        return channelPackage;
    }

    public void setChannelPackage(String channelPackage) {
        this.channelPackage = channelPackage;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Long updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getResourceVersion() {
        return resourceVersion;
    }

    public void setResourceVersion(Integer resourceVersion) {
        this.resourceVersion = resourceVersion;
    }

    @Override
    public String toString() {
        return "ClientResourceVersion{" +
                "channelPackage='" + channelPackage + '\'' +
                ", url='" + url + '\'' +
                ", updateDate=" + updateDate +
                ", updateTime=" + updateTime +
                ", resourceVersion=" + resourceVersion +
                '}';
    }
}
