package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import com.senpure.base.entity.IntEntity;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/6/7.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_diamond_proxy_record")
public class DiamondProxyRecord extends IntEntity {

    private static final long serialVersionUID = -5411496821740720904L;

    private long time;
    private Date date;
    private int diamond;
    private int proxyId;
    private String proxyName;
    private int toProxyId;
    private String toProxyName;
    private String type;
    private String comment;

    public int getDiamond() {
        return diamond;
    }

    public void setDiamond(int diamond) {
        this.diamond = diamond;
    }

    public int getProxyId() {
        return proxyId;
    }

    public void setProxyId(int proxyId) {
        this.proxyId = proxyId;
    }

    public String getProxyName() {
        return proxyName;
    }

    public void setProxyName(String proxyName) {
        this.proxyName = proxyName;
    }

    public int getToProxyId() {
        return toProxyId;
    }

    public void setToProxyId(int toProxyId) {
        this.toProxyId = toProxyId;
    }

    public String getToProxyName() {
        return toProxyName;
    }

    public void setToProxyName(String toProxyName) {
        this.toProxyName = toProxyName;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
