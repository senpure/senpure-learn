package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import com.senpure.base.entity.VersionEntity;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/3/30.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_Player")
public class Player extends VersionEntity {

    private static final long serialVersionUID = 425851639240015132L;
    @Id
  //  @GeneratedValue(generator = "hibernate")
    @GenericGenerator(name = "hibernate", strategy = "assigned")
    private Integer id;
    @Column(nullable = false)
    private Integer diamond=0;
    @Column(nullable = false,length = 32)
    private String nick;
    @Column(nullable = false,length = 255)
    private String head;
    //位置，大厅或房间内
    @Column(nullable = false,length = 12)
     private String location;
    @Column(nullable = false,length = 12)
    private Integer roomId=0;
    @Column(nullable = false)
    private Boolean online=false;
    @Column
    private String loginType;
    private String logoutType;
    private Long loginTime;
    private Date loginDate;
    private Long logoutTime;
    private Date logoutDate;
    private String loginIP;
    private String lastLoginIP;
    @Column(nullable = true,length = 32)
    private String loginSession;
    private Long loginSessionTime;
    private Date loginSessionDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDiamond() {
        return diamond;
    }

    public void setDiamond(Integer diamond) {
        this.diamond = diamond;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Boolean getOnline() {
        return online;
    }

    public void setOnline(Boolean online) {
        this.online = online;
    }

    public String getLoginType() {
        return loginType;
    }

    public void setLoginType(String loginType) {
        this.loginType = loginType;
    }

    public String getLogoutType() {
        return logoutType;
    }

    public void setLogoutType(String logoutType) {
        this.logoutType = logoutType;
    }

    public Long getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Long loginTime) {
        this.loginTime = loginTime;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Date loginDate) {
        this.loginDate = loginDate;
    }

    public Long getLogoutTime() {
        return logoutTime;
    }

    public void setLogoutTime(Long logoutTime) {
        this.logoutTime = logoutTime;
    }

    public Date getLogoutDate() {
        return logoutDate;
    }

    public void setLogoutDate(Date logoutDate) {
        this.logoutDate = logoutDate;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public String getLastLoginIP() {
        return lastLoginIP;
    }

    public void setLastLoginIP(String lastLoginIP) {
        this.lastLoginIP = lastLoginIP;
    }

    public String getLoginSession() {
        return loginSession;
    }

    public void setLoginSession(String loginSession) {
        this.loginSession = loginSession;
    }

    public Long getLoginSessionTime() {
        return loginSessionTime;
    }

    public void setLoginSessionTime(Long loginSessionTime) {
        this.loginSessionTime = loginSessionTime;
    }

    public Date getLoginSessionDate() {
        return loginSessionDate;
    }

    public void setLoginSessionDate(Date loginSessionDate) {
        this.loginSessionDate = loginSessionDate;
    }
}
