package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import com.senpure.base.entity.IntEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/3/30.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_Player_Account")
public class PlayerAccount extends IntEntity {
    @ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.PERSIST})
    @JoinColumn(name = "playerId")
    private Player player;
    @Column(nullable = false,length = 32)
    private String type;
    @Column(nullable = false,length = 128)
    private String account;
    private long bindTime;
    private Date bindDate;

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public long getBindTime() {
        return bindTime;
    }

    public void setBindTime(long bindTime) {
        this.bindTime = bindTime;
    }

    public Date getBindDate() {
        return bindDate;
    }

    public void setBindDate(Date bindDate) {
        this.bindDate = bindDate;
    }
}
