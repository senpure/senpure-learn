package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import com.senpure.base.entity.IntEntity;

import javax.persistence.*;

/**
 * Created by 罗中正 on 2017/5/31.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_Player_round_result")
public class PlayerRoundResult extends IntEntity {

    private int playerId;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name="resultId")
    private RoundResult roundResult;

    public int getPlayerId() {
        return playerId;
    }

    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    public RoundResult getRoundResult() {
        return roundResult;
    }

    public void setRoundResult(RoundResult roundResult) {
        this.roundResult = roundResult;
    }
}
