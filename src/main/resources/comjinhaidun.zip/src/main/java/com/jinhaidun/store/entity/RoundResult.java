package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/5/31.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_ROUND_RESULT")
public class RoundResult{
    @Id
    @GenericGenerator(name = "hibernate", strategy = "assigned")
    private long recordId;
    private int roomId;
    private long createTime;
    private Date createDate;

    @Column(length = 5000)
    private String finallyScore;
    @Column(length = 5000)
    private String deatilScore;


    public long getRecordId() {
        return recordId;
    }

    public void setRecordId(long recordId) {
        this.recordId = recordId;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getFinallyScore() {
        return finallyScore;
    }

    public void setFinallyScore(String finallyScore) {
        this.finallyScore = finallyScore;
    }

    public String getDeatilScore() {
        return deatilScore;
    }

    public void setDeatilScore(String deatilScore) {
        this.deatilScore = deatilScore;
    }


}
