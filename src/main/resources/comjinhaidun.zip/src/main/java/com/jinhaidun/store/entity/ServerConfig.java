package com.jinhaidun.store.entity;

import com.jinhaidun.AppConstant;
import com.senpure.base.entity.IntEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by 罗中正 on 2017/3/31.
 */

@Entity
@Table(name = AppConstant.DB_BASE_PREFIX+"_Server_Config")
public class ServerConfig extends IntEntity {
    private static final long serialVersionUID = 7267783460203784888L;

    @Column(nullable = false,length = 32)
    private  String configKey;
    @Column(nullable = false,length = 128)
    private String configValue;

    public String getConfigKey() {
        return configKey;
    }

    public void setConfigKey(String configKey) {
        this.configKey = configKey;
    }

    public String getConfigValue() {
        return configValue;
    }

    public void setConfigValue(String configValue) {
        this.configValue = configValue;
    }
}
