package com.jinhaidun.store.handler;


import com.senpure.base.result.ResultMap;
import com.senpure.base.spring.BaseController;

/**
 * Created by 罗中正 on 2017/5/9.
 */
public class ClientConlroller extends BaseController {

    protected ResultMap getSuccessResult()
    {
        ResultMap resultMap=ResultMap.getSuccessResult();
        resultMap.put("result",resultMap.getCode());
        return  resultMap;
    }
    protected ResultMap getDimResult()
    {
        ResultMap resultMap=ResultMap.getDimResult();
        resultMap.put("result",0);
        resultMap.put("resultinfo","服务器繁忙，请稍后再试！");
        return  resultMap;
    }
}
