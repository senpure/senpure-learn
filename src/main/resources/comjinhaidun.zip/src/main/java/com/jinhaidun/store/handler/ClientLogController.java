package com.jinhaidun.store.handler;


import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by 罗中正 on 2017/4/26.
 */
@Controller
@RequestMapping(value = "/game")
public class ClientLogController extends BaseController {
}
