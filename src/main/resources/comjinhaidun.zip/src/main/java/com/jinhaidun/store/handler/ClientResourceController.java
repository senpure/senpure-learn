package com.jinhaidun.store.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jinhaidun.AppConstant;
import com.jinhaidun.store.criterion.ClientResourceCriteria;
import com.jinhaidun.store.dao.ClientResourceDao;
import com.jinhaidun.store.entity.ClientResourceVersion;
import com.jinhaidun.store.init.IPGeter;
import com.jinhaidun.store.service.ClientResourceService;
import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.result.ResultMap;
import com.senpure.base.struct.KeyValue;
import com.senpure.base.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Created by 罗中正 on 2017/5/8.
 */
@Controller
@RequestMapping(value = "/game")
@MenuGenerator(id = 20,text = "游戏管理",icon = "fa fa-gamepad  faa-float")
public class ClientResourceController extends ClientConlroller {

    public static String RESOURCE_PATH = "ext" + File.separator + "resource";
    @Autowired
    private ClientResourceDao clientResourceDao;
    @Autowired
    private ClientResourceService clientResourceService;

    private String getFileName(int start, int now) {

        return "update_" + start + "_" + now + "_resource.zip";
    }

    private ConcurrentHashMap<String, ReadWriteLock> lockMap = new ConcurrentHashMap<>();

    @RequestMapping(value = "/version")
    @ResponseBody
    public Object resources(HttpServletRequest request, @RequestBody(required = false) String clientJson) {
        try {

            if (StringUtil.isNullOrEmpty(clientJson)) {
                JSONObject jo = new JSONObject();
                jo.put("osversion", "IOS");
                jo.put("resource", "1");
                clientJson = jo.toJSONString();
            }

            logger.debug("--- befor-clientJson:{}", clientJson);
            clientJson = URLDecoder.decode(clientJson, "utf-8");
            logger.debug("--- after -clientJson:{}", clientJson);
            if (clientJson.endsWith("=")) {
                clientJson = clientJson.substring(0, clientJson.length() - 1);
                logger.debug("--- after -clientJson:{}", clientJson);
            }
            JSONObject jsonObject = JSON.parseObject(clientJson);
            // int resource = jsonObject.getIntValue("resource");
            String os = jsonObject.getString("osversion");
            int clientVersion = jsonObject.getIntValue("resource");
            if (os == null) {
                os = "IOS";
            }
            os = os.toUpperCase();
            ClientResourceVersion cv = clientResourceService.currentResource(os);
            logger.debug("cv {}", cv);
            if (cv.getUrl() == null) {
                os = "IOS";
                cv = clientResourceService.currentResource(os);
            }
            logger.debug("cv {}", cv);
            //jsonObject.get("vsersion");
            ResultMap resultMap = getSuccessResult();
            resultMap.put("version", cv.getResourceVersion());
            String url = cv.getUrl();
            if (url == null) {
                logger.info("服务器尚未更新资源");
                return resultMap;
            }
            logger.debug("url {}", url);
            if (cv.getResourceVersion() - clientVersion > 1) {
                String fileName = getFileName(clientVersion, cv.getResourceVersion());
                logger.debug("fileName {}", fileName);
                lockMap.putIfAbsent(fileName, new ReentrantReadWriteLock(false));
                ReadWriteLock lock = lockMap.get(fileName);
                lock.readLock().lock();
                File file =
                        Paths.get(RESOURCE_PATH, fileName).toAbsolutePath().toFile();
                logger.debug("file {} {}", file.getAbsolutePath(), file.exists());
                if (!file.exists()) {
                    lock.readLock().unlock();
                    lock.writeLock().lock();
                    if (!file.exists()) {
                        clientResourceService.generateFile(os, clientVersion, file, RESOURCE_PATH);
                    }
                    lock.writeLock().unlock();
                }
                url = fileName;
            }
            if (url.startsWith("http")) {
            } else {
                url = "http://"+ IPGeter.getIp()+":" + request.getLocalPort() + "/ext/resource/" + url;
            }

            if (cv.getResourceVersion() > clientVersion) {
                resultMap.put("url", url);
            }

            resultMap.put("time", AppConstant.DFM.format(cv.getUpdateDate()));
            return resultMap;
        } catch (Exception e) {
            logger.error(",", e);
        }
        return getDimResult();
    }

    private Object getCpList() {

        List<KeyValue<String, String>> keyValues = new ArrayList<>();

        KeyValue<String, String> keyValue = new KeyValue();
        keyValue.setKey("IOS");
        keyValue.setValue("IOS_PACKAGE");

        keyValues.add(keyValue);

        keyValue = new KeyValue();
        keyValue.setKey("ANDROID");
        keyValue.setValue("ANDROID_PACKAGE");
        keyValues.add(keyValue);
        return keyValues;
    }


    @RequestMapping(value = "/updateResource", method = {RequestMethod.GET})
    @PermissionVerify("资源管理页面")
    @MenuGenerator(id = 21,text = "资源管理",uri = "/game/updateResource")
    public ModelAndView updateResource(HttpServletRequest request, @ModelAttribute("criteria") ClientResourceCriteria criteria) {

        if (StringUtil.isNullOrEmpty(criteria.getCp())) {
            criteria.setCp("IOS");
        }
        int version = clientResourceService.currentResourceVersion(criteria.getCp());
        criteria.setClientVersion(version + 1);
        ResultMap resultMap = ResultMap.getSuccessResult();
        resultMap.put("cplist", getCpList());
        return new ModelAndView("game/resource").addObject("cplist", getCpList());
    }

    @RequestMapping(value = "/updateResource", method = {RequestMethod.POST})
    @PermissionVerify("修改游戏资源")

    public ModelAndView updateResource(HttpServletRequest request,
                                       @ModelAttribute("criteria") ClientResourceCriteria criteria,
                                       @RequestParam(name = "resource")
                                               MultipartFile resource) {

        ResultMap resultMap = ResultMap.getSuccessResult();
        try {
            logger.debug(criteria.getCp());
            if (!resource.isEmpty()) {
                String saveName = AppConstant.DFS_COMPACT.format(new Date()) + "_" + resource.getOriginalFilename();
                clientResourceService.updateResource(criteria.getCp(), criteria.getClientVersion(), saveName);
                // File file = Paths.get("ext" + File.separator + "resource", saveName).toAbsolutePath().toFile();
                // logger.debug(file.getAbsolutePath());
                // file.createNewFile();
                Files.copy(resource.getInputStream(), Paths.get("ext" + File.separator + "resource", saveName));
                ClientResourceVersion cv = clientResourceService.currentResource(criteria.getCp());

                criteria.setClientVersion(cv.getResourceVersion() + 1);

            }
        } catch (IOException e) {
            logger.error("", e);
            resultMap = ResultMap.getDimResult();
        }

        putCpList(resultMap);
        return addActionResult(request, new ModelAndView("game/resource"), resultMap);

    }

    private void putCpList(ResultMap resultMap) {
        resultMap.put("cplist", getCpList());
    }

    @PostConstruct
    public void createExtResourceFloder() {

        File file = Paths.get("ext" + File.separator + "resource").toFile();
        if (!file.exists()) {
            file.mkdirs();
        }

        logger.debug("ext resource " + file.getAbsolutePath());
    }

    private void createFile() {

    }
}
