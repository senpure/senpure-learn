package com.jinhaidun.store.handler;

import com.jinhaidun.store.service.DiamondService;
import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.result.Result;
import com.senpure.base.result.ResultHelper;
import com.senpure.base.result.ResultMap;
import com.senpure.base.service.AuthorizeService;
import com.senpure.base.spring.BaseController;
import com.senpure.base.struct.LoginedAccount;
import com.senpure.base.util.Http;
import com.senpure.base.vo.AccountVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 罗中正 on 2017/6/7.
 */
@Controller
@RequestMapping("/game/diamond")
@MenuGenerator(id = 30, text = "钻石管理", icon = "fa fa-diamond faa-float")
public class DiamondController extends BaseController {

    @Autowired
    private DiamondService diamondService;

    @Autowired
    private AuthorizeService authorizeService;

    @RequestMapping("/add")
    @PermissionVerify(value = "增加玩家钻石页面")
    @MenuGenerator(id = 31, text = "增加钻石", uri = "/game/diamond/add")
    public ModelAndView daimon(HttpServletRequest request) {


        return view(request, "game/addDiamond");
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @PermissionVerify(value = "增加玩家钻石 ")

    public ModelAndView addDaimon(HttpServletRequest request, int playerId, int diamond) {

        if (diamond > 2000) {
            ResultMap resultMap = ResultMap.getResult(Result.DAIMOND_TOO_MUCH);
            resultMap.put("playerId", playerId);
            ResultHelper.wrapMessage(resultMap, localeResolver.resolveLocale(request), 2000 + "");
            return
                    addActionResult(request, new ModelAndView("game/addDiamond"), resultMap, false);
        }
        LoginedAccount account = Http.getSubject(request);
        diamondService.addDiamon(playerId, diamond, account.getId());
        account.setDiamond(account.getDiamond() - diamond);
        return success(request, "game/addDiamond");
    }

    @RequestMapping(value = "/proxy/add/{accountId}", method = RequestMethod.GET)
    @PermissionVerify(value = "增加代理钻石页面 ")
    public ModelAndView addProxyDaimon(HttpServletRequest request, @PathVariable int accountId, Model model) {

        AccountVo accountVo = authorizeService.loadAccount(accountId);
        if (accountVo == null) {

            // diamondService.addDiamon(playerId, diamond, Http.getSubject(request).getId());
            return dim(request);
        }
        model.addAttribute("proxy", accountVo);
        return view(request, "game/ProxyAddDiamond");
    }

    @RequestMapping(value = "/proxy/add", method = RequestMethod.POST)
    @PermissionVerify(value = "增加代理钻石 ")
    public ModelAndView addProxyDaimon(HttpServletRequest request, int accountId, int diamond) {

        if (diamond > 50000) {
            ResultMap resultMap = ResultMap.getResult(Result.DAIMOND_TOO_MUCH);
            ResultHelper.wrapMessage(resultMap, localeResolver.resolveLocale(request), 50000 + "");

            return
                    view(request, "game/ProxyAddDiamond", resultMap);
        }
        // diamondService.addDiamon(playerId, diamond, Http.getSubject(request).getId());
        LoginedAccount account = Http.getSubject(request);
        ResultMap resultMap = diamondService.addProxyDiamond(account.getId(), accountId, diamond);
        if (resultMap.isSuccess()) {

            account.setDiamond(account.getDiamond() - diamond);
            LoginedAccount toAccount = Http.getSubject(accountId);
            if(toAccount!=null)
            {
                toAccount.setDiamond(toAccount.getDiamond() + diamond);
            }
        }

        return result(request, "game/ProxyAddDiamond", resultMap);
    }

    @RequestMapping("/replenish")
    @PermissionVerify("补充钻石")
    @MenuGenerator(id = 32, text = "补充钻石")
    public ModelAndView replenish(HttpServletRequest request) {
        LoginedAccount account = Http.getSubject(request);


        int diamond = diamondService.replenishDiamond(Http.getSubject(request).getId());
        account.setDiamond(account.getDiamond() + diamond);
        return success(request, "game/replenish");
    }
}
