package com.jinhaidun.store.handler;


import com.senpure.base.result.ResultMap;
import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.nio.file.Paths;

/**
 * Created by 罗中正 on 2017/5/9.
 */
@Controller
@RequestMapping("/ext")
public class ExtController extends BaseController {

    @RequestMapping("/resource/{name:.+}")
    public ModelAndView extResource(HttpServletRequest request,@PathVariable String name)
    {
        File file=
        Paths.get("ext"+File.separator+"resource",name).toAbsolutePath().toFile();
       logger.debug(file.getAbsoluteFile()+""+file.exists());
        ResultMap resultMap=ResultMap.getSuccessResult();
        resultMap.put(ResultMap.FILE_KEY,file);
        return addActionResult(request,new ModelAndView(""),resultMap);
    }
    @RequestMapping({"/resources/image/{name:.+}"})
    public ModelAndView extImage(HttpServletRequest request,@PathVariable String name)
    {
        File file=
                Paths.get("ext"+File.separator+ "resources/image",name).toAbsolutePath().toFile();
       logger.debug(file.getAbsoluteFile()+""+file.exists());
        ResultMap resultMap=ResultMap.getSuccessResult();
        resultMap.put(ResultMap.FILE_KEY,file);
        return addActionResult(request,new ModelAndView(""),resultMap);
    }

    @PostConstruct
    public void createExtFloder() {

        File file = Paths.get("ext" + File.separator + "resource").toFile();
        if (!file.exists()) {
            file.mkdirs();
        }
       logger.debug("ext resource " + file.getAbsolutePath());

        file = Paths.get("ext" + File.separator + "resources/image").toFile();
        if (!file.exists()) {
            file.mkdirs();
        }
       logger.debug("ext resources.image " + file.getAbsolutePath());
    }

}
