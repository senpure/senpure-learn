package com.jinhaidun.store.handler;

import com.alibaba.fastjson.JSONObject;
import com.jinhaidun.store.init.IPGeter;
import com.senpure.base.result.ResultMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/6/7.
 */
@Controller
@RequestMapping("/game")
public class NoticeController extends ClientConlroller {


    @RequestMapping("/notice")
    @ResponseBody
    public Map notice(HttpServletRequest request)
    {
        ResultMap map = getSuccessResult();

      String url=  "http://"+ IPGeter.getIp()+":" + request.getLocalPort();
        List<JSONObject> jsonObjects = new ArrayList<>();
        for (int i = 0; i <3 ; i++) {
            JSONObject jsonObject=new JSONObject();

            jsonObject.put("title","title"+(i+1));
            jsonObject.put("type","notice");
            jsonObject.put("img",url+"/ext/resources.image/pic.png");
            jsonObjects.add(jsonObject);

        }

        map.put("notices", jsonObjects);
        return map;
    }
    @RequestMapping("/notice/add")
    public ModelAndView noticeAddView(HttpServletRequest request)
    {
        return  view(request,"game/addNotice");
    }
}
