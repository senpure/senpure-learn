package com.jinhaidun.store.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jinhaidun.store.init.IPGeter;
import com.jinhaidun.store.service.PlayerService;
import com.jinhaidun.store.service.WeChatService;
import com.jinhaidun.store.vo.PlayerVo;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.result.Result;
import com.senpure.base.result.ResultMap;
import com.senpure.base.spring.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/4/25.
 */
@Controller
@RequestMapping(value = "/game")
public class PlayerController extends BaseController {
    @Autowired
    private PlayerService playerService;
    @Autowired
    private WeChatService weChatService;

    @RequestMapping(value = "/login")
    @ResponseBody
    public Object playerLogin(@RequestBody(required = false) String clientJson) {

        //  ResultMap resultMap = ResultMap.getResult(Result.FAILURE);
        Map<String, Object> resultMap = new HashMap<>();
        int result = 0;

        try {

            logger.debug("--- befor-clientJson:{}", clientJson);
            clientJson = URLDecoder.decode(clientJson, "utf-8");
            logger.debug("--- after -clientJson:{}", clientJson);
            if (clientJson.endsWith("=")) {
                clientJson = clientJson.substring(0, clientJson.length() - 1);
                logger.debug("--- after -clientJson:{}", clientJson);
            }
            JSONObject jsonObject = JSON.parseObject(clientJson);
            String account = jsonObject.getString("account");
            //String type = ACCOUNT_TYPE.VISITOR.toString();
            String type = jsonObject.getString("type");
            Map<String, Object> context = new HashMap<>();

            resultMap = playerService.findId(account, type, context);
            resultMap.put("ip", IPGeter.getIp());
            resultMap.put("port", "8007");
            result = 1;
        } catch (Exception e) {
            logger.error("",e);
        }

        resultMap.put("result", result);
        if (result == 0) {
            resultMap.put("resultinfo", "服务器繁忙，请稍后再试！");
        }
        logger.debug(resultMap.toString());
        return resultMap;
    }

    @RequestMapping(value = "/player/{playerId}")
    @PermissionVerify(verify = false)
    public ModelAndView playerInfo(HttpServletRequest request, @PathVariable int playerId) {
        PlayerVo playerVo = playerService.loadPlayer(playerId);
        if (playerVo == null) {

          return   result(request, "game/player/info", ResultMap.getResult(Result.PLAYER_ID_NOT_EXIST));
        }
        return result(request, "game/player/info", ResultMap.getResult(Result.SUCCESS).put("info", playerVo));

    }
}
