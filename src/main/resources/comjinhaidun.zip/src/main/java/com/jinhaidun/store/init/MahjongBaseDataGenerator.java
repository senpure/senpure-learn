package com.jinhaidun.store.init;

import com.jinhaidun.AppConstant;
import com.jinhaidun.store.dao.SequenceDao;
import com.jinhaidun.store.entity.Sequence;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * Created by Administrator on 2017/3/1.
 */
@Component
@Order(value = 100)
public class MahjongBaseDataGenerator implements ApplicationListener<ContextRefreshedEvent> {
    private static Logger LOG = LogManager.getLogger(MahjongBaseDataGenerator.class);

    @Autowired
    private SequenceDao sequenceDao;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {

        checkAndGenerateSequence();


    }
    private void checkAndgenerateRoot()
    {}
    private void checkAndGenerateSequence()
    {
        Sequence sequence= sequenceDao.findSequenceByType(AppConstant.PLAYER_ID_SEQUENCE_TYPE);
        if(sequence==null)
        {
            LOG.debug("玩家id序列为空 进行填充");
            sequence=new Sequence();
            sequence.setType(AppConstant.PLAYER_ID_SEQUENCE_TYPE);
            sequence.setDigit(6);
            sequence.setSpan(1);
            sequence.setSequence(AppConstant.PLAYER_ID_SEQUENCE_START_VALUE);
            sequenceDao.save(sequence);
        }
    }


}
