package com.jinhaidun.store.scheduler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by 罗中正 on 2017/4/26.
 */
public class SchedulerSupport {

    protected Logger log;

    public SchedulerSupport() {
        log= LogManager.getLogger(getClass());
    }
}
