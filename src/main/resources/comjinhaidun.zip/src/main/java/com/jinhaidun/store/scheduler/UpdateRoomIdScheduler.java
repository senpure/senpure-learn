package com.jinhaidun.store.scheduler;

import com.jinhaidun.store.dao.PlayerDao;
import com.jinhaidun.store.em.LOGOUT_TYPE;
import com.jinhaidun.store.entity.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.Predicate;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/26.
 */
@Component
public class UpdateRoomIdScheduler extends SchedulerSupport {

    @Autowired
    private PlayerDao playerDao;
    private long checkTime = 6 * 60 * 1000;
    @Scheduled(cron = "0/30 * *  * * ? ")
    @Transactional
    public void updateRoomId() {
        List<Player> players = playerDao.findAll((root, query, builder) -> {
            Predicate roomId = builder.greaterThan(root.get("roomId"), 0);
            Predicate online = builder.equal(root.get("online"), false);
            Predicate logout = builder.lessThan(root.get("logoutTime"), System.currentTimeMillis() - checkTime);
            Predicate outType = builder.equal(root.get("logoutType"), LOGOUT_TYPE.OFF_LINE.toString());
            return builder.and(roomId, online, logout, outType);
        });
        players.forEach(player -> player.setRoomId(0));
        playerDao.save(players);

    }
}
