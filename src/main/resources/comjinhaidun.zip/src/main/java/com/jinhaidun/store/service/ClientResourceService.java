package com.jinhaidun.store.service;


import com.jinhaidun.store.dao.ClientResourceDao;
import com.jinhaidun.store.dao.ServerConfigDao;
import com.jinhaidun.store.entity.ClientResourceVersion;
import com.jinhaidun.store.entity.ServerConfig;
import com.senpure.base.service.BaseService;
import com.senpure.base.util.ZipUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

/**
 * Created by 罗中正 on 2017/5/8.
 */
@Service
@Transactional
public class ClientResourceService extends BaseService {
    @Autowired
    private ClientResourceDao clientResourceDao;

    @Autowired
    private ServerConfigDao serverConfigDao;

    public int currentResourceVersion(String cp) {

        return getResource(cp).getResourceVersion();
    }

    public ClientResourceVersion currentResource(String cp) {

        ClientResourceVersion cv = getResource(cp);
        cv.getResourceVersion();
        return cv;
    }

    private String getKey(String cp) {

        return "last_" + cp.toLowerCase() + "_update_resource_id";
    }

    private ClientResourceVersion getResource(String cp) {

        ServerConfig serverConfig = serverConfigDao.findByConfigKey(getKey(cp));
        ClientResourceVersion clientResourceVersion = null;
        if (serverConfig == null) {
            clientResourceVersion = new ClientResourceVersion();
            Date now = new Date();
            clientResourceVersion.setChannelPackage(cp);
            clientResourceVersion.setUpdateDate(now);
            clientResourceVersion.setUpdateTime(now.getTime());
            clientResourceVersion.setResourceVersion(1);
        } else {
            clientResourceVersion = clientResourceDao.findOne(Integer.parseInt(serverConfig.getConfigValue()));
        }
        return clientResourceVersion;
    }

    public void updateResource(String cp, int clientVersion, String url) {
        ClientResourceVersion last = getResource(cp);
        ClientResourceVersion clientResourceVersion = new ClientResourceVersion();
        clientResourceVersion.setUrl(url);
        Date now = new Date();
        clientResourceVersion.setUpdateDate(now);
        clientResourceVersion.setUpdateTime(now.getTime());
        clientResourceVersion.setChannelPackage(cp);
        int upVersion = clientVersion == 0 ? last.getResourceVersion() + 1 : clientVersion;
        upVersion = upVersion > last.getResourceVersion() ? upVersion : last.getResourceVersion();
        clientResourceVersion.setResourceVersion(upVersion);
        clientResourceDao.save(clientResourceVersion);
        String key = getKey(cp);
        ServerConfig serverConfig = serverConfigDao.findByConfigKey(key);

        if (serverConfig == null) {
            serverConfig=new ServerConfig();
            serverConfig.setConfigKey(key);
        }
        serverConfig.setConfigValue(clientResourceVersion.getId() + "");
        serverConfigDao.save(serverConfig);

    }


    public void generateFile(String cp, int start, File file, String path) {
        List<ClientResourceVersion> clientResourceVersions = clientResourceDao.findByChannelPackageAndResourceVersionGreaterThanEqual(cp, start);
        int size = clientResourceVersions.size();
        File[] files = new File[size];
        for (int i = 0; i < size; i++) {
            ClientResourceVersion cv = clientResourceVersions.get(i);
            files[i] = Paths.get(path, cv.getUrl()).toAbsolutePath().toFile();

        }
        ZipUtil.mergeZip(file, files);

    }

    public List<ClientResourceVersion> getResources(String cp, int start) {
        List<ClientResourceVersion> clientResourceVersions = clientResourceDao.findByChannelPackageAndResourceVersionGreaterThanEqual(cp, start);

        return clientResourceVersions;
    }
}
