package com.jinhaidun.store.service;

import com.alibaba.fastjson.JSONObject;
import com.jinhaidun.store.dao.DiamondPrxoyRecordDao;
import com.jinhaidun.store.dao.DiamondRecordDao;
import com.jinhaidun.store.dao.PlayerDao;
import com.jinhaidun.store.entity.DiamondProxyRecord;
import com.jinhaidun.store.entity.DiamondRecord;
import com.jinhaidun.store.entity.Player;
import com.senpure.base.dao.AccountDao;
import com.senpure.base.entity.Account;
import com.senpure.base.result.Result;
import com.senpure.base.result.ResultMap;
import com.senpure.base.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * Created by 罗中正 on 2017/6/7.
 */
@Service
public class DiamondService extends BaseService {

    @Autowired
    private PlayerDao playerDao;

    @Autowired
    private AccountDao accountDao;

    @Autowired
    private DiamondRecordDao diamondRecordDao;
    @Autowired
    private DiamondPrxoyRecordDao diamondPrxoyRecordDao;

    @Transactional
    public ResultMap addDiamon(int playerId, int diamond, int proxyId) {
        Account account = accountDao.findOne(proxyId);
        if (account.getDiamond() < diamond) {

            return ResultMap.getResult(Result.DAIMOND_PROXY_LACK);
        }

        if (diamond > 0) {
            account.setDiamond(account.getDiamond() - diamond);
            accountDao.save(account);
        }
        Player player = playerDao.findOne(playerId);

        player.setDiamond(player.getDiamond() + diamond);
        if (player.getDiamond() < 0) {
            logger.warn("玩家钻石为负 playerId {} ,diamond{}", playerId, player.getDiamond());
        }
        playerDao.save(player);
        DiamondRecord diamondRecord = new DiamondRecord();

        diamondRecord.setDate(new Date());
        diamondRecord.setTime(diamondRecord.getDate().getTime());

        diamondRecord.setDiamond(diamond);

        diamondRecord.setType("PROXY");
        diamondRecord.setPlayerId(playerId);
        diamondRecord.setPlayerName(player.getNick());
        diamondRecord.setProxyId(proxyId);
        diamondRecord.setProxyName(account.getName());
        diamondRecordDao.save(diamondRecord);
        // PlayerVo playerVo = ConvertUtil.convert(player);
        return ResultMap.getSuccessResult();
    }

    @Transactional
    public void useDiamon(int playerId, int diamond, int roomId) {

        Player player = playerDao.findOne(playerId);
        player.setDiamond(player.getDiamond() - diamond);
        if (player.getDiamond() < 0) {
            logger.warn("玩家钻石为负 playerId {} ,diamond{}", playerId, player.getDiamond());
        }
        playerDao.save(player);
        DiamondRecord diamondRecord = new DiamondRecord();
        diamondRecord.setType("GAME");
        diamondRecord.setDate(new Date());
        diamondRecord.setTime(diamondRecord.getDate().getTime());
        diamondRecord.setPlayerId(playerId);
        diamondRecord.setPlayerName(player.getNick());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("roomId", roomId);
        diamondRecord.setComment(jsonObject.toJSONString());
        diamondRecordDao.save(diamondRecord);
    }

    @Transactional
    public ResultMap addProxyDiamond(int prxoyId, int toProxyId, int diamond) {
        Account proxy = accountDao.findOne(prxoyId);
        if (proxy.getDiamond() < diamond) {
            return ResultMap.getResult(Result.DAIMOND_PROXY_LACK);
        }
        Account to = accountDao.findOne(toProxyId);
        to.setDiamond(to.getDiamond() + diamond);
        if (to.getDiamond() < 0) {
            logger.warn("代理钻石为负 account {}, name{} ,diamond {}", to.getAccount(), to.getName(), to.getDiamond());
        }

        DiamondProxyRecord record = new DiamondProxyRecord();
        Date now = new Date();
        record.setDate(now);
        record.setDiamond(diamond);
        record.setProxyId(prxoyId);
        record.setProxyName(proxy.getName());
        record.setToProxyId(toProxyId);
        record.setToProxyName(to.getName());
        record.setType("NORMAL");
        diamondPrxoyRecordDao.save(record);
        accountDao.save(to);
        if(diamond>0)
        {
            proxy.setDiamond(proxy.getDiamond() - diamond);
            accountDao.save(proxy);
        }
        return ResultMap.getSuccessResult();
    }
@Transactional
    public int  replenishDiamond(int accountId)
    {

        Account account=accountDao.findOne(accountId);

        int diamond=200000-account.getDiamond();
        if(diamond!=0)
        {
            account.setDiamond(200000);
            DiamondProxyRecord record=new DiamondProxyRecord();
            Date now = new Date();
            record.setDate(now);
            record.setDiamond(diamond);
            record.setProxyId(account.getId());
            record.setProxyName(account.getName());
            record.setToProxyId(account.getId());
            record.setToProxyName(account.getName());
            record.setType("REPLENISH");
            diamondPrxoyRecordDao.save(record);
            accountDao.save(account);
        }
        return  diamond;
    }
}
