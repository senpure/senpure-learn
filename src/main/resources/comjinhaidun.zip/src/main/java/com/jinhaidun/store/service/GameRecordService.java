package com.jinhaidun.store.service;

import com.jinhaidun.store.criterion.RoundResultCriteria;
import com.jinhaidun.store.dao.PlayerRoundResountDao;
import com.jinhaidun.store.dao.RoundResountDao;
import com.jinhaidun.store.dao.VideoDao;
import com.jinhaidun.store.entity.PlayerRoundResult;
import com.jinhaidun.store.entity.RoundResult;
import com.jinhaidun.store.entity.Video;
import com.jinhaidun.store.util.ConvertUtil;
import com.jinhaidun.store.vo.RoundResultVo;
import com.jinhaidun.store.vo.VideoVo;
import com.senpure.base.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/5/31.
 */
@Service
public class GameRecordService extends BaseService {

    @Autowired
    RoundResountDao roundResountDao;
    @Autowired
    private PlayerRoundResountDao playerRoundResountDao;
    @Autowired
    private VideoDao videoDao;

    public void saveRoundRecord(RoundResult record) {
        roundResountDao.save(record);

    }

    public void savePlayerRecord(List<PlayerRoundResult> records, List<Video> videos) {
        playerRoundResountDao.save(records);
        videoDao.save(videos);

    }

    public List<RoundResultVo> loadRoundResult(RoundResultCriteria criteria) {


        Pageable pageable = getPage(criteria);

        Page<PlayerRoundResult> playerRoundResults = playerRoundResountDao.findAll(new Specification<PlayerRoundResult>() {
            @Override
            public Predicate toPredicate(Root<PlayerRoundResult> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {


                criteriaQuery.orderBy(criteriaBuilder.desc(root.get("roundResult").get("createTime")));
                return criteriaBuilder.equal(root.get("playerId"), criteria.getPlayerId());
            }
        }, pageable);

        List<RoundResultVo> roundResultVos = new ArrayList<>();
        playerRoundResults.getContent().forEach(playerRoundResult -> {
            roundResultVos.add(ConvertUtil.convert(playerRoundResult.getRoundResult()));
        });
        return roundResultVos;
    }

    public VideoVo loadVideo(long recordId, int index) {

        Video video = videoDao.findByRecordIdAndRoundIndex(recordId, index);

        if (video == null) {
            return null;
        }
        return ConvertUtil.convert(video);
    }

}
