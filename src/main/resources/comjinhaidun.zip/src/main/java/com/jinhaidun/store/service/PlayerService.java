package com.jinhaidun.store.service;

import com.jinhaidun.AppConstant;
import com.jinhaidun.store.dao.PlayerAccountDao;
import com.jinhaidun.store.dao.PlayerDao;
import com.jinhaidun.store.em.ACCOUNT_TYPE;
import com.jinhaidun.store.em.PLAYER_LOCATION;
import com.jinhaidun.store.entity.Player;
import com.jinhaidun.store.entity.PlayerAccount;
import com.jinhaidun.store.util.ConvertUtil;
import com.jinhaidun.store.vo.PlayerVo;
import com.senpure.base.result.ResultMap;
import com.senpure.base.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/4/25.
 */
@Service
@Transactional
public class PlayerService extends BaseService {

    public static final String THIRD_ACCOUNT = "thirdAccount";
    public static final String LOGIN_TYPE = "loginType";
    private  int initDiamond=2;
    @Autowired
    private PlayerAccountDao accountDao;
    @Autowired
    private PlayerDao playerDao;
    @Autowired
    private WeChatService weChatService;
    @Autowired
    private SequenceService sequenceService;

    public PlayerVo playerLogin(String loginSession, Map<String, Object> context) {

        Player player = playerDao.findPlayerByLoginSession(loginSession);
        if (player != null) {
            player.setOnline(true);

            player.setLastLoginIP(player.getLoginIP());
            Object ip = context.get("ip");
            if (ip != null) {
                player.setLoginIP(ip.toString());
            }
            Date now = new Date();
            player.setLoginTime(now.getTime());
            player.setLoginDate(now);
            playerDao.save(player);
            return ConvertUtil.convert(player);
        }
        return null;
    }

    public ResultMap findId(String account, String type, Map<String, Object> context) {
        //String thirdAccount=context.get(THIRD_ACCOUNT).toString();
        // String loginType=context.get(LOGIN_TYPE).toString();
        Date now = new Date();
        String loginSession = java.util.UUID.randomUUID().toString().replace("-", "");
        if (type.equalsIgnoreCase(ACCOUNT_TYPE.VISITOR.toString())) {
            PlayerAccount playerAccount = accountDao.
                    findPlayerAccountByTypeAndAccount(ACCOUNT_TYPE.VISITOR.toString(), account);
            Player player = null;
            if (playerAccount == null) {
                player = new Player();
                String id = sequenceService.nextSequence(AppConstant.PLAYER_ID_SEQUENCE_TYPE);
                logger.debug("id = {}", id);
                player.setId(Integer.valueOf(id));

                player.setDiamond(initDiamond);
                player.setHead("");
                player.setNick("玩家[" + player.getId() + "]");
                player.setLocation(PLAYER_LOCATION.HALL.toString());
                player.setLoginSession(loginSession);
                playerAccount = new PlayerAccount();
                playerAccount.setAccount(account);
                playerAccount.setType(ACCOUNT_TYPE.VISITOR.toString());


                playerAccount.setBindDate(now);
                playerAccount.setBindTime(now.getTime());
                playerAccount.setPlayer(player);
                //accountDao.save(playerAccount);

            } else {
                player = playerAccount.getPlayer();

            }
            player.setLoginSession(loginSession);
            player.setLoginSessionDate(now);
            player.setLoginSessionTime(now.getTime());
            accountDao.save(playerAccount);
            return ResultMap.getSuccessResult().put("token", loginSession);

        } else if (type.equalsIgnoreCase(ACCOUNT_TYPE.WECHAT.toString())) {

            weChatService.getWechatAccessToken(account, context);
            return playerLoginSession(context.get("thirdId").toString(), ACCOUNT_TYPE.WECHAT.toString(), context, true);

        }
        return ResultMap.getSuccessResult().put("token", loginSession);

    }

    private ResultMap playerLoginSession(String account, String type, Map<String, Object> context, boolean updateInfo) {
        Date now = new Date();
        String loginSession = java.util.UUID.randomUUID().toString().replace("-", "");
        PlayerAccount playerAccount = accountDao.
                findPlayerAccountByTypeAndAccount(type, account);
        Player player = null;
        Object ho = context.get("head");
        Object no = context.get("nick");
        String head = "";
        String nick = "";
        if (ho != null) {
            head = ho.toString();

        }
        if (no != null) {
            nick = no.toString();
        }
        if (playerAccount == null) {
            player = new Player();
            String id = sequenceService.nextSequence(AppConstant.PLAYER_ID_SEQUENCE_TYPE);
            logger.debug("id = {}", id);
            player.setId(Integer.valueOf(id));
            player.setDiamond(initDiamond);
            player.setHead(head);
            player.setNick(nick);
            player.setLocation(PLAYER_LOCATION.HALL.toString());
            player.setLoginSession(loginSession);
            playerAccount = new PlayerAccount();
            playerAccount.setAccount(account);
            playerAccount.setType(type.toUpperCase());
            playerAccount.setBindDate(now);
            playerAccount.setBindTime(now.getTime());
            playerAccount.setPlayer(player);
            //accountDao.save(playerAccount);

        } else {
            player = playerAccount.getPlayer();
            if (updateInfo) {
                player.setHead(head);
                player.setNick(nick);
            }

        }
        player.setLoginSession(loginSession);
        player.setLoginSessionDate(now);
        player.setLoginSessionTime(now.getTime());
        accountDao.save(playerAccount);

        return ResultMap.getSuccessResult().put("token", loginSession);
    }


    public PlayerVo loadPlayer(int playerId) {
        Player player = playerDao.findOne(playerId);

        if (player != null) {

          return   ConvertUtil.convert(player);
        }


        return null;
    }


    public PlayerVo loadPlayer(String type, String account) {
        PlayerAccount playerAccount = accountDao.
                findPlayerAccountByTypeAndAccount(type, account);
        if (playerAccount != null) {
            logger.debug("account{}", playerAccount);
            Player player = playerAccount.getPlayer();
            return ConvertUtil.convert(player);
        }
        return null;
    }

    public void updatePlayer(PlayerVo vo) {
        Player player = playerDao.findOne(vo.getId());
        ConvertUtil.convert(vo, player);
        playerDao.save(player);

    }


    public static void main(String[] args) {

        String str = java.util.UUID.randomUUID().toString();

        System.out.println(str + "," + str.length());
    }
}
