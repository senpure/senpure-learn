package com.jinhaidun.store.service;


import com.jinhaidun.store.dao.SequenceDao;
import com.jinhaidun.store.entity.Sequence;
import com.senpure.base.service.ServiceSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Service
public class SequenceService extends ServiceSupport {

    @Autowired
    private SequenceDao dao;
    public String nextSequence(String type) {
        Sequence sequence = dao.findSequenceByType(type);
        int num = sequence.getSequence();
        sequence.setSequence(num + sequence.getSpan());
        dao.save(sequence);
        StringBuilder sb = new StringBuilder(num);
        sb.append(num);
        while (sb.length() < sequence.getDigit()) {
            sb.insert(0, "0");
        }

        if (sequence.getPrefix() != null) {
            sb.insert(0, sequence.getPrefix());
        }
        if (sequence.getSuffix() != null) {
            sb.append(sequence.getSuffix());
        }
        return sb.toString();
    }
}
