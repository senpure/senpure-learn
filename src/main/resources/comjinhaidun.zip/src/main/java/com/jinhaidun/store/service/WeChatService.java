package com.jinhaidun.store.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.senpure.base.service.BaseService;
import com.senpure.base.util.HttpsConnect;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by 罗中正 on 2017/5/2.
 */
@Service
public class WeChatService extends BaseService {

    protected String weChatAppId = "wxe61c486ef1bca73f";
    protected String weChatAppSecret = "3e97fb435a2db283fdb620175cbb8734";
    public  Map<String, Object> getWechatAccessToken(String code, Map<String, Object> context) {

        StringBuilder sb = new StringBuilder();
        sb.append("https://api.weixin.qq.com/sns/oauth2/access_token?");
        sb.append("appid=").append(weChatAppId).append("&");
        sb.append("secret=").append(weChatAppSecret).append("&");
        sb.append("code=").append(code).append("&");
        sb.append("grant_type=authorization_code");

        try {
            logger.debug("微信获取accesstoken 请求 {}", sb.toString());
            String reslut = HttpsConnect.sendGetRequest(sb.toString());
            logger.debug("微信获取accesstoken 返回:{}", reslut);
            JSONObject json = JSON.parseObject(reslut);
            String thirdId = json.getString("openid");
            context.put("thirdId", thirdId);
            if (thirdId != null) {
                String accessToken = json.getString("access_token");
                sb = new StringBuilder();
                sb.append("https://api.weixin.qq.com/sns/userinfo?");
                sb.append("access_token").append("=").append(accessToken).append("&");
                sb.append("openId").append("=").append(thirdId);
                reslut = HttpsConnect.sendGetRequest(sb.toString());
                logger.debug("微信获取userinfo 返回:{}", reslut);
                json = JSON.parseObject(reslut);
                if (json.getString("openid") != null) {
                    String head = json.getString("headimgurl");
                    String name = json.getString("nickname");
                    context.put("head", head);
                    context.put("nick", name);
                    return context;
                }


            }
            return null;
//
//            if(thirdId!=null)
//            {
//                String accessToken=json.getString("access_token");
//                String refreshToken=json.getString("refresh_token");
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
