package com.jinhaidun.store.struct;

/**
 * Created by 罗中正 on 2017/4/26.
 */
public class LoginContext {
    private String ip;
    private long ipNum;
    private String ipStr;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public long getIpNum() {
        return ipNum;
    }

    public void setIpNum(long ipNum) {
        this.ipNum = ipNum;
    }

    public String getIpStr() {
        return ipStr;
    }

    public void setIpStr(String ipStr) {
        this.ipStr = ipStr;
    }
}
