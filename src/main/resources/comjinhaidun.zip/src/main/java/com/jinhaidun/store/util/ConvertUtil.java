package com.jinhaidun.store.util;

import com.jinhaidun.store.entity.Player;
import com.jinhaidun.store.entity.PlayerAccount;
import com.jinhaidun.store.entity.RoundResult;
import com.jinhaidun.store.entity.Video;
import com.jinhaidun.store.vo.PlayerAccountVo;
import com.jinhaidun.store.vo.PlayerVo;
import com.jinhaidun.store.vo.RoundResultVo;
import com.jinhaidun.store.vo.VideoVo;

/**
 * Created by 罗中正 on 2017/4/25.
 */
public class ConvertUtil {

     public static PlayerVo convert(Player entity) {
        PlayerVo vo= new PlayerVo();
        return convert(entity,vo);
    }

    public static PlayerVo convert(Player entity,PlayerVo vo) {
        vo.setId(entity.getId());
        vo.setVersion(entity.getVersion());
        vo.setDiamond(entity.getDiamond());
        vo.setNick(entity.getNick());
        vo.setHead(entity.getHead());
        vo.setLocation(entity.getLocation());
        vo.setRoomId(entity.getRoomId());
        vo.setOnline(entity.getOnline());
        vo.setLoginType(entity.getLoginType());
        vo.setLogoutType(entity.getLogoutType());
        vo.setLoginTime(entity.getLoginTime());
        vo.setLoginDate(entity.getLoginDate());
        vo.setLogoutTime(entity.getLogoutTime());
        vo.setLogoutDate(entity.getLogoutDate());
        vo.setLoginIP(entity.getLoginIP());
        vo.setLastLoginIP(entity.getLastLoginIP());
        vo.setLoginSession(entity.getLoginSession());
        vo.setLoginSessionTime(entity.getLoginSessionTime());
        vo.setLoginSessionDate(entity.getLoginSessionDate());
        vo.setVersion(entity.getVersion());
        return vo;
    }

    public static Player convert(PlayerVo vo) {
        Player entity= new Player();
        return convert(vo,entity);
    }

    public static Player convert(PlayerVo vo,Player entity) {
        if(vo.getId()!=null){
            entity.setId(vo.getId());
        }
        if(vo.getVersion()!=null){
            entity.setVersion(vo.getVersion());
        }
        if(vo.getDiamond()!=null){
            entity.setDiamond(vo.getDiamond());
        }
        if(vo.getNick()!=null){
            entity.setNick(vo.getNick());
        }
        if(vo.getHead()!=null){
            entity.setHead(vo.getHead());
        }
        if(vo.getLocation()!=null){
            entity.setLocation(vo.getLocation());
        }
        if(vo.getRoomId()!=null){
            entity.setRoomId(vo.getRoomId());
        }
        if(vo.isOnline()!=null){
            entity.setOnline(vo.isOnline());
        }
        if(vo.getLoginType()!=null){
            entity.setLoginType(vo.getLoginType());
        }
        if(vo.getLogoutType()!=null){
            entity.setLogoutType(vo.getLogoutType());
        }
        if(vo.getLoginTime()!=null){
            entity.setLoginTime(vo.getLoginTime());
        }
        if(vo.getLoginDate()!=null){
            entity.setLoginDate(vo.getLoginDate());
        }
        if(vo.getLogoutTime()!=null){
            entity.setLogoutTime(vo.getLogoutTime());
        }
        if(vo.getLogoutDate()!=null){
            entity.setLogoutDate(vo.getLogoutDate());
        }
        if(vo.getLoginIP()!=null){
            entity.setLoginIP(vo.getLoginIP());
        }
        if(vo.getLastLoginIP()!=null){
            entity.setLastLoginIP(vo.getLastLoginIP());
        }
        if(vo.getLoginSession()!=null){
            entity.setLoginSession(vo.getLoginSession());
        }
        if(vo.getLoginSessionTime()!=null){
            entity.setLoginSessionTime(vo.getLoginSessionTime());
        }
        if(vo.getLoginSessionDate()!=null){
            entity.setLoginSessionDate(vo.getLoginSessionDate());
        }
        if(vo.getVersion()!=null){
            entity.setVersion(vo.getVersion());
        }
        return entity;
    }




    public static PlayerAccountVo convert(PlayerAccount entity) {
        PlayerAccountVo vo = new PlayerAccountVo();
        return convert(entity, vo);
    }

    public static PlayerAccountVo convert(PlayerAccount entity, PlayerAccountVo vo) {
        vo.setId(entity.getId());
        vo.setVersion(entity.getVersion());
        Player player = entity.getPlayer();
        if (player != null) {
            vo.setPlayerId(player.getId());
        }
        vo.setType(entity.getType());
        vo.setAccount(entity.getAccount());
        vo.setBindTime(entity.getBindTime());
        vo.setBindDate(entity.getBindDate());
        vo.setVersion(entity.getVersion());
        return vo;
    }

    public static PlayerAccount convert(PlayerAccountVo vo) {
        PlayerAccount entity = new PlayerAccount();
        return convert(vo, entity);
    }

    public static PlayerAccount convert(PlayerAccountVo vo, PlayerAccount entity) {
        if (vo.getId() != null) {
            entity.setId(vo.getId());
        }
        if (vo.getVersion() != null) {
            entity.setVersion(vo.getVersion());
        }
        Player player = entity.getPlayer();
        if (player != null) {
            player.setId(vo.getPlayerId());
        }
        if (vo.getType() != null) {
            entity.setType(vo.getType());
        }
        if (vo.getAccount() != null) {
            entity.setAccount(vo.getAccount());
        }
        entity.setBindTime(vo.getBindTime());
        if (vo.getBindDate() != null) {
            entity.setBindDate(vo.getBindDate());
        }
        if (vo.getVersion() != null) {
            entity.setVersion(vo.getVersion());
        }
        return entity;
    }

    public static RoundResultVo convert(RoundResult entity) {
        RoundResultVo vo= new RoundResultVo();
        return convert(entity,vo);
    }

    public static RoundResultVo convert(RoundResult entity,RoundResultVo vo) {

        vo.setRecordId(entity.getRecordId());
        vo.setRoomId(entity.getRoomId());
        vo.setCreateTime(entity.getCreateTime());
        vo.setCreateDate(entity.getCreateDate());
        vo.setFinallyScore(entity.getFinallyScore());
        vo.setDeatilScore(entity.getDeatilScore());

        return vo;
    }

    public static RoundResult convert(RoundResultVo vo) {
        RoundResult entity= new RoundResult();
        return convert(vo,entity);
    }

    public static RoundResult convert(RoundResultVo vo,RoundResult entity) {

        entity.setRecordId(vo.getRecordId());
        entity.setRoomId(vo.getRoomId());
        entity.setCreateTime(vo.getCreateTime());
        if(vo.getCreateDate()!=null){
            entity.setCreateDate(vo.getCreateDate());
        }
        if(vo.getFinallyScore()!=null){
            entity.setFinallyScore(vo.getFinallyScore());
        }
        if(vo.getDeatilScore()!=null){
            entity.setDeatilScore(vo.getDeatilScore());
        }

        return entity;
    }

    public static VideoVo convert(Video entity) {
        VideoVo vo= new VideoVo();
        return convert(entity,vo);
    }

    public static VideoVo convert(Video entity,VideoVo vo) {
        vo.setId(entity.getId());
        vo.setVersion(entity.getVersion());
        vo.setRecordId(entity.getRecordId());
        vo.setIndex(entity.getRoundIndex());
        vo.setData(entity.getData());
        vo.setVersion(entity.getVersion());
        return vo;
    }

    public static Video convert(VideoVo vo) {
        Video entity= new Video();
        return convert(vo,entity);
    }

    public static Video convert(VideoVo vo,Video entity) {
        if(vo.getId()!=null){
            entity.setId(vo.getId());
        }
        if(vo.getVersion()!=null){
            entity.setVersion(vo.getVersion());
        }
        entity.setRecordId(vo.getRecordId());
        entity.setRoundIndex(vo.getIndex());
        if(vo.getData()!=null){
            entity.setData(vo.getData());
        }
        if(vo.getVersion()!=null){
            entity.setVersion(vo.getVersion());
        }
        return entity;
    }


}
