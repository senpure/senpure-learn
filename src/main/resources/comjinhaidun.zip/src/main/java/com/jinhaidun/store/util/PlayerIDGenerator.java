package com.jinhaidun.store.util;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public class PlayerIDGenerator {

    private static AtomicInteger currentID= new AtomicInteger(600000);
    public static void setCurrentID(AtomicInteger currentID) {
        PlayerIDGenerator.currentID = currentID;
    }
    public  static int nextPlayerId()
    {
     return  currentID.getAndIncrement();
    }
    public static void main(String[] args) {
        AtomicInteger current=   new AtomicInteger(15);

        PlayerIDGenerator.setCurrentID(current);
        System.out.println(PlayerIDGenerator.nextPlayerId());
        System.out.println(PlayerIDGenerator.nextPlayerId());
        System.out.println(PlayerIDGenerator.nextPlayerId());

    }
}
