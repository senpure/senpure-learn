package com.jinhaidun.store.vo;

import java.io.Serializable;
import java.util.Date;

public class PlayerAccountVo implements Serializable {
	private static final long serialVersionUID = 1493702977912L;


	private	Integer id;
	private	Integer playerId;
	private	String type;
	private	String account;
	private	long bindTime;
	private	Date bindDate;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public Integer getPlayerId() {
		return playerId;
	}


	public	void setPlayerId(Integer playerId) {
		this.playerId=playerId ;
	}

	public String getType() {
		return type;
	}


	public	void setType(String type) {
		this.type=type ;
	}

	public String getAccount() {
		return account;
	}


	public	void setAccount(String account) {
		this.account=account ;
	}

	public long getBindTime() {
		return bindTime;
	}


	public	void setBindTime(long bindTime) {
		this.bindTime=bindTime ;
	}

	public Date getBindDate() {
		return bindDate;
	}


	public	void setBindDate(Date bindDate) {
		this.bindDate=bindDate ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}