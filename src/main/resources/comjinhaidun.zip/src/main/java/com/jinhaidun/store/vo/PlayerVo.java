package com.jinhaidun.store.vo;

import java.io.Serializable;
import java.util.Date;

public class PlayerVo implements Serializable {
	private static final long serialVersionUID = 1493702977906L;


	private	Integer id;
	private	Integer diamond;
	private	String nick;
	private	String head;
	private	String location;
	private	Integer roomId;
	private	Boolean online;
	private	String loginType;
	private	String logoutType;
	private	Long loginTime;
	private	Date loginDate;
	private	Long logoutTime;
	private	Date logoutDate;
	private	String loginIP;
	private	String lastLoginIP;
	private	String loginSession;
	private	Long loginSessionTime;
	private	Date loginSessionDate;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public Integer getDiamond() {
		return diamond;
	}


	public	void setDiamond(Integer diamond) {
		this.diamond=diamond ;
	}

	public String getNick() {
		return nick;
	}


	public	void setNick(String nick) {
		this.nick=nick ;
	}

	public String getHead() {
		return head;
	}


	public	void setHead(String head) {
		this.head=head ;
	}

	public String getLocation() {
		return location;
	}


	public	void setLocation(String location) {
		this.location=location ;
	}

	public Integer getRoomId() {
		return roomId;
	}


	public	void setRoomId(Integer roomId) {
		this.roomId=roomId ;
	}

	public Boolean isOnline() {
		return online;
	}


	public	void setOnline(Boolean online) {
		this.online=online ;
	}

	public String getLoginType() {
		return loginType;
	}


	public	void setLoginType(String loginType) {
		this.loginType=loginType ;
	}

	public String getLogoutType() {
		return logoutType;
	}


	public	void setLogoutType(String logoutType) {
		this.logoutType=logoutType ;
	}

	public Long getLoginTime() {
		return loginTime;
	}


	public	void setLoginTime(Long loginTime) {
		this.loginTime=loginTime ;
	}

	public Date getLoginDate() {
		return loginDate;
	}


	public	void setLoginDate(Date loginDate) {
		this.loginDate=loginDate ;
	}

	public Long getLogoutTime() {
		return logoutTime;
	}


	public	void setLogoutTime(Long logoutTime) {
		this.logoutTime=logoutTime ;
	}

	public Date getLogoutDate() {
		return logoutDate;
	}


	public	void setLogoutDate(Date logoutDate) {
		this.logoutDate=logoutDate ;
	}

	public String getLoginIP() {
		return loginIP;
	}


	public	void setLoginIP(String loginIP) {
		this.loginIP=loginIP ;
	}

	public String getLastLoginIP() {
		return lastLoginIP;
	}


	public	void setLastLoginIP(String lastLoginIP) {
		this.lastLoginIP=lastLoginIP ;
	}

	public String getLoginSession() {
		return loginSession;
	}


	public	void setLoginSession(String loginSession) {
		this.loginSession=loginSession ;
	}

	public Long getLoginSessionTime() {
		return loginSessionTime;
	}


	public	void setLoginSessionTime(Long loginSessionTime) {
		this.loginSessionTime=loginSessionTime ;
	}

	public Date getLoginSessionDate() {
		return loginSessionDate;
	}


	public	void setLoginSessionDate(Date loginSessionDate) {
		this.loginSessionDate=loginSessionDate ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}