package com.jinhaidun.store.vo;

import java.io.Serializable;
import java.util.Date;
public class RoundResultVo implements Serializable {
	private static final long serialVersionUID = 1496225107244L;


	private	Integer id;
	private	long recordId;
	private	int roomId;
	private	long createTime;
	private	Date createDate;
	private	String finallyScore;
	private	String deatilScore;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public long getRecordId() {
		return recordId;
	}


	public	void setRecordId(long recordId) {
		this.recordId=recordId ;
	}

	public int getRoomId() {
		return roomId;
	}


	public	void setRoomId(int roomId) {
		this.roomId=roomId ;
	}

	public long getCreateTime() {
		return createTime;
	}


	public	void setCreateTime(long createTime) {
		this.createTime=createTime ;
	}

	public Date getCreateDate() {
		return createDate;
	}


	public	void setCreateDate(Date createDate) {
		this.createDate=createDate ;
	}

	public String getFinallyScore() {
		return finallyScore;
	}


	public	void setFinallyScore(String finallyScore) {
		this.finallyScore=finallyScore ;
	}

	public String getDeatilScore() {
		return deatilScore;
	}


	public	void setDeatilScore(String deatilScore) {
		this.deatilScore=deatilScore ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

	@Override
	public String toString() {
		return "RoundResultVo{" +
				"id=" + id +
				", recordId=" + recordId +
				", roomId=" + roomId +
				", createTime=" + createTime +
				", createDate=" + createDate +
				", finallyScore='" + finallyScore + '\'' +
				", deatilScore='" + deatilScore + '\'' +
				", version=" + version +
				'}';
	}
}