package com.jinhaidun.store.vo;

import java.io.Serializable;
import java.util.Date;
public class UserVo implements Serializable {
	private static final long serialVersionUID = 1493099848560L;


	private	Integer id;
	private	String user_id;
	private	String user_code;
	private	String password;
	private	String user_name;
	private	String parent_code;
	private	String role_code;
	private	String permission_code;
	private	Integer masonry_num;
	private	Date create_date;
	private	Date login_time;
	private	Date logout_time;
	private	String logout_type;
	private	String update_code;
	private	Date update_time;
	private	String isValid;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public String getUser_id() {
		return user_id;
	}


	public	void setUser_id(String user_id) {
		this.user_id=user_id ;
	}

	public String getUser_code() {
		return user_code;
	}


	public	void setUser_code(String user_code) {
		this.user_code=user_code ;
	}

	public String getPassword() {
		return password;
	}


	public	void setPassword(String password) {
		this.password=password ;
	}

	public String getUser_name() {
		return user_name;
	}


	public	void setUser_name(String user_name) {
		this.user_name=user_name ;
	}

	public String getParent_code() {
		return parent_code;
	}


	public	void setParent_code(String parent_code) {
		this.parent_code=parent_code ;
	}

	public String getRole_code() {
		return role_code;
	}


	public	void setRole_code(String role_code) {
		this.role_code=role_code ;
	}

	public String getPermission_code() {
		return permission_code;
	}


	public	void setPermission_code(String permission_code) {
		this.permission_code=permission_code ;
	}

	public Integer getMasonry_num() {
		return masonry_num;
	}


	public	void setMasonry_num(Integer masonry_num) {
		this.masonry_num=masonry_num ;
	}

	public Date getCreate_date() {
		return create_date;
	}


	public	void setCreate_date(Date create_date) {
		this.create_date=create_date ;
	}

	public Date getLogin_time() {
		return login_time;
	}


	public	void setLogin_time(Date login_time) {
		this.login_time=login_time ;
	}

	public Date getLogout_time() {
		return logout_time;
	}


	public	void setLogout_time(Date logout_time) {
		this.logout_time=logout_time ;
	}

	public String getLogout_type() {
		return logout_type;
	}


	public	void setLogout_type(String logout_type) {
		this.logout_type=logout_type ;
	}

	public String getUpdate_code() {
		return update_code;
	}


	public	void setUpdate_code(String update_code) {
		this.update_code=update_code ;
	}

	public Date getUpdate_time() {
		return update_time;
	}


	public	void setUpdate_time(Date update_time) {
		this.update_time=update_time ;
	}

	public String getIsValid() {
		return isValid;
	}


	public	void setIsValid(String isValid) {
		this.isValid=isValid ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}