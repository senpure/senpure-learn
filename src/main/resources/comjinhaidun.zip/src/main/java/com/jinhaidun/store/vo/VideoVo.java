package com.jinhaidun.store.vo;

import java.io.Serializable;
import java.util.Date;
public class VideoVo implements Serializable {
	private static final long serialVersionUID = 1496715028504L;


	private	Integer id;
	private	long recordId;
	private	int index;
	private	String data;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public long getRecordId() {
		return recordId;
	}


	public	void setRecordId(long recordId) {
		this.recordId=recordId ;
	}

	public int getIndex() {
		return index;
	}


	public	void setIndex(int index) {
		this.index=index ;
	}

	public String getData() {
		return data;
	}


	public	void setData(String data) {
		this.data=data ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}