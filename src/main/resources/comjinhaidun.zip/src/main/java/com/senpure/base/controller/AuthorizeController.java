package com.senpure.base.controller;

import com.senpure.base.service.AuthorizeService;
import com.senpure.base.spring.BaseController;
import com.senpure.base.util.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by Administrator on 2017/3/1.
 */
@Controller
@RequestMapping("/authorize")
public class AuthorizeController extends BaseController {
    @Autowired
private AuthorizeService authorizeService;

    @RequestMapping(value = "/notallow")
    public void notPermission() {

        Assert.error("权限不足。");
    }





}
