package com.senpure.base.controller;

import com.senpure.base.result.ResultMap;
import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by 罗中正 on 2017/5/4.
 */
@Controller
@RequestMapping("/authorize")
public class CreateAccountController extends BaseController {

   // @RequestMapping({"/account/{container}","/account2/{container}"})
    //@PermissionVerify(login = false)
    public ResultMap createAccount(@PathVariable int container )
    {
       logger.debug("创建账号"+container);
        return null;
    }
    //@RequestMapping({"/account/*"})
    //@PermissionVerify(login = false)
    public ResultMap createAccount2(@PathVariable int container )
    {
       logger.debug("创建账号2"+container);
        return null;
    }
}
