package com.senpure.base.criterion;

import org.hibernate.validator.constraints.Length;

/**
 * Created by 罗中正 on 2017/5/19.
 */
public class AccountCreateCriteria {

    @Length(min = 2, max = 8, message = "{length.error}")
    private String name;
    @Length(min = 5, max = 24, message = "{base.length.error}")
    private String account;
    @Length(min = 5, max = 24, message = "{password.length.error}")
    private String password;

   private int  containerId;
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getContainerId() {
        return containerId;
    }

    public void setContainerId(int containerId) {
        this.containerId = containerId;
    }
}
