package com.senpure.base.criterion;

/**
 * Created by 罗中正 on 2017/5/19.
 */
public class RolePermissionCriteria  extends  Criteria{

    private int roleId;
    private String name;

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
