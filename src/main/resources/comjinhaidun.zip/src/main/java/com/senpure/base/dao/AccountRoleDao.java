package com.senpure.base.dao;

import com.senpure.base.entity.AccountRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/2/7.
 */
@Repository
public interface AccountRoleDao extends JpaRepository<AccountRole, Integer> {


    public AccountRole findByAccountIdAndRoleId(int accountId, int roleId);


}
