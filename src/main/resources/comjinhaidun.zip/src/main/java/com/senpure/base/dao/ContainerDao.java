package com.senpure.base.dao;

import com.senpure.base.entity.Container;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/2/7.
 */
@Repository
public interface ContainerDao extends JpaRepository<Container,Integer> ,JpaSpecificationExecutor<Container> {
    Container findByName(String name);
    List<Container> findByParent(Container parent);
}
