package com.senpure.base.dao;

import com.senpure.base.entity.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/6/15.
 */
@Repository
public interface MenuDao extends JpaRepository<Menu,Integer> {
}
