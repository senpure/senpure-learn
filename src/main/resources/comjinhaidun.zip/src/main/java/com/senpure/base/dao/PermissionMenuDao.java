package com.senpure.base.dao;

import com.senpure.base.entity.PermissionMenu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/6/16.
 */
@Repository
public interface PermissionMenuDao extends JpaRepository<PermissionMenu,Integer> {
    PermissionMenu findByPermissionName(String permssionName);
}
