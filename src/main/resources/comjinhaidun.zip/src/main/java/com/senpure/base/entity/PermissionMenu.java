package com.senpure.base.entity;

import com.senpure.AppConstant;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by 罗中正 on 2017/6/16.
 */
@Entity
@Table(name = AppConstant.DB_BASE_PREFIX + "_PERMISSION_MENU")
public class PermissionMenu extends IntEntity {
    private static final long serialVersionUID = -6746933581483135892L;
    private int menuId;
    private String permissionName;

    private Boolean dataBaseUpdate=false;

    public int getMenuId() {
        return menuId;
    }

    public void setMenuId(int menuId) {
        this.menuId = menuId;
    }


    public Boolean getDataBaseUpdate() {
        return dataBaseUpdate;
    }

    public void setDataBaseUpdate(Boolean dataBaseUpdate) {
        this.dataBaseUpdate = dataBaseUpdate;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }
}
