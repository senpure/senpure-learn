package com.senpure.base.init;

import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.entity.Menu;
import com.senpure.base.spring.SpringContextRefreshEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/6/15.
 */
@Component
@Order(0)
public class MenuParentGenerator  extends SpringContextRefreshEvent {

    Logger logger = LoggerFactory.getLogger(MenuGenerator.class);


    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {

        logger.debug("MenuParentGenerator11111111111111111111111111111111111111111");
        logger.debug("MenuParentGenerator11111111111111111111111111111111111111111");
        logger.debug("MenuParentGenerator11111111111111111111111111111111111111111");
        logger.debug("MenuParentGenerator11111111111111111111111111111111111111111");


    }

    public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) throws BeansException {
        logger.debug("MenuParentGenerator222222222222222222222222222222222222222222222");
        logger.debug("MenuParentGenerator222222222222222222222222222222222222222222222");
        logger.debug("MenuParentGenerator222222222222222222222222222222222222222222222");
        logger.debug("MenuParentGenerator222222222222222222222222222222222222222222222");
        Map<String, Object> map = factory.getBeansWithAnnotation(MenuGenerator.class);
        Iterator<Map.Entry<String, Object>> entry = map.entrySet().iterator();

        while (entry.hasNext()) {

            Object o = entry.next().getValue();
            MenuGenerator menuGenerator = o.getClass().getAnnotation(MenuGenerator.class);
            Menu menu = new Menu();
            menu.setText(menuGenerator.text());
            if (menuGenerator.description().length() > 0) {
                menu.setDescription(menuGenerator.description());
            }
            if (menuGenerator.config().length() > 0) {
                menu.setConfig(menuGenerator.config());
            }
            menu.setIcon(menuGenerator.icon());
            menu.setId(menuGenerator.id());
            PermissionsGenerator.checkAndPutMenu(menu);
        }

    }



    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        ApplicationContext context=event.getApplicationContext();
        String beans[]= context .getBeanNamesForType(Object.class);
        for (String bean:beans)
        {

            Object o=   context.getBean(bean);
            MenuGenerator menuGenerator = o.getClass().getAnnotation(MenuGenerator.class);
            if(menuGenerator!=null)
            {Menu menu = new Menu();
                menu.setText(menuGenerator.text());
                if (menuGenerator.description().length() > 0) {
                    menu.setDescription(menuGenerator.description());
                }
                if (menuGenerator.config().length() > 0) {
                    menu.setConfig(menuGenerator.config());
                }
                menu.setIcon(menuGenerator.icon());
                menu.setId(menuGenerator.id());
                PermissionsGenerator.checkAndPutMenu(menu);}

        }
    }
}
