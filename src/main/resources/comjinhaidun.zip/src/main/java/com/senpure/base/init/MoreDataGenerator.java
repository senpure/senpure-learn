package com.senpure.base.init;

import com.senpure.AppConstant;
import com.senpure.base.dao.AccountDao;
import com.senpure.base.dao.ContainerDao;
import com.senpure.base.dao.SystemValueDao;
import com.senpure.base.entity.Account;
import com.senpure.base.entity.Container;
import com.senpure.base.entity.SystemValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by 罗中正 on 2017/5/22.
 */
@Component
@Order(value = 2)
public class MoreDataGenerator implements ApplicationListener<ContextRefreshedEvent> {



    @Autowired
    AccountDao accountDao;
    @Autowired
    SystemValueDao systemValueDao;
    @Autowired
    ContainerDao containerDao;

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        SystemValue systemValue = systemValueDao.findByKey("create.base.test");
        if (systemValue != null) {
            return;
        }
        systemValue = systemValueDao.findByKey("top.container.id");
        Container p = containerDao.getOne(Integer.valueOf(systemValue.getValue()));
        Container container = new Container();

        container.setLevel(AppConstant.CONTAINER_LEVEL_TOP);
        container.setName("我的团队");
        container.setContainerStructure(p.getContainerStructure() + AppConstant.CONTAINER_SEPARTOR + p.getId() + AppConstant.CONTAINER_SEPARTOR);
        container.setDescription("用了容纳我的下级成员的一个团队");
        container.setParent(p);
        container.setRelation(p.getRelation());
        containerDao.save(container);

        List<Account> accounts = new ArrayList<>();
        for (int i = 10; i < 80; i++) {
            Account account = new Account();
            account.setAccount("accountTest" + i);
            account.setPassword("accountTest");
            Date now = new Date();
            account.setVersion(0);
            account.setCreateDate(now);
            account.setCreateTime(now.getTime());
            account.setAccountState(AppConstant.ACCOUNT_STATE_NORMAL);
            account.setName("accountTest_name" + i);
            account.setContainer(container);
            accounts.add(account);
        }
        accountDao.save(accounts);
        systemValue = new SystemValue();
        systemValue.setKey("create.base.test");
        systemValue.setValue("true");
        systemValueDao.save(systemValue);

    }
}
