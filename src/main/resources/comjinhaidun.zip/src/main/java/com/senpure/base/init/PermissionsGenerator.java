package com.senpure.base.init;

import com.senpure.AppConstant;
import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.annotation.ResourceVerify;
import com.senpure.base.entity.Menu;
import com.senpure.base.entity.Permission;
import com.senpure.base.entity.PermissionMenu;
import com.senpure.base.entity.URIPermission;
import com.senpure.base.service.PermissionService;
import com.senpure.base.spring.SpringContextRefreshEvent;
import com.senpure.base.spring.VerifyInterceptor;
import com.senpure.base.util.Assert;
import com.senpure.base.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Repository;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.util.*;

@Repository
@Order(value = 1)
public class PermissionsGenerator extends SpringContextRefreshEvent {

    @Autowired
    private PermissionService permissionService;
      @Autowired
     private VerifyInterceptor verifyInterceptor;
    private Map<String, List<Permission>> uriPermissionS = new HashMap<>();
    private static Map<Integer, Menu> menuMap = new HashMap<>();

    public static void checkAndPutMenu(Menu menu) {
        if (menuMap.containsKey(menu.getId())) {
            Assert.error(" 菜单ID重复:" + menu.getId());
        }
        menuMap.put(menu.getId(), menu);
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        logger.debug("准备检查代码中的权限，生成数据");
        RequestMappingHandlerMapping rm = event.getApplicationContext().getBean(RequestMappingHandlerMapping.class);
         verifyInterceptor.setHandlerMapping(rm);
        Map<RequestMappingInfo, HandlerMethod> map = rm.getHandlerMethods();
        Iterator<Map.Entry<RequestMappingInfo, HandlerMethod>> iterator = map.entrySet().iterator();
        List<Permission> createPermissions = new ArrayList<>();
        Map<String, Permission> permissionMap = new HashMap<>();
        List<PermissionMenu> permissionMenus = new ArrayList<>();

        while (iterator.hasNext()) {
            Map.Entry<RequestMappingInfo, HandlerMethod> entry = iterator.next();
            RequestMappingInfo info = entry.getKey();
            HandlerMethod handlerMethod = entry.getValue();
            PermissionVerify permissionVerify = handlerMethod.getMethod().getAnnotation(PermissionVerify.class);
            String pname = null;
            if (permissionVerify != null) {

                String suffix = mapping2Suffix(info,handlerMethod);
                StringBuilder sname = new StringBuilder();
                Iterator<String> it = info.getPatternsCondition().getPatterns().iterator();
                List<String> uriAndMethod = new ArrayList<>();
                while (true) {
                    String uri = it.next();
                    uriAndMethod.add(uri + "->" + handlerMethod.getMethod().getName());
                    sname.append(uri);
                    if (it.hasNext()) {
                        sname.append("||");
                    } else {
                        break;
                    }
                }
                String uris = sname.toString();
                sname.append("_").append(suffix);
                // logger.debug(sname);
                Permission permission = new Permission();
                if (StringUtil.isExist(permissionVerify.value())) {
                    permission.setReadableName(permissionVerify.value());
                } else {
                    permission.setReadableName(sname.toString());
                }
                String name = permissionVerify.name();
                if (StringUtil.isExist(name)) {
                    permission.setName(name);
                } else {
                    permission.setName(sname.toString());
                }
                pname = permission.getName();
                permission.setDescription(sname.toString() + "->" + handlerMethod.getMethod().getName());
                permission.setType(AppConstant.PERMISSION_TYPE_NORMAL);
                List<URIPermission> uriPermissions = new ArrayList<>();
                for (String um : uriAndMethod) {
                    URIPermission uriPermission = new URIPermission();
                    uriPermission.setUriAndMethod(um);
                    uriPermission.setPermission(permission);
                    uriPermissions.add(uriPermission);
                }
                permission.setUris(uriPermissions);
                permission = checkPermission(permissionMap, permission, uris);

                ResourceVerify[] resourceVerifies = handlerMethod.getMethod().getAnnotationsByType(ResourceVerify.class);
                if (resourceVerifies != null && resourceVerifies.length > 0) {
                    Permission resourcePermission = new Permission();
                    resourcePermission.setName(permission.getName() + "_owner");
                        String ownerPname = resourceVerifies[0].permissionName();
                        if (ownerPname.length() > 0) {
                            resourcePermission.setReadableName(ownerPname);
                        } else {
                            StringBuilder sb = new StringBuilder();
                            sb.append(permission.getReadableName())
                                    .insert(2, "我的");
                            resourcePermission.setReadableName(sb.toString());
                        }
                    resourcePermission.setType(AppConstant.PERMISSION_TYPE_OWNER);
                    resourcePermission.setDescription(sname.toString() + "_owner" + "->" + handlerMethod.getMethod().getName());
                    List<URIPermission> uriPermissions2 = new ArrayList<>();
                    for (String um : uriAndMethod) {
                        URIPermission uriPermission = new URIPermission();
                        uriPermission.setPermission(resourcePermission);
                        uriPermission.setUriAndMethod(um);
                        uriPermissions2.add(uriPermission);
                    }
                    resourcePermission.setUris(uriPermissions2);
                    checkPermission(permissionMap, resourcePermission, uris);
                }


            }
            //
            //生成菜单
            MenuGenerator menuGenerator = handlerMethod.getMethod().getAnnotation(MenuGenerator.class);
            if (menuGenerator != null) {
                Menu menu = new Menu();
                setBaseProp(menuGenerator, menu);
                if (menuMap.get(menu.getId()) != null) {
                    Assert.error("菜单ID重复" + menu.getId() + "," + handlerMethod.getBeanType());
                } else {
                    menuMap.put(menu.getId(), menu);
                }
                if (pname != null) {
                    PermissionMenu permissionMenu = new PermissionMenu();
                    permissionMenu.setMenuId(menu.getId());
                    permissionMenu.setPermissionName(pname);
                    permissionMenus.add(permissionMenu);
                }

                if (menuGenerator.uri().length() > 0) {
                    menu.setUri(menuGenerator.uri());
                } else {
                    //取第一个
                    menu.setUri(info.getPatternsCondition().getPatterns().iterator().next());
                }

                if (menuGenerator.parentId() == 0) {
                    MenuGenerator parent = handlerMethod.getBeanType().getAnnotation(MenuGenerator.class);
                    if (parent != null) {
                        menu.setParentId(parent.id());
                        Menu parentMenu=new Menu();
                        setBaseProp(parent, parentMenu);
                        if (menuMap.get(parentMenu.getId()) == null) {
                          //  menuMap.put(parentMenu.getId(), parentMenu);
                        }
                    } else {
                        menu.setParentId(0);
                    }
                } else {
                    menu.setParentId(menuGenerator.parentId());
                }
            }
        }
        createPermissions.addAll(permissionMap.values());
        if (!createPermissions.isEmpty()) {
            permissionService.syncPermissions(createPermissions);
        }

        if (menuMap.size() > 0) {
            List<Menu> menus = new ArrayList<>();
            menus.addAll(menuMap.values());

            permissionService.syncMenu(menus);
            permissionService.syncPermissionMenu(permissionMenus);
        }
        logger.info("SpringContextRefreshedEvent ----------------------------------------------------------------------");

    }

    private Permission checkPermission(Map<String, Permission> permissionMap, Permission permission, String uris) {

        Permission mPermission = permissionMap.get(permission.getName());
        if (mPermission != null) {
            permission.getUris().forEach(uriPermission ->
                    uriPermission.setPermission(mPermission));
            mPermission.getUris().addAll(permission.getUris());
            mPermission.setDescription(uris + "||" + mPermission.getDescription());
            return mPermission;
        } else {
            permissionMap.put(permission.getName(), permission);
            return permission;
        }
    }

    public static  StringBuilder mapping2permissionName(RequestMappingInfo info , HandlerMethod handlerMethod)
    { Iterator<String> it = info.getPatternsCondition().getPatterns().iterator();
        StringBuilder sname = new StringBuilder();

        List<String> uriAndMethod = new ArrayList<>();
        while (true) {
            String uri = it.next();
            sname.append(uri);
            uriAndMethod.add(uri + "->" + handlerMethod.getMethod().getName());
            if (it.hasNext()) {
                sname.append("||");
            } else {
                break;
            }
        }
        return sname;
    }
    private static String mapping2Suffix(RequestMappingInfo info , HandlerMethod handlerMethod)
    {

        String suffix = "read";
        if (info.getMethodsCondition().isEmpty()) {
            suffix = method2Suffix(handlerMethod, false);
        } else {
            List<String> methods = new ArrayList<>();
            info.getMethodsCondition().getMethods().forEach(requestMethod ->
                    methods.add(requestMethod.toString().toUpperCase()));
            if (methods.contains("DELETE")) {
                suffix = "delete";
            } else if (
                    methods.contains("PUT")) {
                suffix = "create";
            } else if (
                    methods.contains("POST")) {
                suffix = method2Suffix(handlerMethod, true);
            }
        }
        return  suffix;
    }
   public static String method2Suffix(HandlerMethod handlerMethod, boolean post) {
        String suffix = "create";
        if (handlerMethod.getMethod().getName().startsWith("add") || handlerMethod.getMethod().getName().startsWith("create")) {
            suffix = "create";
        } else if (handlerMethod.getMethod().getName().startsWith("del")) {
            suffix = "delete";
        } else if (handlerMethod.getMethod().getName().startsWith("update") || handlerMethod.getMethod().getName().startsWith("change")) {
            suffix = "update";
        } else {
            suffix = post ? "update" : "read";
        }
        return suffix;
    }


    private void setBaseProp(MenuGenerator menuGenerator, Menu menu) {
        menu.setText(menuGenerator.text());
        if (menuGenerator.description().length() > 0) {
            menu.setDescription(menuGenerator.description());
        }
        if (menuGenerator.config().length() > 0) {
            menu.setConfig(menuGenerator.config());
        }
        menu.setIcon(menuGenerator.icon());
        menu.setId(menuGenerator.id());

    }


    public static void main(String[] args) {
        String str = "创建容器";
        StringBuilder sb = new StringBuilder(str);
        sb.insert(2, "我的");
        System.out.println(sb);

    }
}
