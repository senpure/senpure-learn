package com.senpure.base.menu;

public class MenuBagde implements MenuListener {

	@Override
	public void execute(Menu menu) {
	switch (menu.getId()) {
	case 1:
		
		break;

	default:
		break;
	}

	}

}
