package com.senpure.base.result;

import com.senpure.base.annotation.Message;

import java.io.Serializable;


public abstract interface Result extends Serializable {

	@Message(message = "成功")
	public static final int NOTHING= -1;
	@Message(message = "失败")
	public static final int FAILURE = 0;
	@Message(message = "成功")
	public static final int SUCCESS = 1;

	@Message(message = "未知错误")
	public static final int ERROR_UNKNOWN = 10;
	@Message(message = "服务器发送错误")
	public static final int ERROR_SERVER= 11;
	@Message(message ="服务器繁忙，请稍后再试")
	public static final int ERROR_DIM= 12;

	@Message(message = "账号已经存在")
	public static final int ACCOUNT_ALREADY_EXISTS = 100;
	@Message(message = "账号不存在")
	public static final int ACCOUNT_NOT_EXIST = 101;
	@Message(message = "账号被禁用")
	public static final int ACCOUNT_BANED = 102;
	@Message(message = "密码不正确")
	public static final int PASSWORD_INCORRECT = 103;
	@Message(message = "数据格式不正确")
	public static final int FORMAT_INCORRECT = 104;
	@Message(message = "账号在其他地方登陆")
	public static final int ACCOUNT_OTHER_LOGIN = 105;
	@Message(message = "账号未登陆")
	public static final int ACCOUNT_NOT_LOGIN = 106;
	@Message(message = "账号未登陆或登陆超时 ")
	public static final int ACCOUNT_NOT_LOGIN_OR_SESSION_TIMEOUT = 107;


	@Message(message = "玩家不存在 ")
	public static final int PLAYER_ID_NOT_EXIST = 201;
	@Message(message = "钻石过多,不能超过{0} ")
	public static final int DAIMOND_TOO_MUCH = 202;
	@Message(message = "代理钻石不足 ")
	public static final int DAIMOND_PROXY_LACK= 203;

}
