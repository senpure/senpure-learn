package com.senpure.base.service;

import com.senpure.base.dao.AccountDao;
import com.senpure.base.dao.ContainerDao;
import com.senpure.base.entity.Account;
import com.senpure.base.util.ConvertUtil;
import com.senpure.base.vo.AccountVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by 罗中正 on 2017/5/3.
 */
@Service
public class AccountService extends BaseService {

    @Autowired
    private AccountDao accountDao;

    @Autowired
    private ContainerDao containerDao;

    public AccountVo loadAccount(String account) {
        Account a = accountDao.findByAccount(account);
       // containerDao.findAccountByAccount("admin");
        if(a==null)
        {
            return null;
        }
        return ConvertUtil.convert(a);
    }


    public void createAccount(AccountVo accountVo ,int containerId,int... role)
    {

        Account account=ConvertUtil.convert(accountVo);


    }
}
