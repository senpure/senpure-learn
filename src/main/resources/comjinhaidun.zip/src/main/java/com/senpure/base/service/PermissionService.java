package com.senpure.base.service;

import com.senpure.base.dao.MenuDao;
import com.senpure.base.dao.PermissionDao;
import com.senpure.base.dao.PermissionMenuDao;
import com.senpure.base.dao.URIPermissionDao;
import com.senpure.base.entity.Menu;
import com.senpure.base.entity.Permission;
import com.senpure.base.entity.PermissionMenu;
import com.senpure.base.entity.URIPermission;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/2/7.
 */
@Service
@Transactional
public class PermissionService extends BaseService {

    private List<Permission> permissions;
    @Autowired
    private PermissionDao dao;
    @Autowired
    private URIPermissionDao uriPermissionDao;
    @Autowired
    private MenuDao menuDao;
    @Autowired
    private PermissionMenuDao permissionMenuDao;

    public void loadAll() {
        permissions = dao.findAll();
    }

    public Permission loadPermission(String name) {

        return dao.findByName(name);

    }


    public void syncPermissions(List<Permission> permissions) {
        loadAll();
        List<Permission> newPermissions = new ArrayList<>();
        List<Permission> updatePermissions = new ArrayList<>();
        List<URIPermission> uriPermissions = new ArrayList<>();
        for (Permission p : permissions) {
            boolean notNew = false;
            for (Permission p2 : this.permissions) {
                if (p.getName().equals(p2.getName())) {
                    if (!p2.getDatabaseUpdate()) {
                        p2.setReadableName(p.getReadableName());
                        p2.setResourceVerifyName(p.getResourceVerifyName());
                        p2.setDescription(p.getDescription());
                        boolean updateUri = true;
                        for (URIPermission uriPermission : p.getUris()) {
                            updateUri = true;
                            for (URIPermission save : p2.getUris()) {
                                if (uriPermission.getUriAndMethod().equals(save.getUriAndMethod())) {
                                    updateUri = false;
                                    break;
                                }
                            }
                            if (updateUri) {
                                uriPermission.setPermission(p2);
                                uriPermissions.add(uriPermission);

                            }
                        }

                        updatePermissions.add(p2);
                    } else {
                        logger.info("{}在数据库中存在，并且产生了修改，以数据库中的数据为准不做修改", p.getName());
                    }

                    notNew = true;
                    break;
                }

            }
            if (!notNew) {
                logger.info("新增权限相关的检查{}", p);
                newPermissions.add(p);
            }

        }

        if (!newPermissions.isEmpty()) {
            dao.save(newPermissions);
        }
        if (updatePermissions.size() > 0) {
            dao.save(updatePermissions);
        }

        if (uriPermissions.size() > 0) {
            uriPermissionDao.save(uriPermissions);
        }
    }

    public void syncMenu(List<Menu> menus) {
        List<Menu> dbMenus = menuDao.findAll();
        List<Menu> newMenus = new ArrayList<>();
        List<Menu> updateMenus = new ArrayList<>();
        for (Menu menu : menus) {
            boolean notNew = false;
            for (Menu dm : dbMenus) {
                if (menu.getId() == dm.getId()) {
                    if (!dm.getDatabaseUpdate()) {
                        dm.setParentId(menu.getParentId());
                        dm.setUri(menu.getUri());
                        dm.setIcon(menu.getIcon());
                        dm.setText(menu.getText());
                        dm.setConfig(menu.getConfig());
                        dm.setDescription(menu.getDescription());
                        updateMenus.add(dm);
                    }
                    notNew = true;
                    break;
                }

            }
            if (!notNew) {
                newMenus.add(menu);
            }
        }


        if (newMenus.size() > 0) {
            menuDao.save(menus);
        }
        if (updateMenus.size() > 0) {
            menuDao.save(updateMenus);
        }
    }

    public void syncPermissionMenu(List<PermissionMenu> permissionMenus) {
        List<com.senpure.base.entity.PermissionMenu> dbPersmiison = permissionMenuDao.findAll();
        List<com.senpure.base.entity.PermissionMenu> save = new ArrayList<>();
        List<com.senpure.base.entity.PermissionMenu> update = new ArrayList<>();
        for (PermissionMenu permissionMenu : permissionMenus) {
            boolean saveThis=true;
            for (com.senpure.base.entity.PermissionMenu dbp : dbPersmiison) {

                if (dbp.getPermissionName().equals(permissionMenu.getPermissionName()) ) {
                   if(!dbp.getDataBaseUpdate())
                   {
                       dbp.setMenuId(permissionMenu.getMenuId());
                       update.add(dbp);
                       saveThis=false;
                       break;
                   }
                }
            }
            if(saveThis)
            {
                save.add(permissionMenu);

            }
        }
        if(save.size()>0)
        {
            permissionMenuDao.save(save);
        }
        if (update.size() > 0) {
            permissionMenuDao.save(update);
        }
    }
}
