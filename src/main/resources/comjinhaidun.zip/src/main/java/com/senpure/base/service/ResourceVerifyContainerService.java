package com.senpure.base.service;

import com.senpure.AppConstant;
import com.senpure.base.dao.AccountDao;
import com.senpure.base.dao.ContainerDao;
import com.senpure.base.entity.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/2/6.
 */
@Service
public class ResourceVerifyContainerService extends ResourceVerifySupportService<Integer> {

    public static final String VERIF_NAME = "containerResource";
    @Autowired
    private ContainerDao containerDao;
    @Autowired
    private AccountDao accountDao;

    @Override
    public String getName() {
        return VERIF_NAME;
    }


    @Override
    public boolean verify(int accountId, String resourceId) {
        Integer checkId = Integer.valueOf(resourceId);
        return verify(accountId, checkId);
    }

    public boolean verify(int accountId, int resourceId) {
        Account account = accountDao.getOne(accountId);
        com.senpure.base.entity.Container container = containerDao.findOne(resourceId);
        if(container==null)
        {
            logger.warn("容器Id{} 不存在",resourceId);
            return false;
        }
        logger.debug("账号所在容器id" + account.getContainer().getId());
        logger.debug("待检测的容器结构" + container.getContainerStructure());
        logger.debug(container.getContainerStructure().contains(AppConstant.CONTAINER_SEPARTOR + account.getContainer().getId())+"");
        return container.getContainerStructure().contains(AppConstant.CONTAINER_SEPARTOR + account.getContainer().getId());

    }
}
