package com.senpure.base.service;

import com.senpure.base.dao.AccountDao;
import com.senpure.base.dao.ContainerDao;
import com.senpure.base.entity.Account;
import com.senpure.base.entity.ContainerPermission;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2017/2/6.
 */
@Service
public class ResourceVerifyPermissionService extends ResourceVerifySupportService<Integer> {

    public static final String VERIF_NAME = "permissionResource";
    @Autowired
    private ContainerDao containerDao;
    @Autowired
    private AccountDao accountDao;

    @Override
    public String getName() {
        return VERIF_NAME;
    }


    @Override
    public boolean verify(int accountId, String resourceId) {
        Account account = accountDao.getOne(accountId);
        Integer checkId = Integer.valueOf(resourceId);
        List<ContainerPermission> containerPermissions = account.getContainer().getContainerPermissions();
        for (ContainerPermission cp : containerPermissions) {
            if (cp.getExpiry() == null || cp.getExpiry() == 0 || cp.getExpiry() > System.currentTimeMillis()) {
                if (cp.getPermission().getId() == checkId.intValue()) {
                    return true;
                }
            }
        }

        return false;
    }


}
