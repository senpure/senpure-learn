package com.senpure.base.service;

import com.senpure.AppConstant;
import com.senpure.base.dao.AccountDao;
import com.senpure.base.dao.ContainerDao;
import com.senpure.base.dao.RoleDao;
import com.senpure.base.entity.Account;
import com.senpure.base.entity.AccountRole;
import com.senpure.base.entity.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2017/2/6.
 */
@Service
public class ResourceVerifyRoleService extends ResourceVerifySupportService<Integer> {

    public static final String VERIF_NAME = "roleResource";
    @Autowired
    private ContainerDao containerDao;
    @Autowired
    private AccountDao accountDao;
    @Autowired
    private RoleDao roleDao;

    @Override
    public String getName() {
        return VERIF_NAME;
    }

    @Override
    public boolean verify(int accountId, String resourceId) {

        Account account = accountDao.getOne(accountId);
        int checkId = Integer.parseInt(resourceId);
        List<AccountRole> accountRoles = account.getAccountRoles();
        for (AccountRole ar : accountRoles) {
            if (ar.getRole().getId() == checkId) {
//                if (ar.getExpiry() == null || ar.getExpiry() == 0) {
//                    return true;
//                }
//                if (ar.getExpiry() > 0 && ar.getExpiry() > System.currentTimeMillis()) {
//                    return true;
//                }
//                return false;

                return true;
            }
        }
        account.getContainer();
        Role role = roleDao.findOne(checkId);
        return role.getContainer().getContainerStructure().contains(AppConstant.CONTAINER_SEPARTOR + account.getContainer().getId());

    }
}
