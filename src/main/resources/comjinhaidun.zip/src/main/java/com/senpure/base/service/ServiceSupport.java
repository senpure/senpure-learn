package com.senpure.base.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by 罗中正 on 2017/3/31.
 */
public class ServiceSupport {
    protected Logger log;


    public ServiceSupport() {
        super();
        log = LogManager.getLogger(getClass());
    }
}
