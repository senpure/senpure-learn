package com.senpure.base.service;

import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/2/6.
 */
@Service
public class SomethingResourceVerifyService extends ResourceVerifySupportService {
    @Override
    public String getName() {
        return "somethingResource";
    }

    @Override
    public boolean verify(int accountId, String resourceId) {
        return false;
    }
}
