package com.senpure.base.show;

import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 罗中正 on 2017/7/7.
 */
@Controller

public class ShowController extends BaseController {


    @RequestMapping("/show/{page}")
    public ModelAndView show(HttpServletRequest request,@PathVariable String page)
    {


        String view="show/"+page;

        return new ModelAndView(view);
    }
}
