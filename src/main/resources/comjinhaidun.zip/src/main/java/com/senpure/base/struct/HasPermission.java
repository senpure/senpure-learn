package com.senpure.base.struct;

import com.senpure.base.vo.PermissionVo;

/**
 * Created by 罗中正 on 2017/5/19.
 */
public class HasPermission extends PermissionVo implements Comparable<HasPermission> {
    private boolean has;
    private int middleId;

    public boolean isHas() {
        return has;
    }

    public void setHas(boolean has) {
        this.has = has;
    }

    public int getMiddleId() {
        return middleId;
    }

    public void setMiddleId(int middleId) {
        this.middleId = middleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HasPermission that = (HasPermission) o;

        return getMiddleId() == that.getMiddleId();
    }

    @Override
    public int hashCode() {
        return getMiddleId();
    }

    @Override
    public int compareTo(HasPermission o) {
        return getName().compareTo(o.getName());
    }
}
