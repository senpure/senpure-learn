package com.senpure.base.struct;

import com.senpure.base.menu.Menu;
import com.senpure.base.vo.AccountVo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/2/7.
 */
public class LoginedAccount  extends AccountVo{
    private static final long serialVersionUID = 1347550701424356203L;

    private List<Menu> viewMenus = new ArrayList<>();

    private List<MergePermission> permissions=new ArrayList<>();
    private List<KeyValue<String,String>> config=new ArrayList<>();





    public List<MergePermission> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<MergePermission> permissions) {
        this.permissions = permissions;
    }

    public List<KeyValue<String, String>> getConfig() {
        return config;
    }

    public void setConfig(List<KeyValue<String, String>> config) {
        this.config = config;
    }

    public List<Menu> getViewMenus() {
        return viewMenus;
    }

    public void setViewMenus(List<Menu> viewMenus) {
        this.viewMenus = viewMenus;
    }
}
