package com.senpure.base.util;

public interface Nameable  {
	
	String getName();

}
