package com.senpure.base.validator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * Created by 罗中正 on 2017/5/15.
 */
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = PatterbDateValidator.class)
@Documented
public @interface DynamicDate {
    String message() default "{time.format.error}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
