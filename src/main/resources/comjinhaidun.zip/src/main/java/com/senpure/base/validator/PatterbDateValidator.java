package com.senpure.base.validator;

import com.senpure.AppConstant;
import com.senpure.AppContext;
import com.senpure.base.struct.PatternDate;
import com.senpure.base.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/5/15.
 */
public class PatterbDateValidator implements ConstraintValidator<DynamicDate, PatternDate> {
    private Logger logger = LoggerFactory.getLogger(PatterbDateValidator.class);

    @Override
    public void initialize(DynamicDate dynamicDate) {

    }

    @Override
    public boolean isValid(PatternDate patternDate, ConstraintValidatorContext constraintValidatorContext) {

        if (StringUtil.isExistTrim(patternDate.getDateStr())) {
            DateFormat dateFormat = AppContext.getDateFormat(patternDate.getPattern() == null ? AppConstant.DFP_Y2D : patternDate.getPattern());
            if (dateFormat == null) {
                dateFormat = AppContext.getDateFormat(AppConstant.DFP_Y2D);
            }
            try {
                Date date = dateFormat.parse(patternDate.getDateStr());
                patternDate.setDate(date);
            } catch (ParseException e) {
                logger.error("时间转换出错 " + patternDate.getPattern() + "> " + patternDate.getDateStr(), e);
                return false;
            }
        }
        return true;
    }
}


