package com.senpure.base.vo;

import java.io.Serializable;
public class ContainerPermissionVo implements Serializable {
	private static final long serialVersionUID = 1495001168128L;


	private	Integer id;
	private	Integer containerId;
	private	Integer permissionId;
	private	Long expiry;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public Integer getContainerId() {
		return containerId;
	}


	public	void setContainerId(Integer containerId) {
		this.containerId=containerId ;
	}

	public Integer getPermissionId() {
		return permissionId;
	}


	public	void setPermissionId(Integer permissionId) {
		this.permissionId=permissionId ;
	}

	public Long getExpiry() {
		return expiry;
	}


	public	void setExpiry(Long expiry) {
		this.expiry=expiry ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}