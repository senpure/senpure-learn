package com.senpure.base.vo;

import java.io.Serializable;
import java.util.Date;
public class ContainerVo implements Serializable {
	private static final long serialVersionUID = 1495508553548L;


	private	Integer id;
	private	Integer parentId;
	private	String name;
	private	String description;
	private	Integer level;
	private	Integer relation;
	private	Long createTime;
	private	Date createDate;
	private	String containerStructure;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public Integer getParentId() {
		return parentId;
	}


	public	void setParentId(Integer parentId) {
		this.parentId=parentId ;
	}

	public String getName() {
		return name;
	}


	public	void setName(String name) {
		this.name=name ;
	}

	public String getDescription() {
		return description;
	}


	public	void setDescription(String description) {
		this.description=description ;
	}

	public Integer getLevel() {
		return level;
	}


	public	void setLevel(Integer level) {
		this.level=level ;
	}

	public Integer getRelation() {
		return relation;
	}


	public	void setRelation(Integer relation) {
		this.relation=relation ;
	}

	public Long getCreateTime() {
		return createTime;
	}


	public	void setCreateTime(Long createTime) {
		this.createTime=createTime ;
	}

	public Date getCreateDate() {
		return createDate;
	}


	public	void setCreateDate(Date createDate) {
		this.createDate=createDate ;
	}

	public String getContainerStructure() {
		return containerStructure;
	}


	public	void setContainerStructure(String containerStructure) {
		this.containerStructure=containerStructure ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}