package com.senpure.base.vo;

import java.io.Serializable;

public class IntEntityVo implements Serializable {
	private static final long serialVersionUID = 1495001168257L;


	private	Integer id;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}