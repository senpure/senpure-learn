#!/usr/bin/env bash
nohup java -jar mahjong.jar > /dev/null &
sh outToshell.sh