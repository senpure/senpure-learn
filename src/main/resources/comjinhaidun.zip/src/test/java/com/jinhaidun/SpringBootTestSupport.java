package com.jinhaidun;

import com.SpringBoot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by Administrator on 2017/1/16.
 */


@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBoot.class)
public class SpringBootTestSupport {

    protected Logger log;

    public SpringBootTestSupport() {
        log= LogManager.getLogger(getClass());
    }
}
