package com.jinhaidun.base.util;

import org.junit.Test;

/**
 * Created by 罗中正 on 2017/4/10.
 */
public class RandomUtilTest {
    @Test
    public void random() throws Exception {

        for (int i = 0; i < 10; i++) {
          //  System.out.println(RandomUtil.random(5));

        }
    }

    @Test
    public void ss() throws Exception {
    }

}