package com.jinhaidun.mahjong.logic;

import com.SpringBoot;
import com.jinhaidun.SpringBootTestSupport;
import org.junit.Test;

/**
 * Created by 罗中正 on 2017/5/3.
 */
public class GameRoomTest extends SpringBootTestSupport {
    @Test
    public void init() throws Exception {
        SpringBoot.getBean(GameRoom.class);
    }

}