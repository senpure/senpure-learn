package com.jinhaidun.mahjong.service;

import com.jinhaidun.SpringBootTestSupport;
import com.jinhaidun.mahjong.struct.Player;
import com.jinhaidun.store.em.ACCOUNT_TYPE;
import com.jinhaidun.store.service.PlayerService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/4/26.
 */
public class DefaultDataServiceImplTest extends SpringBootTestSupport {
    @Autowired
    private DataService dataService;
    @Autowired
    private PlayerService playerService;

    @Test
    public void updatePlayerRoom() throws Exception {

        dataService.updatePlayerRoom(600001,20002);
    }

    @Test
    public void playerOffline() throws Exception {
    }


    @Test
    public void playerLogin() throws Exception {
        Map<String, Object> context = new HashMap<>();

        String token = playerService.findId("admin3", ACCOUNT_TYPE.VISITOR.toString(), context)
                .get("token").toString();
        Player player = dataService.playerLogin(token, context);
        log.debug("player---------------------\n" + player);

    }

}