package com.jinhaidun.mahjong.struct;

import com.jinhaidun.mahjong.util.TileUtil;
import org.junit.Test;

/**
 * Created by 罗中正 on 2017/5/5.
 */
public class RenQiuMahjongTest {

    @Test
    public void tileTest()
    {

        RenQiuMahjong mahjong= TileUtil.generateRenQiuMahjion();

        System.out.println(mahjong.currentTiles().size());

        mahjong.getTiles(13);
        mahjong.getTiles(13);
        mahjong.getTiles(13);
        System.out.println(mahjong.currentTiles().size());
        mahjong.nextTime();
        System.out.println(mahjong.currentTiles().size());


    }
    @Test
    public void birtest()
    {
        System.out.println(0>>2);
        System.out.println(1>>2);

    }

}