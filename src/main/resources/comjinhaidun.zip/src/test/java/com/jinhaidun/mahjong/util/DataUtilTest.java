package com.jinhaidun.mahjong.util;

import org.junit.Test;

/**
 * Created by 罗中正 on 2017/6/6.
 */

public class DataUtilTest {
    @Test
    public void action()
    {

    }

}