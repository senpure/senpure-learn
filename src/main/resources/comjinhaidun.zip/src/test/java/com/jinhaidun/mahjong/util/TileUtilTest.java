package com.jinhaidun.mahjong.util;

import com.jinhaidun.mahjong.struct.HuPai;
import com.jinhaidun.mahjong.struct.RenQiuMahjong;
import com.jinhaidun.mahjong.struct.Seat;
import com.jinhaidun.mahjong.struct.Tile;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/11.
 */
public class TileUtilTest {
    @Test
    public void moveTiles() throws Exception {

        RenQiuMahjong renQiuMahjong=TileUtil.generateRenQiuMahjion();

        Seat seat=new Seat();

        seat. hand=renQiuMahjong.getTiles(14);

        //Collections.sort(seat.hand);

        System.out.println(TileUtil.countTile(seat. hand,22));
        System.out.println(seat. hand);
        System.out.println(seat.out);
        TileUtil.moveTiles(seat. hand,seat.out,23,1);
        System.out.println(seat. hand);
        System.out.println(seat.out.get(seat.out.size()-1));
    }

    private static Tile tile = new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3));

    private List<Tile> getHuPai() {

        List<Tile> tiles = new ArrayList<>();
        // tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(3)));

        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(2)));

        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));

        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));



        Collections.shuffle(tiles);
        return tiles;
    }

    private List<Tile> getQidui() {
        List<Tile> tiles = new ArrayList<>();

        // tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(2)));

        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(6)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));

        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        return tiles;
    }
    private List<Tile> getTile() {
        List<Tile> tiles = new ArrayList<>();

        // tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));

        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(2)));

        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(4)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        return tiles;
    }

    private List<Tile> getTile2() {
        List<Tile> tiles = new ArrayList<>();

        // tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));

        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(2)));

        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(4)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.FENG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));


        return tiles;
    }
    @Test
    public void huPaile() throws Exception {

        System.out.println(TileUtil.checkHuPai(getHuPai(), tile.getIntValue()));
       System.out.println(TileUtil.checkHuPai(getQidui(), tile.getIntValue()));
        System.out.println(TileUtil.checkHuPai(getTile(), tile.getIntValue()));
        System.out.println(TileUtil.checkHuPai(getTile2(), tile.getIntValue()));
    }

    @Test
    public void huPai() throws Exception {

        Tile baida = new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3));


        List<Tile> tiles = new ArrayList<>();

        // tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(9)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(5)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(6)));
        tiles.add(new Tile(Tile.SUIT.TIAO, Tile.RANK.getRank(7)));


        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(4)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(4)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));


        System.out.println(TileUtil.checkHuPai(tiles, baida.getIntValue()));
        ;
    }

    @Test
    public void testOneBaida()
    {

        Tile baida = new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3));
        List<Tile> tiles = new ArrayList<>();

        // tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(1)));
        tiles.add(new Tile(Tile.SUIT.TONG, Tile.RANK.getRank(2)));
       tiles.add(new Tile(Tile.SUIT.WAN, Tile.RANK.getRank(3)));
        HuPai huPai = TileUtil.checkHuPai(tiles, baida.getIntValue());
        System.out.println(huPai);
    }

    public static void main(String[] args) {

        int score=5;
        score<<=1;
        System.out.println(score);
    }

}