package com.jinhaidun.store.dao;

import com.jinhaidun.SpringBootTestSupport;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by 罗中正 on 2017/5/12.
 */
public class ClientResourceDaoTest extends SpringBootTestSupport {

    @Autowired
    private ClientResourceDao clientResourceDao;
    @Test
    public void findByChannelPackageAndResourceVersionGreaterThanEqual() throws Exception {

        System.out.println(clientResourceDao.findByChannelPackageAndResourceVersionGreaterThanEqual("IOS",0));
    }

}