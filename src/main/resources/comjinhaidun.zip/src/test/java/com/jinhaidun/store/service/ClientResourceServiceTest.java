package com.jinhaidun.store.service;

import com.jinhaidun.SpringBootTestSupport;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by 罗中正 on 2017/5/8.
 */
public class ClientResourceServiceTest extends SpringBootTestSupport {
    @Autowired
    private ClientResourceService clientResourceService;
    @Test
    public void currentResource() throws Exception {
    }

    @Test
    public void getResources() throws Exception {

        clientResourceService.getResources("IOS",5);
    }


    @Test
    public void currentResourceVersion() throws Exception {
       log.debug( clientResourceService.currentResourceVersion("IOS"));
    }

    @Test
    public void updateResource() throws Exception {

        clientResourceService.updateResource("IOS",8,"baido.com");
        currentResourceVersion();
    }

}