package com.jinhaidun.store.service;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.compressors.CompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream;
import org.apache.commons.compress.compressors.gzip.GzipParameters;
import org.junit.Test;

import java.io.*;

/**
 * Created by 罗中正 on 2017/5/10.
 */
public class Compress {


    @Test
    public void compress() {
        System.out.println("compress");
        String path = "E:\\data\\compress\\compres77s.zip";
        String source = "E:\\data\\compress";
        String one = "E:\\data\\compress\\Logger.java";
        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(path);

            GzipParameters gzipParameters = new GzipParameters();
            gzipParameters.setFilename("lo.java");
            CompressorOutputStream gzippedOut = new GzipCompressorOutputStream(outputStream, gzipParameters);
            InputStream inputStream = new FileInputStream(one);


            int buff = 50;
            byte[] data = new byte[buff];
            int num = inputStream.read(data);

            while (num > -1) {
                gzippedOut.write(data, 0, num);
                //num=inputStream.read(data);
            }
            gzippedOut.flush();
            // gzippedOut.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void c() throws Exception {
        System.out.println("compress");
        String path = "E:\\data\\compress\\compresszip.zip";
        String source = "E:\\data\\compress";
        String one = "E:\\data\\compress\\msg\\";
        File zipFile = new File(path);
        File onefile = new File(one);
        OutputStream outputStream = new FileOutputStream(path);
        ZipArchiveEntry zipArchiveEntry = new ZipArchiveEntry(onefile, onefile.getName());
        ZipArchiveOutputStream zipout = new ZipArchiveOutputStream(outputStream);
        zipout.putArchiveEntry(zipArchiveEntry);
        long entrySize = zipArchiveEntry.getSize();
        int writeSize = Integer.MAX_VALUE;
        while (entrySize > Integer.MAX_VALUE) {
            entrySize -= writeSize;
            zipout.write(writeSize);
        }
        zipout.write((int) entrySize);
        zipout.closeArchiveEntry();
    }

    public void un() throws Exception {
        String path = "E:\\data\\compress\\msg.zip";

        ZipArchiveEntry entry = new ZipArchiveEntry("name");

    }
}
