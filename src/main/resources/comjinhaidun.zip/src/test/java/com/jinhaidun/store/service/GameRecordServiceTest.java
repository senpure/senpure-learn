package com.jinhaidun.store.service;

import com.jinhaidun.SpringBootTestSupport;
import com.jinhaidun.store.criterion.RoundResultCriteria;
import com.jinhaidun.store.entity.PlayerRoundResult;
import com.jinhaidun.store.entity.RoundResult;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by 罗中正 on 2017/5/31.
 */
public class GameRecordServiceTest extends SpringBootTestSupport {
    @Autowired
    private GameRecordService gameRecordService;
    @Test
    public void loadRoundResult() throws Exception {


        RoundResultCriteria criteria=new RoundResultCriteria();
        criteria.setPlayerId(123);
        System.out.println(gameRecordService.loadRoundResult(criteria)); ;
    }

    @Test
    public void saveresult(){

        RoundResult roundResult=new RoundResult();
        roundResult.setDeatilScore("ds");
        roundResult.setFinallyScore("fs");
        roundResult.setRoomId(666666);
        roundResult.setCreateTime(System.currentTimeMillis());
        roundResult.setCreateDate(new Date());
        roundResult.setRecordId(123456);
        List<PlayerRoundResult> roundResultList = new ArrayList<>();
        for (int i = 0; i <4 ; i++) {
            PlayerRoundResult playerRoundResult = new PlayerRoundResult();
            playerRoundResult.setPlayerId(123+i);
            playerRoundResult.setRoundResult(roundResult);
            roundResultList.add(playerRoundResult);
        }
        //gameRecordService.savePlayerRecord(roundResultList);
    }

}