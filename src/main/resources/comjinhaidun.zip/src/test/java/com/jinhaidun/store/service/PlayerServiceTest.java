package com.jinhaidun.store.service;

import com.jinhaidun.SpringBootTestSupport;
import com.jinhaidun.store.em.ACCOUNT_TYPE;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

/**
 * Created by 罗中正 on 2017/4/25.
 */
public class PlayerServiceTest extends SpringBootTestSupport{
    @Test
    public void login() throws Exception {

       // playerService.login("admin212",ACCOUNT_TYPE.VISITOR.toString(),null);

    }

    @Autowired
    PlayerService playerService;
    @Autowired
    WebApplicationContext webApplicationConnect;
    @Test
    public void loadPlayer() throws Exception {

        MockMvc mvc= MockMvcBuilders.webAppContextSetup(webApplicationConnect).build();
        MvcResult mvcResult =  mvc.perform(MockMvcRequestBuilders.get("/game/login")
                .param("account","playerId")
        .param("type",ACCOUNT_TYPE.VISITOR.toString()))
        .andReturn();

        log.debug(mvcResult);

       // playerService.loadPlayer(ACCOUNT_TYPE.VISITOR.toString(),"playerId");
    }

}