package com.jhd.game.handler;

import com.jhd.game.message.SSServerErrorMessage;
import com.senpure.io.message.AbstractMessageHandler;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 错误信息处理器
 * 
 * @author senpure-generator
 * @version 2017-8-28 14:29:24
 */
@Component
public class SSServerErrorMessageHandler extends AbstractMessageHandler<SSServerErrorMessage> {

    @Override
    public void execute(Channel channel, SSServerErrorMessage message) {
        //TODO 请在这里写下你的代码

    }

    @Override
    public int handlerId() {
    return 10102;
    }

    @Override
    public SSServerErrorMessage getEmptyMessage() {
    return new SSServerErrorMessage();
    }

    }