package com.jhd.game.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
 * 错误信息
 * 
 * @author senpure-generator
 * @version 2017-9-5 17:57:04
 */
public class SSServerErrorMessage extends  Message {
    //错误ID
    private int code;
    //错误消息
    private String messsage;
    //格式化的参数
    private List<String> args=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //错误ID
        writeInt(buf,code);
        //错误消息
        writeStr(buf,messsage);
        //格式化的参数
        int argsSize=args.size();
        writeShort(buf,argsSize);
        for(int i=0;i< argsSize;i++){
            writeStr(buf,args.get(i));
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //错误ID
        this.code=readInt(buf);
        //错误消息
        this.messsage=readStr(buf);
        //格式化的参数
        int argsSize=readShort(buf);
        for(int i=0;i<argsSize;i++){
            this.args.add(readStr(buf));
         }
    }

    public  int getCode(){
        return code;
}

    public SSServerErrorMessage setCode(int code){
        this.code=code;
        return this;
}
    public  String getMesssage(){
        return messsage;
}

    public SSServerErrorMessage setMesssage(String messsage){
        this.messsage=messsage;
        return this;
}
    public List<String> getArgs(){
        return args;
    }
    public SSServerErrorMessage setArgs (List<String> args){
        this.args=args;
        return this;
    }


    @Override
    public int getMessageId() {
    return 10102;
    }

    @Override
    public String toString() {
        return "SSServerErrorMessage{"
                +"code=" + code
                +",messsage=" + messsage
                +",args=" + args
                + "}";
   }

    //8 + 3 = 11 个空格
    private String nextIndent ="           ";
    //最长字段长度 8
    private int filedPad = 8;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SSServerErrorMessage").append("{");
        //错误ID
        sb.append("\n");
        sb.append(indent).append(rightPad("code", filedPad)).append(" = ").append(code);
        //错误消息
        sb.append("\n");
        sb.append(indent).append(rightPad("messsage", filedPad)).append(" = ").append(messsage);
        //格式化的参数
        sb.append("\n");
        sb.append(indent).append(rightPad("args", filedPad)).append(" = ");
        int argsSize = args.size();
        if (argsSize > 0) {
            sb.append("[");
            for (int i = 0; i<argsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(args.get(i));
            }
            sb.append("\n");
    sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}