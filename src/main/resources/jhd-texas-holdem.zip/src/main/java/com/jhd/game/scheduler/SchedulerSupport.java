package com.jhd.game.scheduler;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by 罗中正 on 2017/4/26.
 */
@EnableScheduling
public class SchedulerSupport {

    protected Logger logger;

    public SchedulerSupport() {

        logger = LoggerFactory.getLogger(getClass());

    }
}
