package com.jhd.game.test.handler;

import com.jhd.game.test.bean.Author;
import com.jhd.game.test.bean.Book;
import com.jhd.game.test.bean.Student;
import com.jhd.game.test.message.CSStudentMessage;
import com.jhd.game.test.message.SCStudentMessage;
import com.senpure.io.message.AbstractMessageHandler;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求学生信息处理器
 * 
 * @author senpure-generator
 * @version 2017-8-28 14:29:24
 */
@Component
public class CSStudentMessageHandler extends AbstractMessageHandler<CSStudentMessage> {

    @Override
    public void execute(Channel channel, CSStudentMessage message) {
        //TODO 请在这里写下你的代码
        Book readBook = new Book();
        readBook.setName("罗密欧与朱丽叶");
        //readBook.setName("ruomio and zhuliy");

        Author author=new Author();
        author.setPhone(123456);
        author.setName("jklLUo林");
        readBook.setAuthor(author);
        readBook.setPrice(25);
        Student student = new Student();
        student.setAge(23);
        student.setNum(10086);
        student.setName("xiaoming名");
        student.setReadBook(readBook);
        student.getLuckNums().add(101);
        student.getLuckNums().add(998);
        student.getProvide().add("nice to meeet you ");
        student.getLikeBooks().add(readBook);
        for (int i = 0; i < 2; i++) {
            Book book = new Book();
            book.setName("halibote哈利波特(" + (i + 1) + ")");
            book.setPrice(28);
            if(i==1)
            {
                author=new Author();
                author.setName("xitulu");
                author.setPhone(66666);
                book.setAuthor(author);
            }
            student.getLikeBooks().add(book);
        }
        SCStudentMessage msg = new SCStudentMessage();

        msg.setStudent(student);

        channel.writeAndFlush(msg);

    }

    @Override
    public int handlerId() {
    return 66101;
    }

    @Override
    public CSStudentMessage getEmptyMessage() {
    return new CSStudentMessage();
    }

    }