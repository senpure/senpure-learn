package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
* 德州扑克房间
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class GameRoom extends  Bean {
    //房间ID
    private int roomId;
    //房间状态 CLOSING, CLOSED, READYING, PLAYING
    private String state;
    //筹码边池
    private List<Double> edgePool=new ArrayList();
    //筹码池
    private double chipPool;
    //大盲注
    private double bigBlind;
    //大盲注位置
    private int bigBlindIndex;
    //小盲注位置
    private int smallBlindIndex;
    //当前轮到做动作的位置
    private int currentIndex;
    //公共牌
    private List<Integer> publicCards=new ArrayList();
    //座位
    private List<Seat> seats=new ArrayList();
    //房间创建时间
    private double createTime;
    //房间创建玩家ID
    private int createPlayerId;
    //玩了几局了
    private int playedRound;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //房间ID
        writeInt(buf,roomId);
        //房间状态 CLOSING, CLOSED, READYING, PLAYING
        writeStr(buf,state);
        //筹码边池
        int edgePoolSize=edgePool.size();
        writeShort(buf,edgePoolSize);
        for(int i=0;i< edgePoolSize;i++){
            writeDouble(buf,edgePool.get(i));
           }
        //筹码池
        writeDouble(buf,chipPool);
        //大盲注
        writeDouble(buf,bigBlind);
        //大盲注位置
        writeInt(buf,bigBlindIndex);
        //小盲注位置
        writeInt(buf,smallBlindIndex);
        //当前轮到做动作的位置
        writeInt(buf,currentIndex);
        //公共牌
        int publicCardsSize=publicCards.size();
        writeShort(buf,publicCardsSize);
        for(int i=0;i< publicCardsSize;i++){
            writeInt(buf,publicCards.get(i));
           }
        //座位
        int seatsSize=seats.size();
        writeShort(buf,seatsSize);
        for(int i=0;i< seatsSize;i++){
            writeBean(buf,seats.get(i),false);
           }
        //房间创建时间
        writeDouble(buf,createTime);
        //房间创建玩家ID
        writeInt(buf,createPlayerId);
        //玩了几局了
        writeInt(buf,playedRound);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //房间ID
        this.roomId = readInt(buf);
        //房间状态 CLOSING, CLOSED, READYING, PLAYING
        this.state= readStr(buf);
        //筹码边池
        int edgePoolSize=readShort(buf);
        for(int i=0;i<edgePoolSize;i++){
            this.edgePool.add(readDouble(buf));
         }
        //筹码池
        this.chipPool = readDouble(buf);
        //大盲注
        this.bigBlind = readDouble(buf);
        //大盲注位置
        this.bigBlindIndex = readInt(buf);
        //小盲注位置
        this.smallBlindIndex = readInt(buf);
        //当前轮到做动作的位置
        this.currentIndex = readInt(buf);
        //公共牌
        int publicCardsSize=readShort(buf);
        for(int i=0;i<publicCardsSize;i++){
            this.publicCards.add(readInt(buf));
         }
        //座位
        int seatsSize=readShort(buf);
        for(int i=0;i<seatsSize;i++){
            this.seats.add((Seat)readBean(buf,Seat.class,false));
         }
        //房间创建时间
        this.createTime = readDouble(buf);
        //房间创建玩家ID
        this.createPlayerId = readInt(buf);
        //玩了几局了
        this.playedRound = readInt(buf);
    }

    /**
     * get 房间ID
     * @return
     */
    public  int getRoomId(){
        return roomId;
}

    /**
     * set 房间ID
     */
    public GameRoom setRoomId(int roomId){
        this.roomId=roomId;
        return this;
}
    /**
     * get 房间状态 CLOSING, CLOSED, READYING, PLAYING
     * @return
     */
    public  String getState(){
        return state;
}

    /**
     * set 房间状态 CLOSING, CLOSED, READYING, PLAYING
     */
    public GameRoom setState(String state){
        this.state=state;
        return this;
}
     /**
      * get 筹码边池
      * @return
      */
    public List<Double> getEdgePool(){
        return edgePool;
    }
     /**
      * set 筹码边池
      */
    public GameRoom setEdgePool (List<Double> edgePool){
        this.edgePool=edgePool;
        return this;
    }

    /**
     * get 筹码池
     * @return
     */
    public  double getChipPool(){
        return chipPool;
}

    /**
     * set 筹码池
     */
    public GameRoom setChipPool(double chipPool){
        this.chipPool=chipPool;
        return this;
}
    /**
     * get 大盲注
     * @return
     */
    public  double getBigBlind(){
        return bigBlind;
}

    /**
     * set 大盲注
     */
    public GameRoom setBigBlind(double bigBlind){
        this.bigBlind=bigBlind;
        return this;
}
    /**
     * get 大盲注位置
     * @return
     */
    public  int getBigBlindIndex(){
        return bigBlindIndex;
}

    /**
     * set 大盲注位置
     */
    public GameRoom setBigBlindIndex(int bigBlindIndex){
        this.bigBlindIndex=bigBlindIndex;
        return this;
}
    /**
     * get 小盲注位置
     * @return
     */
    public  int getSmallBlindIndex(){
        return smallBlindIndex;
}

    /**
     * set 小盲注位置
     */
    public GameRoom setSmallBlindIndex(int smallBlindIndex){
        this.smallBlindIndex=smallBlindIndex;
        return this;
}
    /**
     * get 当前轮到做动作的位置
     * @return
     */
    public  int getCurrentIndex(){
        return currentIndex;
}

    /**
     * set 当前轮到做动作的位置
     */
    public GameRoom setCurrentIndex(int currentIndex){
        this.currentIndex=currentIndex;
        return this;
}
     /**
      * get 公共牌
      * @return
      */
    public List<Integer> getPublicCards(){
        return publicCards;
    }
     /**
      * set 公共牌
      */
    public GameRoom setPublicCards (List<Integer> publicCards){
        this.publicCards=publicCards;
        return this;
    }

    public List<Seat> getSeats(){
        return seats;
    }
    public GameRoom setSeats (List<Seat> seats){
        this.seats=seats;
        return this;
    }

    /**
     * get 房间创建时间
     * @return
     */
    public  double getCreateTime(){
        return createTime;
}

    /**
     * set 房间创建时间
     */
    public GameRoom setCreateTime(double createTime){
        this.createTime=createTime;
        return this;
}
    /**
     * get 房间创建玩家ID
     * @return
     */
    public  int getCreatePlayerId(){
        return createPlayerId;
}

    /**
     * set 房间创建玩家ID
     */
    public GameRoom setCreatePlayerId(int createPlayerId){
        this.createPlayerId=createPlayerId;
        return this;
}
    /**
     * get 玩了几局了
     * @return
     */
    public  int getPlayedRound(){
        return playedRound;
}

    /**
     * set 玩了几局了
     */
    public GameRoom setPlayedRound(int playedRound){
        this.playedRound=playedRound;
        return this;
}

    @Override
    public String toString() {
        return "GameRoom{"
                +"roomId=" + roomId
                +",state=" + state
                +",edgePool=" + edgePool
                +",chipPool=" + chipPool
                +",bigBlind=" + bigBlind
                +",bigBlindIndex=" + bigBlindIndex
                +",smallBlindIndex=" + smallBlindIndex
                +",currentIndex=" + currentIndex
                +",publicCards=" + publicCards
                +",seats=" + seats
                +",createTime=" + createTime
                +",createPlayerId=" + createPlayerId
                +",playedRound=" + playedRound
                + "}";
   }

    //15 + 3 = 18 个空格
    private String nextIndent ="                  ";
    //最长字段长度 15
    private int filedPad = 15;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("GameRoom").append("{");
        //房间ID
        sb.append("\n");
        sb.append(indent).append(rightPad("roomId", filedPad)).append(" = ").append(roomId);
        //房间状态 CLOSING, CLOSED, READYING, PLAYING
        sb.append("\n");
        sb.append(indent).append(rightPad("state", filedPad)).append(" = ").append(state);
        //筹码边池
        sb.append("\n");
        sb.append(indent).append(rightPad("edgePool", filedPad)).append(" = ");
        int edgePoolSize = edgePool.size();
        if (edgePoolSize > 0) {
            sb.append("[");
            for (int i = 0; i<edgePoolSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(edgePool.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        //筹码池
        sb.append("\n");
        sb.append(indent).append(rightPad("chipPool", filedPad)).append(" = ").append(chipPool);
        //大盲注
        sb.append("\n");
        sb.append(indent).append(rightPad("bigBlind", filedPad)).append(" = ").append(bigBlind);
        //大盲注位置
        sb.append("\n");
        sb.append(indent).append(rightPad("bigBlindIndex", filedPad)).append(" = ").append(bigBlindIndex);
        //小盲注位置
        sb.append("\n");
        sb.append(indent).append(rightPad("smallBlindIndex", filedPad)).append(" = ").append(smallBlindIndex);
        //当前轮到做动作的位置
        sb.append("\n");
        sb.append(indent).append(rightPad("currentIndex", filedPad)).append(" = ").append(currentIndex);
        //公共牌
        sb.append("\n");
        sb.append(indent).append(rightPad("publicCards", filedPad)).append(" = ");
        int publicCardsSize = publicCards.size();
        if (publicCardsSize > 0) {
            sb.append("[");
            for (int i = 0; i<publicCardsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(publicCards.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        //座位
        sb.append("\n");
        sb.append(indent).append(rightPad("seats", filedPad)).append(" = ");
        int seatsSize = seats.size();
        if (seatsSize > 0) {
            sb.append("[");
            for (int i = 0; i<seatsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(seats.get(i).toString(indent + nextIndent));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        //房间创建时间
        sb.append("\n");
        sb.append(indent).append(rightPad("createTime", filedPad)).append(" = ").append(createTime);
        //房间创建玩家ID
        sb.append("\n");
        sb.append(indent).append(rightPad("createPlayerId", filedPad)).append(" = ").append(createPlayerId);
        //玩了几局了
        sb.append("\n");
        sb.append(indent).append(rightPad("playedRound", filedPad)).append(" = ").append(playedRound);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}