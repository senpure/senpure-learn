package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
* 比牌座位
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class PkSeat extends  Bean {
    //座位编号(下标为零开始)
    private int index;
    //手牌
    private List<Integer> handCards=new ArrayList();
    //牌型
    private TexasCards texasCards;
    //边池的index 下标0开始 -1 表示主池
    private int poolIndex;
    //收益
    private double chip;
    //输赢
    private boolean win;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号(下标为零开始)
        writeInt(buf,index);
        //手牌
        int handCardsSize=handCards.size();
        writeShort(buf,handCardsSize);
        for(int i=0;i< handCardsSize;i++){
            writeInt(buf,handCards.get(i));
           }
        //牌型
        writeBean(buf,texasCards,true);
        //边池的index 下标0开始 -1 表示主池
        writeInt(buf,poolIndex);
        //收益
        writeDouble(buf,chip);
        //输赢
        writeBoolean(buf,win);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号(下标为零开始)
        this.index = readInt(buf);
        //手牌
        int handCardsSize=readShort(buf);
        for(int i=0;i<handCardsSize;i++){
            this.handCards.add(readInt(buf));
         }
        //牌型
        this.texasCards = (TexasCards)readBean(buf,TexasCards.class,true);
        //边池的index 下标0开始 -1 表示主池
        this.poolIndex = readInt(buf);
        //收益
        this.chip = readDouble(buf);
        //输赢
        this.win = readBoolean(buf);
    }

    /**
     * get 座位编号(下标为零开始)
     * @return
     */
    public  int getIndex(){
        return index;
}

    /**
     * set 座位编号(下标为零开始)
     */
    public PkSeat setIndex(int index){
        this.index=index;
        return this;
}
    public List<Integer> getHandCards(){
        return handCards;
    }
    public PkSeat setHandCards (List<Integer> handCards){
        this.handCards=handCards;
        return this;
    }

    public  TexasCards getTexasCards(){
        return texasCards;
}

    public PkSeat setTexasCards(TexasCards texasCards){
        this.texasCards=texasCards;
        return this;
}
    /**
     * get 边池的index 下标0开始 -1 表示主池
     * @return
     */
    public  int getPoolIndex(){
        return poolIndex;
}

    /**
     * set 边池的index 下标0开始 -1 表示主池
     */
    public PkSeat setPoolIndex(int poolIndex){
        this.poolIndex=poolIndex;
        return this;
}
    public  double getChip(){
        return chip;
}

    public PkSeat setChip(double chip){
        this.chip=chip;
        return this;
}
    public  boolean  isWin(){
        return win;
}

    public PkSeat setWin(boolean win){
        this.win=win;
        return this;
}

    @Override
    public String toString() {
        return "PkSeat{"
                +"index=" + index
                +",handCards=" + handCards
                +",texasCards=" + texasCards
                +",poolIndex=" + poolIndex
                +",chip=" + chip
                +",win=" + win
                + "}";
   }

    //10 + 3 = 13 个空格
    private String nextIndent ="             ";
    //最长字段长度 10
    private int filedPad = 10;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("PkSeat").append("{");
        //座位编号(下标为零开始)
        sb.append("\n");
        sb.append(indent).append(rightPad("index", filedPad)).append(" = ").append(index);
        //手牌
        sb.append("\n");
        sb.append(indent).append(rightPad("handCards", filedPad)).append(" = ");
        int handCardsSize = handCards.size();
        if (handCardsSize > 0) {
            sb.append("[");
            for (int i = 0; i<handCardsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(handCards.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        //牌型
        sb.append("\n");
        sb.append(indent).append(rightPad("texasCards", filedPad)).append(" = ");
        if(texasCards!=null){
            sb.append(texasCards.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        //边池的index 下标0开始 -1 表示主池
        sb.append("\n");
        sb.append(indent).append(rightPad("poolIndex", filedPad)).append(" = ").append(poolIndex);
        //收益
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        //输赢
        sb.append("\n");
        sb.append(indent).append(rightPad("win", filedPad)).append(" = ").append(win);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}