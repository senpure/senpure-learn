package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
* 比牌组-废弃(2017.09.26)
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class PkSeatGroup extends  Bean {
    //比牌座位
    private List<PkSeat> pkSeats=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //比牌座位
        int pkSeatsSize=pkSeats.size();
        writeShort(buf,pkSeatsSize);
        for(int i=0;i< pkSeatsSize;i++){
            writeBean(buf,pkSeats.get(i),false);
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //比牌座位
        int pkSeatsSize=readShort(buf);
        for(int i=0;i<pkSeatsSize;i++){
            this.pkSeats.add((PkSeat)readBean(buf,PkSeat.class,false));
         }
    }

     /**
      * get 比牌座位
      * @return
      */
    public List<PkSeat> getPkSeats(){
        return pkSeats;
    }
     /**
      * set 比牌座位
      */
    public PkSeatGroup setPkSeats (List<PkSeat> pkSeats){
        this.pkSeats=pkSeats;
        return this;
    }


    @Override
    public String toString() {
        return "PkSeatGroup{"
                +"pkSeats=" + pkSeats
                + "}";
   }

    //7 + 3 = 10 个空格
    private String nextIndent ="          ";
    //最长字段长度 7
    private int filedPad = 7;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("PkSeatGroup").append("{");
        //比牌座位
        sb.append("\n");
        sb.append(indent).append(rightPad("pkSeats", filedPad)).append(" = ");
        int pkSeatsSize = pkSeats.size();
        if (pkSeatsSize > 0) {
            sb.append("[");
            for (int i = 0; i<pkSeatsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(pkSeats.get(i).toString(indent + nextIndent));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}