package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

/**
* 玩家信息
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class Player extends  Bean {
    //玩家ID
    private int id;
    //玩家昵称
    private String nick;
    //玩家头像
    private String head;
    //玩家总筹码
    private double chip;
    //玩家在牌局中筹码
    private double playingChip;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //玩家ID
        writeInt(buf,id);
        //玩家昵称
        writeStr(buf,nick);
        //玩家头像
        writeStr(buf,head);
        //玩家总筹码
        writeDouble(buf,chip);
        //玩家在牌局中筹码
        writeDouble(buf,playingChip);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //玩家ID
        this.id = readInt(buf);
        //玩家昵称
        this.nick= readStr(buf);
        //玩家头像
        this.head= readStr(buf);
        //玩家总筹码
        this.chip = readDouble(buf);
        //玩家在牌局中筹码
        this.playingChip = readDouble(buf);
    }

    /**
     * get 玩家ID
     * @return
     */
    public  int getId(){
        return id;
}

    /**
     * set 玩家ID
     */
    public Player setId(int id){
        this.id=id;
        return this;
}
    /**
     * get 玩家昵称
     * @return
     */
    public  String getNick(){
        return nick;
}

    /**
     * set 玩家昵称
     */
    public Player setNick(String nick){
        this.nick=nick;
        return this;
}
    /**
     * get 玩家头像
     * @return
     */
    public  String getHead(){
        return head;
}

    /**
     * set 玩家头像
     */
    public Player setHead(String head){
        this.head=head;
        return this;
}
    /**
     * get 玩家总筹码
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 玩家总筹码
     */
    public Player setChip(double chip){
        this.chip=chip;
        return this;
}
    /**
     * get 玩家在牌局中筹码
     * @return
     */
    public  double getPlayingChip(){
        return playingChip;
}

    /**
     * set 玩家在牌局中筹码
     */
    public Player setPlayingChip(double playingChip){
        this.playingChip=playingChip;
        return this;
}

    @Override
    public String toString() {
        return "Player{"
                +"id=" + id
                +",nick=" + nick
                +",head=" + head
                +",chip=" + chip
                +",playingChip=" + playingChip
                + "}";
   }

    //最长字段长度 11
    private int filedPad = 11;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("Player").append("{");
        //玩家ID
        sb.append("\n");
        sb.append(indent).append(rightPad("id", filedPad)).append(" = ").append(id);
        //玩家昵称
        sb.append("\n");
        sb.append(indent).append(rightPad("nick", filedPad)).append(" = ").append(nick);
        //玩家头像
        sb.append("\n");
        sb.append(indent).append(rightPad("head", filedPad)).append(" = ").append(head);
        //玩家总筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        //玩家在牌局中筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("playingChip", filedPad)).append(" = ").append(playingChip);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}