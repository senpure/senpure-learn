package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
* 座位信息
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class Seat extends  Bean {
    //座位编号(下标为零开始)
    private int index;
    //座位状态 IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN
    private String state;
    //是否在线
    private boolean online;
    //本轮下的筹码
    private double betChip;
    //本阶段的筹码
    private double phaseBetChip;
    //轮到该座位的时间
    private double turnTime;
    //座位上的玩家
    private Player player;
    //手牌
    private List<Integer> handCards=new ArrayList();
    //牌型
    private TexasCards texasCards;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号(下标为零开始)
        writeInt(buf,index);
        //座位状态 IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN
        writeStr(buf,state);
        //是否在线
        writeBoolean(buf,online);
        //本轮下的筹码
        writeDouble(buf,betChip);
        //本阶段的筹码
        writeDouble(buf,phaseBetChip);
        //轮到该座位的时间
        writeDouble(buf,turnTime);
        //座位上的玩家
        writeBean(buf,player,true);
        //手牌
        int handCardsSize=handCards.size();
        writeShort(buf,handCardsSize);
        for(int i=0;i< handCardsSize;i++){
            writeInt(buf,handCards.get(i));
           }
        //牌型
        writeBean(buf,texasCards,true);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号(下标为零开始)
        this.index = readInt(buf);
        //座位状态 IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN
        this.state= readStr(buf);
        //是否在线
        this.online = readBoolean(buf);
        //本轮下的筹码
        this.betChip = readDouble(buf);
        //本阶段的筹码
        this.phaseBetChip = readDouble(buf);
        //轮到该座位的时间
        this.turnTime = readDouble(buf);
        //座位上的玩家
        this.player = (Player)readBean(buf,Player.class,true);
        //手牌
        int handCardsSize=readShort(buf);
        for(int i=0;i<handCardsSize;i++){
            this.handCards.add(readInt(buf));
         }
        //牌型
        this.texasCards = (TexasCards)readBean(buf,TexasCards.class,true);
    }

    /**
     * get 座位编号(下标为零开始)
     * @return
     */
    public  int getIndex(){
        return index;
}

    /**
     * set 座位编号(下标为零开始)
     */
    public Seat setIndex(int index){
        this.index=index;
        return this;
}
    /**
     * get 座位状态 IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN
     * @return
     */
    public  String getState(){
        return state;
}

    /**
     * set 座位状态 IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN
     */
    public Seat setState(String state){
        this.state=state;
        return this;
}
    /**
     * get 是否在线
     * @return
     */
    public  boolean  isOnline(){
        return online;
}

    /**
     * set 是否在线
     */
    public Seat setOnline(boolean online){
        this.online=online;
        return this;
}
    /**
     * get 本轮下的筹码
     * @return
     */
    public  double getBetChip(){
        return betChip;
}

    /**
     * set 本轮下的筹码
     */
    public Seat setBetChip(double betChip){
        this.betChip=betChip;
        return this;
}
    /**
     * get 本阶段的筹码
     * @return
     */
    public  double getPhaseBetChip(){
        return phaseBetChip;
}

    /**
     * set 本阶段的筹码
     */
    public Seat setPhaseBetChip(double phaseBetChip){
        this.phaseBetChip=phaseBetChip;
        return this;
}
    /**
     * get 轮到该座位的时间
     * @return
     */
    public  double getTurnTime(){
        return turnTime;
}

    /**
     * set 轮到该座位的时间
     */
    public Seat setTurnTime(double turnTime){
        this.turnTime=turnTime;
        return this;
}
    /**
     * get 座位上的玩家
     * @return
     */
    public  Player getPlayer(){
        return player;
}

    /**
     * set 座位上的玩家
     */
    public Seat setPlayer(Player player){
        this.player=player;
        return this;
}
    public List<Integer> getHandCards(){
        return handCards;
    }
    public Seat setHandCards (List<Integer> handCards){
        this.handCards=handCards;
        return this;
    }

    public  TexasCards getTexasCards(){
        return texasCards;
}

    public Seat setTexasCards(TexasCards texasCards){
        this.texasCards=texasCards;
        return this;
}

    @Override
    public String toString() {
        return "Seat{"
                +"index=" + index
                +",state=" + state
                +",online=" + online
                +",betChip=" + betChip
                +",phaseBetChip=" + phaseBetChip
                +",turnTime=" + turnTime
                +",player=" + player
                +",handCards=" + handCards
                +",texasCards=" + texasCards
                + "}";
   }

    //12 + 3 = 15 个空格
    private String nextIndent ="               ";
    //最长字段长度 12
    private int filedPad = 12;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("Seat").append("{");
        //座位编号(下标为零开始)
        sb.append("\n");
        sb.append(indent).append(rightPad("index", filedPad)).append(" = ").append(index);
        //座位状态 IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN
        sb.append("\n");
        sb.append(indent).append(rightPad("state", filedPad)).append(" = ").append(state);
        //是否在线
        sb.append("\n");
        sb.append(indent).append(rightPad("online", filedPad)).append(" = ").append(online);
        //本轮下的筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("betChip", filedPad)).append(" = ").append(betChip);
        //本阶段的筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("phaseBetChip", filedPad)).append(" = ").append(phaseBetChip);
        //轮到该座位的时间
        sb.append("\n");
        sb.append(indent).append(rightPad("turnTime", filedPad)).append(" = ").append(turnTime);
        //座位上的玩家
        sb.append("\n");
        sb.append(indent).append(rightPad("player", filedPad)).append(" = ");
        if(player!=null){
            sb.append(player.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        //手牌
        sb.append("\n");
        sb.append(indent).append(rightPad("handCards", filedPad)).append(" = ");
        int handCardsSize = handCards.size();
        if (handCardsSize > 0) {
            sb.append("[");
            for (int i = 0; i<handCardsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(handCards.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        //牌型
        sb.append("\n");
        sb.append(indent).append(rightPad("texasCards", filedPad)).append(" = ");
        if(texasCards!=null){
            sb.append(texasCards.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}