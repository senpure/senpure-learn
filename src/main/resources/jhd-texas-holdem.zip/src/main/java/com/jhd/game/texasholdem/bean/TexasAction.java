package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

/**
* 玩家操作选项
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class TexasAction extends  Bean {
    //玩家可操作选项  CALL,FOLD, CHECK,RAISE,ALLIN
    private String type;
    //筹码数
    private double chip;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //玩家可操作选项  CALL,FOLD, CHECK,RAISE,ALLIN
        writeStr(buf,type);
        //筹码数
        writeDouble(buf,chip);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //玩家可操作选项  CALL,FOLD, CHECK,RAISE,ALLIN
        this.type= readStr(buf);
        //筹码数
        this.chip = readDouble(buf);
    }

    /**
     * get 玩家可操作选项  CALL,FOLD, CHECK,RAISE,ALLIN
     * @return
     */
    public  String getType(){
        return type;
}

    /**
     * set 玩家可操作选项  CALL,FOLD, CHECK,RAISE,ALLIN
     */
    public TexasAction setType(String type){
        this.type=type;
        return this;
}
    /**
     * get 筹码数
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 筹码数
     */
    public TexasAction setChip(double chip){
        this.chip=chip;
        return this;
}

    @Override
    public String toString() {
        return "TexasAction{"
                +"type=" + type
                +",chip=" + chip
                + "}";
   }

    //最长字段长度 4
    private int filedPad = 4;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("TexasAction").append("{");
        //玩家可操作选项  CALL,FOLD, CHECK,RAISE,ALLIN
        sb.append("\n");
        sb.append(indent).append(rightPad("type", filedPad)).append(" = ").append(type);
        //筹码数
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}