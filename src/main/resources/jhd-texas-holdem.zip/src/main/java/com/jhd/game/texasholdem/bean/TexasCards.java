package com.jhd.game.texasholdem.bean;

import com.senpure.io.message.Bean;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
* 德州扑克的牌型
* 
* @author senpure-generator
* @version 2017-9-28 16:08:07
*/
public class TexasCards extends  Bean {
    //牌型 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH
    private String type;
    //牌
    private List<Integer> cards=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //牌型 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH
        writeStr(buf,type);
        //牌
        int cardsSize=cards.size();
        writeShort(buf,cardsSize);
        for(int i=0;i< cardsSize;i++){
            writeInt(buf,cards.get(i));
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //牌型 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH
        this.type= readStr(buf);
        //牌
        int cardsSize=readShort(buf);
        for(int i=0;i<cardsSize;i++){
            this.cards.add(readInt(buf));
         }
    }

    /**
     * get 牌型 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH
     * @return
     */
    public  String getType(){
        return type;
}

    /**
     * set 牌型 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH
     */
    public TexasCards setType(String type){
        this.type=type;
        return this;
}
    public List<Integer> getCards(){
        return cards;
    }
    public TexasCards setCards (List<Integer> cards){
        this.cards=cards;
        return this;
    }


    @Override
    public String toString() {
        return "TexasCards{"
                +"type=" + type
                +",cards=" + cards
                + "}";
   }

    //5 + 3 = 8 个空格
    private String nextIndent ="        ";
    //最长字段长度 5
    private int filedPad = 5;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("TexasCards").append("{");
        //牌型 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH
        sb.append("\n");
        sb.append(indent).append(rightPad("type", filedPad)).append(" = ").append(type);
        //牌
        sb.append("\n");
        sb.append(indent).append(rightPad("cards", filedPad)).append(" = ");
        int cardsSize = cards.size();
        if (cardsSize > 0) {
            sb.append("[");
            for (int i = 0; i<cardsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(cards.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}