package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.RoomManager;
import com.jhd.game.texasholdem.message.CSAIRoomConnectionMessage;
import com.jhd.game.texasholdem.message.CSCreateRoomMessage;
import com.senpure.io.message.AbstractMessageHandler;
import io.netty.channel.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * ai房间连接处理器
 * 
 * @author senpure-generator
 * @version 2017-9-13 15:11:09
 */
@Component
public class CSAIRoomConnectionMessageHandler extends AbstractMessageHandler<CSAIRoomConnectionMessage> {

    @Autowired
    private CSCreateRoomMessageHandler createRoomMessageHandler;
    @Override
    public void execute(Channel channel, CSAIRoomConnectionMessage message) {

        int roomId=message.getRoomId();
      RoomLogic roomLogic= RoomManager.getRoom(roomId);


        if (roomLogic == null) {

            CSCreateRoomMessage createRoomMessage = new CSCreateRoomMessage();
            createRoomMessage.setAnte(100);
            createRoomMessage.setBigBlind(500);
            createRoomMessage.setChip(4000);
            createRoomMessage.setMaxChip(40000);
           // createRoomMessageHandler.execute(channel, createRoomMessage, playerId);
        }
       // Convert.

    }

    @Override
    public int handlerId() {
    return 200100;
    }

    @Override
    public CSAIRoomConnectionMessage getEmptyMessage() {
    return new CSAIRoomConnectionMessage();
    }

    }