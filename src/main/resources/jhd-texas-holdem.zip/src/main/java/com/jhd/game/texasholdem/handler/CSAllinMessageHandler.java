package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.message.CSAllinMessage;
import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求Allin处理器
 * 
 * @author senpure-generator
 * @version 2017-8-29 10:37:52
 */
@Component
public class CSAllinMessageHandler extends SeatHandler<CSAllinMessage> {

    @Override
    public void execute(Channel channel, CSAllinMessage message,int playerId,RoomLogic room,Seat seat) {
        //auto Generator
        room.playerAllin(message,seat);

    }

    @Override
    public int handlerId() {
    return 100115;
    }

    @Override
    public CSAllinMessage getEmptyMessage() {
    return new CSAllinMessage();
    }

    }