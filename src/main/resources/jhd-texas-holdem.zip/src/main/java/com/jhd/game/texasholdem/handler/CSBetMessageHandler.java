package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.message.CSBetMessage;
import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求下注处理器
 * 
 * @author senpure-generator
 * @version 2017-8-29 10:37:52
 */
@Component
public class CSBetMessageHandler extends SeatHandler<CSBetMessage> {

    @Override
    public void execute(Channel channel, CSBetMessage message,int playerId,RoomLogic room,Seat seat) {
        //auto Generator
        room.playerBet(message,seat);

    }

    @Override
    public int handlerId() {
    return 100109;
    }

    @Override
    public CSBetMessage getEmptyMessage() {
    return new CSBetMessage();
    }

    }