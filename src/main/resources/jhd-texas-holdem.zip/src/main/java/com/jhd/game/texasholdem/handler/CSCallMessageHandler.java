package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import com.jhd.game.texasholdem.message.CSCallMessage;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求跟注处理器
 *
 * @author senpure-generator
 * @version 2017-9-18 18:15:53
 */
@Component
public class CSCallMessageHandler extends SeatHandler<CSCallMessage> {


    @Override
    public int handlerId() {
        return 100123;
    }

    @Override
    public CSCallMessage getEmptyMessage() {
        return new CSCallMessage();
    }

    @Override
    public void execute(Channel channel, CSCallMessage message, int playerId, RoomLogic room, Seat seat) {

        room.playerCall(message, seat);
    }
}