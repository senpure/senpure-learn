package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.message.CSCheckMessage;
import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求过处理器
 * 
 * @author senpure-generator
 * @version 2017-8-29 10:37:52
 */
@Component
public class CSCheckMessageHandler extends SeatHandler<CSCheckMessage> {

    @Override
    public void execute(Channel channel, CSCheckMessage message,int playerId,RoomLogic room,Seat seat) {
        //auto Generator
        room.playerCheck(message,seat);

    }

    @Override
    public int handlerId() {
    return 100111;
    }

    @Override
    public CSCheckMessage getEmptyMessage() {
    return new CSCheckMessage();
    }

    }