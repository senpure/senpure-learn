package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.Config;
import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.RoomManager;
import com.jhd.game.texasholdem.message.CSCreateRoomMessage;
import com.jhd.game.texasholdem.message.CSEntryRoomMessage;
import com.jhd.game.texasholdem.service.DataService;
import com.senpure.base.spring.Spring;
import com.senpure.base.util.DateFormatUtil;
import com.senpure.base.util.StringUtil;
import com.senpure.io.ChannelAttributeUtil;
import io.netty.channel.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 请求创建房间处理器
 *
 * @author senpure-generator
 * @version 2017-8-28 14:29:24
 */
@Component
public class CSCreateRoomMessageHandler extends LoginHandler<CSCreateRoomMessage> {


    @Autowired
    private DataService dataService;

    @Override

    public void execute(Channel channel, CSCreateRoomMessage message, int playerId) {

        Integer entryedRoomId = ChannelAttributeUtil.get(channel, RoomHandler.roomIdKey);
        if (entryedRoomId != null) {

            logger.error("{} 在另一个房间不能创建房间 {}",playerId,entryedRoomId);
            return;
        }
        int roomId = RoomManager.getRoomId();
        Config config = new Config();
        config.name = StringUtil.isExist(message.getName()) ? message.getName() : "房间[" + roomId + "]";
        config.roomId = roomId;
        config.playerOutTime = 10000;
        config.seatNum = 7;
        config.leastPlayerNum=2;
        config.nextRoundInterval=8000;
        config.chip=message.getChip();
        config.maxChip=message.getMaxChip();
        config.bigBlindChip = message.getBigBlind();
        config.smallBindChip = config.bigBlindChip /2;
        config.ante = message.getAnte() > config.smallBindChip ? config.smallBindChip : message.getAnte();

        config.createPlayer = dataService.findPlayer(playerId);
        Date now = new Date();
        config.createTime = now.getTime();
        config.createTimeStr = DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2S).format(now);
        RoomLogic room = Spring.getBean(RoomLogic.class);
        room.init(config);
        RoomManager.addRoom(room);
            CSEntryRoomMessage entryRoomMessage = new CSEntryRoomMessage();
            entryRoomMessage.setSit(true);
            entryRoomMessage.setRoomId(room.getConfig().roomId);
            room.playerEntryRoom(channel, entryRoomMessage, dataService.findPlayer(playerId));



    }


    @Override
    public int handlerId() {
        return 100103;
    }

    @Override
    public CSCreateRoomMessage getEmptyMessage() {
        return new CSCreateRoomMessage();
    }


}