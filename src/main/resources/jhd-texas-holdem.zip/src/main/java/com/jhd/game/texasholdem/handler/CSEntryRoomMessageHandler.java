package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.RoomManager;
import com.jhd.game.texasholdem.message.CSEntryRoomMessage;
import com.jhd.game.texasholdem.result.Result;
import com.jhd.game.texasholdem.service.DataService;
import com.jhd.game.texasholdem.util.ErrorMessageUtil;
import com.senpure.io.ChannelAttributeUtil;
import io.netty.channel.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 请求进入房间处理器
 *
 * @author senpure-generator
 * @version 2017-8-28 14:29:24
 */
@Component
public class CSEntryRoomMessageHandler extends LoginHandler<CSEntryRoomMessage> {

    @Autowired
    private DataService dataService;

    @Override
    public void execute(Channel channel, CSEntryRoomMessage message, int playerId) {
        int roomId = message.getRoomId();
        Integer entryedRoomId = ChannelAttributeUtil.get(channel, RoomHandler.roomIdKey);

        if (entryedRoomId != null) {
            if (entryedRoomId.intValue() != roomId) {

                logger.error("{} 已经在房间 {} ，不能进入房间 {}", playerId, entryedRoomId, roomId);
                return;
            }
            else {
                logger.error("{} 重复进入房间{}", playerId,  roomId);
            }

        }
        RoomLogic roomLogic = RoomManager.getRoom(roomId);
        if (roomLogic != null) {
            roomLogic.playerEntryRoom(channel, message, dataService.findPlayer(playerId));
        } else {

            ErrorMessageUtil.pushMessage(playerId, Result.ROOM_NOT_EXIST);

        }

    }

    @Override
    public int handlerId() {
        return 100105;
    }

    @Override
    public CSEntryRoomMessage getEmptyMessage() {
        return new CSEntryRoomMessage();
    }

}