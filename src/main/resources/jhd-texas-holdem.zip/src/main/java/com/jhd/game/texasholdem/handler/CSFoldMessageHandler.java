package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.message.CSFoldMessage;
import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求弃牌处理器
 * 
 * @author senpure-generator
 * @version 2017-8-29 10:37:52
 */
@Component
public class CSFoldMessageHandler extends SeatHandler<CSFoldMessage> {

    @Override
    public void execute(Channel channel, CSFoldMessage message,int playerId,RoomLogic room,Seat seat) {
        //auto Generator
        room.playerFold(message,seat);

    }

    @Override
    public int handlerId() {
    return 100113;
    }

    @Override
    public CSFoldMessage getEmptyMessage() {
    return new CSFoldMessage();
    }

    }