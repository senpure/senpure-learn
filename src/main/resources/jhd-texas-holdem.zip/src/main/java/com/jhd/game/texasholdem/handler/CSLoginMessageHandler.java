package com.jhd.game.texasholdem.handler;


import com.jhd.game.texasholdem.bean.Player;
import com.jhd.game.texasholdem.message.CSLoginMessage;
import com.jhd.game.texasholdem.message.SCLoginMessage;
import com.jhd.game.texasholdem.service.DataService;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.jhd.game.texasholdem.util.ChannelUtil;
import com.jhd.store.struct.LoginArgs;
import com.senpure.base.util.RandomUtil;
import com.senpure.io.ChannelAttributeUtil;
import com.senpure.io.OffLineHandler;
import com.senpure.io.OffLineListener;
import com.senpure.io.message.AbstractMessageHandler;
import io.netty.channel.Channel;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

/**
 * 请求登录处理器
 *
 * @author senpure-generator
 * @version 2017-8-22 14:17:28
 */
@Component
public class CSLoginMessageHandler extends AbstractMessageHandler<CSLoginMessage> implements OffLineListener {
    @Autowired
    private DataService dataService;
    private static Map<Integer, Player> players = new HashMap<>();
    //多个地方登陆
    private static Map<Integer, Player> mulitPlayers = new HashMap<>();

    private static ChannelGroup loginChannel = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    static {
        ChannelUtil.setChannelGroup(ChannelUtil.LOGIN, loginChannel);
    }


    @Override
    public void execute(Channel channel, CSLoginMessage message) {
        //TODO 请在这里写下你的代码
        Player player = new Player();
        player.setId(10086);
        player.setHead("1");
        player.setNick("刀锋战士");


        if (dataService != null) {
            LoginArgs args = new LoginArgs();
            args.setToken(message.getToken());

            DeskPlayer deskPlayer = dataService.loginByToken(message.getToken());

            if (deskPlayer == null) {
                //todo 通知客户端token错误
                deskPlayer = new DeskPlayer();

                deskPlayer.setId(RandomUtil.random(600000, 999999));
                deskPlayer.setChip(RandomUtil.random(500000, 20000000));
                deskPlayer.setNick("玩家[" + deskPlayer.getId() + "]");
                dataService.cache(deskPlayer);
                //return;
            }
            Integer playerId = deskPlayer.getId();
            Channel oldChannel = ChannelUtil.getChannel(playerId);
            InetSocketAddress insocket = (InetSocketAddress) channel
                    .remoteAddress();
            if (oldChannel != null && !oldChannel.equals(channel)) {
                logger.warn("{} 被挤下线,new channel  {} ", oldChannel, channel);
                //todo 下线通知
                mulitPlayers.put(playerId, player);
                oldChannel.close();

            }
            Integer lastPlayerId = ChannelAttributeUtil.getPlayerId(channel);
            if (lastPlayerId != null && lastPlayerId.longValue() != playerId.longValue()) {
                logger.info("没有断开连接，切换账号，模拟掉线完成处理" + lastPlayerId + " >> " + playerId);
                try {
                    ChannelAttributeUtil.getOfflineHandler(channel).offLineExecute(channel);
                } catch (Exception e) {
                    logger.error("执行掉线逻辑出错", e);
                }
            }

            if (lastPlayerId != null) {
                logger.warn("{}重复登录 ", lastPlayerId);
                //重复登录
            } else {
                ChannelAttributeUtil.setPlayerId(channel, playerId);
                ChannelAttributeUtil.setPlayerName(channel, deskPlayer.getNick());
                ChannelUtil.addLoginCahnnel(channel);
                ChannelUtil.setChannel(playerId, channel);
                OffLineHandler.regChannelOffLineListener(channel, this);
            }
            SCLoginMessage scLoginMessage = new SCLoginMessage();
            player = deskPlayer;
            scLoginMessage.setPlayer(player);
            channel.writeAndFlush(scLoginMessage);
        } else {
            SCLoginMessage scLoginMessage = new SCLoginMessage();
            scLoginMessage.setPlayer(player);
            channel.writeAndFlush(scLoginMessage);
        }

    }

    @Override
    public int handlerId() {
        return 100101;
    }

    @Override
    public CSLoginMessage getEmptyMessage() {
        return new CSLoginMessage();
    }

    @Override
    public void executeOffLine(Channel channel) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(channel);
        logger.debug("{}断开连接",ChannelAttributeUtil.getChannelLogStr(channel));
        if (playerId != null) {
            Player mplayer = mulitPlayers.remove(playerId);
            if (mplayer == null) {
                ChannelUtil.removeChannel(playerId);
                players.remove(playerId);
            }


        }
    }

    @Override
    public String getOffLineListenerName() {
        return "关联Channel掉线监听程序";
    }
}