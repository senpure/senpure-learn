package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.message.CSLuaLongMessage;
import com.jhd.game.texasholdem.message.SCLuaLongMessage;
import com.senpure.io.message.AbstractMessageHandler;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * luaLong型数据的支持处理器
 * 
 * @author senpure-generator
 * @version 2017-9-14 16:56:24
 */
@Component
public class CSLuaLongMessageHandler extends AbstractMessageHandler<CSLuaLongMessage> {

    @Override
    public void execute(Channel channel, CSLuaLongMessage message) {

        SCLuaLongMessage luaLongMessage=new SCLuaLongMessage();
        luaLongMessage.setChip(message.getChip()+1);
        luaLongMessage.setNum(-message.getNum()+1);
        luaLongMessage.setTime(System.currentTimeMillis());
        channel.writeAndFlush(luaLongMessage);

    }

    @Override
    public int handlerId() {
    return 100131;
    }

    @Override
    public CSLuaLongMessage getEmptyMessage() {
    return new CSLuaLongMessage();
    }

    }