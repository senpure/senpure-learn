package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.RoomManager;
import com.jhd.game.texasholdem.message.CSCreateRoomMessage;
import com.jhd.game.texasholdem.message.CSEntryRoomMessage;
import com.jhd.game.texasholdem.message.CSQuickGameMessage;
import com.jhd.game.texasholdem.service.DataService;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.senpure.io.ChannelAttributeUtil;
import io.netty.channel.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 快速游戏处理器
 *
 * @author senpure-generator
 * @version 2017-9-6 13:23:34
 */
@Component
public class CSQuickGameMessageHandler extends LoginHandler<CSQuickGameMessage> {

    @Autowired
    private DataService dataService;
    @Autowired
    private CSCreateRoomMessageHandler createRoomMessageHandler;

    @Override
    public synchronized void execute(Channel channel, CSQuickGameMessage message, int playerId) {

        DeskPlayer deskPlayer = dataService.findPlayer(playerId);

        Integer entryedRoomId = ChannelAttributeUtil.get(channel, RoomHandler.roomIdKey);
        RoomLogic roomLogic=null;
        if (entryedRoomId != null) {
            roomLogic = RoomManager.getRoom(entryedRoomId);
        }
        if (roomLogic == null) {
            roomLogic  = RoomManager.quickRoom(deskPlayer);
        }

       // RoomLogic   roomLogic=RoomManager.getRoom(111111);
        if (roomLogic == null) {
            logger.debug("创建并进入房间 ");
            CSCreateRoomMessage createRoomMessage = new CSCreateRoomMessage();
            createRoomMessage.setAnte(100);
            createRoomMessage.setBigBlind(500);
            createRoomMessage.setChip(4000);
            createRoomMessage.setMaxChip(40000);
            createRoomMessageHandler.execute(channel, createRoomMessage, playerId);
        } else {
            logger.debug("找到房间 roomLogic {}", roomLogic.getConfig());
            CSEntryRoomMessage entryRoomMessage = new CSEntryRoomMessage();
            entryRoomMessage.setSit(true);
            roomLogic.playerEntryRoom(channel, entryRoomMessage, deskPlayer);
        }

    }

    @Override
    public int handlerId() {
        return 100117;
    }

    @Override
    public CSQuickGameMessage getEmptyMessage() {
        return new CSQuickGameMessage();
    }

}