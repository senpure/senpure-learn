package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import com.jhd.game.texasholdem.message.CSReadyGameMessage;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 准备/取消处理器
 * 
 * @author senpure-generator
 * @version 2017-9-7 16:27:39
 */
@Component
public class CSReadyGameMessageHandler extends SeatHandler<CSReadyGameMessage> {


    @Override
    public int handlerId() {
    return 100119;
    }

    @Override
    public CSReadyGameMessage getEmptyMessage() {
    return new CSReadyGameMessage();
    }

    @Override
    public void execute(Channel channel, CSReadyGameMessage message, int playerId, RoomLogic room, Seat seat) {


        room.playerReadyGame(message,seat);
    }
}