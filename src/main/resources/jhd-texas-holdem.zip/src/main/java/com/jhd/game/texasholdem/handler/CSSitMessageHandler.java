package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.message.CSSitMessage;
import com.jhd.game.texasholdem.service.DataService;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import io.netty.channel.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 请求坐下处理器
 * 
 * @author senpure-generator
 * @version 2017-8-29 10:17:31
 */
@Component
public class CSSitMessageHandler extends RoomHandler<CSSitMessage> {

    @Autowired
    private DataService dataService;
    @Override
    public void execute(Channel channel, CSSitMessage message,int playerId,RoomLogic room) {
        //TODO 请在这里写下你的代码

        DeskPlayer deskPlayer = dataService.findPlayer(playerId);
        room.playerSit(message,deskPlayer);
    }

    @Override
    public int handlerId() {
    return 100107;
    }

    @Override
    public CSSitMessage getEmptyMessage() {
    return new CSSitMessage();
    }

    }