package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.message.CSStandMessage;
import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 请求站起处理器
 * 
 * @author senpure-generator
 * @version 2017-9-11 10:29:11
 */
@Component
public class CSStandMessageHandler extends SeatHandler<CSStandMessage> {

    @Override
    public void execute(Channel channel, CSStandMessage message,int playerId,RoomLogic room,Seat seat) {
        //auto Generator
        room.playerStand(message,seat);

    }

    @Override
    public int handlerId() {
    return 100121;
    }

    @Override
    public CSStandMessage getEmptyMessage() {
    return new CSStandMessage();
    }

    }