package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.result.Result;
import com.jhd.game.texasholdem.util.ErrorMessageUtil;
import com.senpure.io.ChannelAttributeUtil;
import com.senpure.io.message.AbstractMessageHandler;
import com.senpure.io.message.Message;
import io.netty.channel.Channel;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public abstract class LoginHandler<T extends Message> extends AbstractMessageHandler<T> {


    @Override
    public void execute(Channel channel, T message) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(channel);
        if (playerId == null) {
            logger.error("玩家 未登陆 ");
            ErrorMessageUtil.pushMessage(channel, Result.ACCOUNT_NOT_LOGIN);
            return;
        }
        execute(channel, message, playerId);
    }

    public abstract void execute(Channel channel, T message, int playerId);
}
