package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.RoomManager;
import com.jhd.game.texasholdem.result.Result;
import com.jhd.game.texasholdem.util.ErrorMessageUtil;
import com.senpure.io.message.Message;
import io.netty.channel.Channel;
import io.netty.util.AttributeKey;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public abstract class RoomHandler<T extends Message> extends LoginHandler<T> {

    public static AttributeKey<Integer> roomIdKey=AttributeKey.valueOf("roomId");
    @Override
    public void execute(Channel channel, T message, int playerId) {
        Integer roomId = channel.attr(roomIdKey).get();
        if (roomId == null) {
            logger.error("玩家{} 未进入房间 ", playerId);
            ErrorMessageUtil.pushMessage(channel, Result.PLAYER_HAS_NOT_ROOM);
            return;
        }
        RoomLogic room = RoomManager.getRoom(roomId.intValue());
        if (room == null) {
            logger.warn("房间{}不存在 ", roomId);
            ErrorMessageUtil.pushMessage(channel, Result.ROOM_NOT_EXIST);
            return;
        }
        execute(channel, message, playerId, room);
    }

    public abstract void execute(Channel channel, T message, int playerId, RoomLogic room);
}
