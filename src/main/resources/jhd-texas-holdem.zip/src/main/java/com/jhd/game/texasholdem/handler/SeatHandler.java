package com.jhd.game.texasholdem.handler;

import com.jhd.game.texasholdem.logic.RoomLogic;
import com.jhd.game.texasholdem.logic.Seat;
import com.jhd.game.texasholdem.result.Result;
import com.jhd.game.texasholdem.util.ErrorMessageUtil;
import com.senpure.io.message.Message;
import io.netty.channel.Channel;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public abstract class SeatHandler<T extends Message> extends RoomHandler<T> {
    @Override
    public void execute(Channel channel, T message, int playerId, RoomLogic room) {

        Seat seat = null;
        for (Seat s : room.getSeats()) {
            if (s.player != null && s.player.getId() == playerId) {
                seat = s;
            }
        }
        if (seat == null) {
            logger.error("玩家{} 没有座位 ", playerId);
            ErrorMessageUtil.pushMessage(channel, Result.PLAYER_HAS_NOT_SEAT);
            return;
        }
        execute(channel, message,playerId, room, seat);
    }

    public abstract void execute(Channel channel, T message, int playerId, RoomLogic room, Seat seat);
}
