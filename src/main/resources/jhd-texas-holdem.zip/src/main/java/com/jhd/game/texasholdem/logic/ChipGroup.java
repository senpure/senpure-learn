package com.jhd.game.texasholdem.logic;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/8/31.
 */
public class ChipGroup {
    public double chip;

    public List<Seat> seats = new ArrayList<>();
}
