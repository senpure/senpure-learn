package com.jhd.game.texasholdem.logic;

import com.jhd.game.texasholdem.struct.DeskPlayer;

/**
 * Created by 罗中正 on 2017/8/21.
 */
public class Config {

    //第一次开始的最少玩家
    public int leastPlayerNum;
    public int roomId;
    public String name;
    //超时弃牌时间
    public double playerOutTime;
    public int seatNum;
    //前注
    public double ante;
    public double bigBlindChip;
    public double smallBindChip;
    //游戏开始后，留给小盲额外的抉择时间
    public long prepFlopExtTime;
    public long flopExtTime;
    public long turnExtTime;
    public long riverExtTime;
    public DeskPlayer createPlayer;
    public double createTime;
    public String createTimeStr;
   public long  nextRoundInterval;
   public double chip;
   public  double maxChip;

    @Override
    public String toString() {
        return "Config{" +
                "roomId=" + roomId +
                ", playerOutTime=" + playerOutTime +
                ", seatNum=" + seatNum +
                ", bigBlindChip=" + bigBlindChip +
                ", smallBindChip=" + smallBindChip +
                ", prepFlopExtTime=" + prepFlopExtTime +
                ", flopExtTime=" + flopExtTime +
                ", turnExtTime=" + turnExtTime +
                ", riverExtTime=" + riverExtTime +
                ", createPlayer=" + createPlayer +
                ", createTime=" + createTime +
                ", createTimeStr='" + createTimeStr + '\'' +
                '}';
    }
}
