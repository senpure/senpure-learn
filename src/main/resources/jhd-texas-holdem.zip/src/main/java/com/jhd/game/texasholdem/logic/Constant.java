package com.jhd.game.texasholdem.logic;

/**
 * Created by 罗中正 on 2017/8/29.
 */
public class Constant {
    public enum ROOM_STATE {
        CLOSING, CLOSED, READYING, PLAYING,CLEARING
        ,
    }

    public enum SEAT_STATE {
        IDLE, WATCH, READY, PLAYING,FOLDED,ALLIN

    }

    public enum STAND_TYPE {
        REQUEST,
        CHIP_LACK,
        CHIP_LIMIT,
        OFF_ONLINE
    }
    public enum GAME_PHASE{
        PERFLOP,FLOP,TURN,
        RIVER
    }
    public  enum  TEXAS_ACTION{
       CALL,FOLD, CHECK,RAISE,ALLIN
    }
    public enum  BET_TYPE{
        CHECK,CALL,BET,RAISE,ALLIN,FOLD


    }
}
