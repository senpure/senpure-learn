package com.jhd.game.texasholdem.logic;

import com.jhd.game.texasholdem.bean.GameRoom;
import com.jhd.game.texasholdem.bean.TexasCards;
import com.jhd.game.texasholdem.struct.Card;
import com.jhd.game.texasholdem.struct.TexasPoker5Cards;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Created by 罗中正 on 2017/9/6.
 */
public class Convert {

    private static Logger logger = LoggerFactory.getLogger(Convert.class);
    public static final int SEE_ALL_INDEX = 100;

    public static GameRoom convert(RoomBase room) {

        return convert(room, -1);
    }

    public static GameRoom convert(RoomBase room, int selfIndex) {

        GameRoom gameRoom = new GameRoom();
        gameRoom.setRoomId(room.config.roomId);
        gameRoom.setState(room.getState().toString());
        gameRoom.setBigBlind(room.config.bigBlindChip);
        if (room.currentSeat != null) {
            gameRoom.setCurrentIndex(room.currentSeat.index);
        } else {
            gameRoom.setCurrentIndex(-1);
        }
        gameRoom.setBigBlindIndex(room.bigBlindIndex);
        gameRoom.setSmallBlindIndex(room.smallBlindIndex);
        gameRoom.setChipPool(room.chipPool);
        for (ChipGroup chipGroup : room.edgePool) {
            gameRoom.getEdgePool().add(chipGroup.chip);
        }
        for (Card card : room.publicCards) {
            gameRoom.getPublicCards().add(card.getIntValue());
        }
        for (Seat seat : room.seats) {
            gameRoom.getSeats().add(convert(seat, selfIndex));
        }
        if (room.config.createPlayer != null) {
            gameRoom.setCreatePlayerId(room.config.createPlayer.getId());
        }

        gameRoom.setCreateTime(room.config.createTime);
        gameRoom.setPlayedRound(room.playedRound);
        return gameRoom;
    }

    public static com.jhd.game.texasholdem.bean.Seat convert(Seat seat) {
        return convert(seat, -1);
    }

    public static com.jhd.game.texasholdem.bean.Seat convert(Seat seat, int selfIndex) {
        com.jhd.game.texasholdem.bean.Seat msgSeat = new com.jhd.game.texasholdem.bean.Seat();

        //logger.debug("room seat {}",seat);
        msgSeat.setIndex(seat.index);
        msgSeat.setPlayer(seat.player);
        msgSeat.setBetChip(seat.betChip);
        msgSeat.setOnline(seat.online);
        msgSeat.setPhaseBetChip(seat.phaseBetChip);
        msgSeat.setTurnTime(seat.turnTime);
        msgSeat.setState(seat.state.toString());
        if (selfIndex == SEE_ALL_INDEX || seat.index == selfIndex) {
            if (seat.texasPoker5Cards != null) {
                TexasCards texasCards = new TexasCards();
                texasCards.setType(seat.texasPoker5Cards.getType().toString());
                for (Card card : seat.texasPoker5Cards.getCards()) {
                    texasCards.getCards().add(card.getIntValue());
                }
                msgSeat.setTexasCards(texasCards);
            }
            if (seat.handCards.size() > 0) {
                for (Card card : seat.handCards) {
                    msgSeat.getHandCards().add(card.getIntValue());
                }
            }
        } else {
            if (seat.handCards.size() > 0) {
                for (Card card : seat.handCards) {
                    msgSeat.getHandCards().add(0);
                }
            }
        }
        //logger.debug("msg seat {}",msgSeat);
        return msgSeat;
    }

    public static TexasCards convertTexas(Seat seat) {
        if (seat.texasPoker5Cards != null) {
            TexasCards texasCards = new TexasCards();
            texasCards.setType(seat.texasPoker5Cards.getType().toString());
            for (Card card : seat.texasPoker5Cards.getCards()) {
                texasCards.getCards().add(card.getIntValue());
            }
            return texasCards;
        }
        return null;
    }

    public static TexasCards convertTexas(TexasPoker5Cards texasPoker5Cards) {

        TexasCards texasCards = new TexasCards();
        texasCards.setType(texasPoker5Cards.getType().toString());
        for (Card card : texasPoker5Cards.getCards()) {
            texasCards.getCards().add(card.getIntValue());

        }
        return texasCards;
    }

    public static void main(String[] args) {

        Seat seat = new Seat(2);

        convert(seat);
    }
}
