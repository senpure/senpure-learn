package com.jhd.game.texasholdem.logic;

import com.senpure.base.spring.SpringContextClosedEvent;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * Created by 罗中正 on 2017/5/23.
 */
@Service
public class EasyRoomManager extends SpringContextClosedEvent {


    public static Set<Integer> roomIds = new LinkedHashSet<>();

    public static BlockingDeque<Integer> using;

    public static int getRoomId() {
        Integer roomId = using.poll();
        return roomId == null ? 0 : roomId;
    }

    public static void back(int roomId) {
        if (roomIds.contains(roomId)) {
           // using.offerFirst(roomId);
            using.offerLast(roomId);
            //using.offer(roomId);
        }
    }

    @PostConstruct
    public static void easyRoom() {


        //22222
        for (int i = 1; i < 10; i++) {
            StringBuilder sb = new StringBuilder();
            for (int j = 0; j < 6; j++) {
                sb.append(i);
            }
            roomIds.add(Integer.valueOf(sb.toString()));

        }
        roomIds.add(123456);
        roomIds.add(654321);
        //111222
        for (int i = 1; i < 10; i++) {
            for (int j = 1; j < 10; j++) {

                if (i == j || i == j) {
                    continue;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(i).append(i).append(i).append(j).append(j).append(j);
                roomIds.add(Integer.valueOf(sb.toString()));

            }

        }
        //112233
        for (int i = 1; i < 10; i++) {
            for (int j = 1; j < 10; j++) {
                for (int k = 1; k < 10; k++) {
                    if (i == j || j == k || i == j) {
                        continue;
                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append(i).append(i).append(j).append(j);
                    sb.append(k).append(k);
                    roomIds.add(Integer.valueOf(sb.toString()));
                }
            }

        }
        //122222

        for (int i = 1; i < 10; i++) {
            for (int j = 1; j < 10; j++) {

                if (i == j || i == j) {
                    continue;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(i).append(j).append(j).append(j);
                sb.append(j).append(j);
                roomIds.add(Integer.valueOf(sb.toString()));

            }

        }

        using = new LinkedBlockingDeque<>(roomIds.size());
        roomIds.forEach(id ->
                using.offer(id)
        );


    }

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
       // logger.debug("服务器关闭，将房间顺序写入磁盘");


    }

    public static void main(String[] args) {

    }
}
