package com.jhd.game.texasholdem.logic;

import com.senpure.base.AppEvn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.RollingFileAppender;
import org.apache.logging.log4j.core.appender.rolling.CompositeTriggeringPolicy;
import org.apache.logging.log4j.core.appender.rolling.DefaultRolloverStrategy;
import org.apache.logging.log4j.core.appender.rolling.SizeBasedTriggeringPolicy;
import org.apache.logging.log4j.core.appender.rolling.TimeBasedTriggeringPolicy;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.apache.logging.slf4j.Log4jLogger;

import java.io.File;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by 罗中正 on 2017/8/21.
 */
public class LoggerUtil {

    private static ConcurrentHashMap<Integer, LoggerAndAppender> loggers = new java.util.concurrent.ConcurrentHashMap();
    private static String FILE_PATH = "f:/logs/texas/";
    private static  String getLogPath()
    {
       if(AppEvn.isWindowsOS())
       {
           return  FILE_PATH;
       }
       return "/data/logs/texas/";
    }
    public static void releaseLogger(int roomId) {
        LoggerAndAppender loggerAndAppender = loggers.remove(roomId);
        if (loggerAndAppender != null) {

            loggerAndAppender.appender.stop();
            loggerAndAppender.logger = null;
        }
    }

    public static org.slf4j.Logger getLogger(int roomId) {
        LoggerAndAppender loggerAndAppender = loggers.get(roomId);
        if (loggerAndAppender != null) {
            return loggerAndAppender.logger;
        }
        String fileName = new File(getLogPath(), File.separator + roomId + File.separator + "texas.log").getAbsolutePath();
        final LoggerContext ctx = (LoggerContext) LogManager.getContext(true);
        final Configuration config = ctx.getConfiguration();

        DefaultRolloverStrategy strategy = DefaultRolloverStrategy.createStrategy("20", null, null, null, null, false, config);
        TimeBasedTriggeringPolicy timeBasedTriggeringPolicy = TimeBasedTriggeringPolicy
                .createPolicy("24", "true");
        SizeBasedTriggeringPolicy sizeBasedTriggeringPolicy = SizeBasedTriggeringPolicy.createPolicy("51200 KB");
        CompositeTriggeringPolicy compositeTriggeringPolicy = CompositeTriggeringPolicy.createPolicy(timeBasedTriggeringPolicy, sizeBasedTriggeringPolicy);
        RollingFileAppender appender = RollingFileAppender.newBuilder()
                .withAppend(true)
                .withName(roomId + "RollingAppender")
                .withBufferedIo(true)
                //.withBufferSize()

                .withFileName(fileName)
                .withFilePattern(getLogPath()+"/log.%d{yyyy-MM-dd}_%i.log")
                .withPolicy(compositeTriggeringPolicy)
                .withLayout(
                        PatternLayout.newBuilder().withPattern("%d{HH:mm:ss.SSS} [%t] %-5level - %msg%n").build())
                .withStrategy(strategy)
                .build();


        appender.start();
        String loggerName = "game.room." + roomId;
        Logger logger = ctx.getLogger(loggerName);
        Iterator<Appender> iterator = logger.getAppenders().values().iterator();
        while (iterator.hasNext()) {
            Appender ader = iterator.next();
            logger.removeAppender(ader);
        }
        logger.addAppender(appender);
        loggerAndAppender = new LoggerAndAppender();
        loggerAndAppender.logger = new Log4jLogger(logger, loggerName);
        loggerAndAppender.appender = appender;
        loggers.putIfAbsent(roomId, loggerAndAppender);
        return loggers.get(roomId).logger;
    }

    private static class LoggerAndAppender {
        Log4jLogger logger;
        Appender appender;

    }

    public static void main(String[] args) throws InterruptedException {


    }
}
