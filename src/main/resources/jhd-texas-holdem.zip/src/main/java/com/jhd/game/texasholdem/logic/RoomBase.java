package com.jhd.game.texasholdem.logic;

import com.jhd.game.texasholdem.message.*;
import com.jhd.game.texasholdem.service.DataService;
import com.jhd.game.texasholdem.struct.Card;
import com.jhd.game.texasholdem.struct.Cards52;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.jhd.game.texasholdem.util.Cardsable;
import io.netty.channel.Channel;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;

/**
 * Created by 罗中正 on 2017/8/22.
 */
public abstract class RoomBase {
    protected static ScheduledThreadPoolExecutor scheduler = new ScheduledThreadPoolExecutor(Runtime.getRuntime().availableProcessors() * 2);
    protected int bigBlindIndex;
    protected int smallBlindIndex;
   // protected int startIndex;
    protected double phaseMaxBetChip;
    protected boolean phaseHasAllin;

    //下注阶段最后一个人
    protected int endIndex;
    protected boolean endIndexNextPhase;
    protected int currentPlayingCount;
    /**
     * 上局大盲位置
     */
    protected int lastBigBlindIndex;

    /**
     * 玩了几局了
     */
    protected int playedRound;
    /**
     * 筹码主池
     */

    protected double chipPool;
    /**
     * c筹码边池
     */
    protected List<ChipGroup> edgePool;
    protected List<Card> publicCards;
    protected Seat currentSeat;
    protected Logger logger;
    protected Config config;
    protected ChannelGroup roomGroup;
    protected ChannelGroup roomLookerGroup;
    protected RoomMessage roomMessage;
    protected List<Seat> seats;
    //List<List<Seat>> pkSeats;
    protected List<DeskPlayer> lookers;
    protected Cardsable cardsable;

    protected int seatPlayerNum;
    protected Constant.GAME_PHASE phase;
    protected long phaseTime;
    protected int playerNum;
    protected long roundOverTime;
    protected volatile Constant.ROOM_STATE state;

    protected ScheduledFuture<Runnable> playerCheck;


    @Autowired
    protected DataService dataService;

    public abstract void playerEntryRoom(Channel channel, CSEntryRoomMessage message, DeskPlayer player);

    public abstract void playerSit(CSSitMessage message, DeskPlayer player);

    public abstract void playerReadyGame(CSReadyGameMessage message, Seat seat);

    /*
     *  下注
     */
    public abstract void playerBet(CSBetMessage message, Seat seat);
    public abstract void playerCall(CSCallMessage message, Seat seat);

    //过
    public abstract void playerCheck(CSCheckMessage message, Seat seat);

    //弃牌
    public abstract void playerFold(CSFoldMessage message, Seat seat);

    /*
     *allin
     */
    public abstract void playerAllin(CSAllinMessage message, Seat seat);


    public void init(Config config) {
        this.config = config;
        logger = LoggerUtil.getLogger(config.roomId);
        logger.debug("房间初始化 {} ", config);
        publicCards = new ArrayList<>(5);
        state = Constant.ROOM_STATE.READYING;

        roomGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
        roomLookerGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
        roomMessage = new RoomMessage(this);
        seats = new ArrayList<>(config.seatNum);
      //  pkSeats = new ArrayList<>();
        for (int i = 0; i < config.seatNum; i++) {
            Seat seat = new Seat(i);
            seats.add(seat);

        }
        lookers = new ArrayList<>(config.seatNum * 3);

        cardsable = new Cards52();
        lastBigBlindIndex = config.seatNum - 1;
        edgePool = new ArrayList<>();


    }

    protected String getLoggerStr(DeskPlayer player) {
        return StringUtils.rightPad("[" + player.getNick(), 11) + "]" +
                StringUtils.rightPad("[" + player.getId(), 8) + "]";

    }

    protected String getLoggerStr(Seat seat) {
        if (seat.player != null) {
            return "seat[" + seat.index + "]" + getLoggerStr(seat.player);
        }
        return "seat[" + seat.index + "]";
    }


    public Logger getLogger() {
        return logger;
    }

    public Config getConfig() {
        return config;
    }

    public ChannelGroup getRoomGroup() {
        return roomGroup;
    }

    public RoomMessage getRoomMessage() {
        return roomMessage;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public List<DeskPlayer> getLookers() {
        return lookers;
    }

    public Cardsable getCardsable() {
        return cardsable;
    }

    public Constant.ROOM_STATE getState() {
        return state;
    }

    public Seat getCurrentSeat() {
        return currentSeat;
    }


    public int getSeatPlayerNum() {
        return seatPlayerNum;
    }

    public void setSeatPlayerNum(int seatPlayerNum) {
        this.seatPlayerNum = seatPlayerNum;
    }
}
