package com.jhd.game.texasholdem.logic;

import com.jhd.game.texasholdem.handler.RoomHandler;
import com.jhd.game.texasholdem.message.*;
import com.jhd.game.texasholdem.result.Result;
import com.jhd.game.texasholdem.struct.Card;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.jhd.game.texasholdem.util.CardUtil;
import com.jhd.game.texasholdem.util.ChannelUtil;
import com.jhd.game.texasholdem.util.ErrorMessageUtil;
import com.senpure.io.ChannelAttributeUtil;
import com.senpure.io.OffLineHandler;
import com.senpure.io.OffLineListener;
import io.netty.channel.Channel;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 分奖池的设计 每次再进入下一阶段时，将奖池分出来
 * Created by 罗中正 on 2017/8/22.
 */
@Service
@Scope("prototype")
public class RoomLogic extends RoomBase implements OffLineListener {
    @Override
    public void executeOffLine(Channel channel) {
        Integer playerId = ChannelAttributeUtil.getPlayerId(channel);
        if (playerId != null) {
            Seat onSeat = null;
            boolean atOnce = true;
            for (Seat seat : seats) {
                if (seat.player != null && playerId.intValue() == seat.player.getId()) {
                    onSeat = seat;
                    if (seat.state == Constant.SEAT_STATE.ALLIN ||
                            seat.state == Constant.SEAT_STATE.PLAYING) {
                        atOnce = false;
                        seat.online = false;
                        logger.debug("{}正在玩牌，但是掉线了", getLoggerStr(seat));
                        roomMessage.playerOnlienChange(seat);
                    }
                    break;
                }
            }
            //直接离开
            if (onSeat != null && atOnce) {
                DeskPlayer deskPlayer = onSeat.player;
                playerStand(onSeat, Constant.STAND_TYPE.OFF_ONLINE);
                playerExitRoom(deskPlayer);
            }
        }
        roomGroup.remove(channel);
    }

    @Override
    public String getOffLineListenerName() {
        return "texas holdem 游戏房间掉线处理器";
    }

    @Override
    public synchronized void playerEntryRoom(Channel channel, CSEntryRoomMessage message, DeskPlayer player) {
        if (state == Constant.ROOM_STATE.CLOSED || state == Constant.ROOM_STATE.CLOSING) {
            logger.warn("房间状态不对{} ，{}", state, getLoggerStr(player));
        }
        boolean reconnect = false;
        for (Seat seat : seats) {
            if (seat.getPlayer() != null && seat.getPlayer().getId() == player.getId() && !seat.online) {
                seat.online = true;
                reconnect = true;
                roomMessage.playerOnlienChange(seat);
                if (currentSeat != null && currentSeat.player.getId() == player.getId()) {
                    roomMessage.reconnectActionMessage();
                }
                break;
            }
        }
        if (!reconnect) {
            playerNum++;
        }
        logger.debug("{}进入房间 reconnect = {}", getLoggerStr(player), reconnect);
        roomGroup.add(channel);
        ChannelAttributeUtil.set(channel, RoomHandler.roomIdKey, config.roomId);
        OffLineHandler.regChannelOffLineListener(channel, this);
        roomMessage.playerEntryRoomMessage(player);
        if (message.isSit() && !reconnect) {
            CSSitMessage sitMessage = new CSSitMessage();
            sitMessage.setSeatIndex(-1);
            playerSit(sitMessage, player);
        }

    }

    @Override
    public void playerSit(CSSitMessage message, DeskPlayer player) {
        int index = message.getSeatIndex();
        Seat sitSeat = null;
        if (player.getChip() < config.chip) {
            ErrorMessageUtil.pushMessage(player.getId(), Result.PLAYER_CHIP_LACK);
            logger.warn("{}筹码不足 {} 想坐下", getLoggerStr(player), config.bigBlindChip);
            return;
        }
        for (Seat seat : seats) {
            if (seat.index == index) {
                if (seat.player == null) {
                    seat.player = player;
                    sitSeat = seat;
                    break;
                } else if (index != -1) {
                    ErrorMessageUtil.pushMessage(player.getId(), Result.SEAT_HAS_PLAYER);
                    return;
                }
            }
        }
        if (index == -1) {
            for (Seat seat : seats) {
                if (seat.player == null) {
                    seat.player = player;
                    sitSeat = seat;
                    break;
                }
            }
        }
        if (sitSeat != null) {
            seatPlayerNum++;
            sitSeat.online = true;
            sitSeat.state = Constant.SEAT_STATE.READY;
            player.setPlayingChip(config.chip);
            player.setChip(player.getChip() - player.getPlayingChip());
            roomMessage.playerSitMessage(sitSeat);
            CSReadyGameMessage readyGameMessage = new CSReadyGameMessage();
            readyGameMessage.setReady(true);
            playerReadyGame(readyGameMessage, sitSeat);

        }

    }

    public void playerStand(CSStandMessage message, Seat seat) {
        if (seat.state == Constant.SEAT_STATE.PLAYING || seat.state == Constant.SEAT_STATE.ALLIN) {
            logger.error("玩牌阶段不允许站起");
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.CAN_NOT_STAND);
            return;
        }
        DeskPlayer deskPlayer = seat.player;
        seat.player = null;
        seat.state = Constant.SEAT_STATE.IDLE;
        playerStand(seat, Constant.STAND_TYPE.REQUEST);
        roomMessage.playerStandMessage(seat);
        playerExitRoom(deskPlayer);
    }

    public void playerExitRoom(DeskPlayer deskPlayer) {
        Channel channel = ChannelUtil.getChannel(deskPlayer.getId());
        if (channel != null) {
            ChannelAttributeUtil.clear(channel, RoomHandler.roomIdKey);
            roomGroup.remove(channel);
        }
        playerNum--;

    }

    @Override
    public void playerReadyGame(CSReadyGameMessage message, Seat seat) {
        if (state != Constant.ROOM_STATE.READYING) {
            logger.debug("{}非准备时间准备", getLoggerStr(seat.player));
            return;
        }
        seat.state = message.isReady() ? Constant.SEAT_STATE.READY : Constant.SEAT_STATE.WATCH;
        logger.debug("{}准备游戏 {}", getLoggerStr(seat.player), message.isReady());
        roomMessage.playerReadyGameMessage(message.isReady(), seat);
        if (playedRound == 0 && message.isReady() && state == Constant.ROOM_STATE.READYING) {
            int readyCount = 0;
            for (Seat s : seats) {
                if (s.state == Constant.SEAT_STATE.READY) {
                    readyCount++;
                }
            }
            if (readyCount >= config.leastPlayerNum) {
                startGame();
            }
        }

    }

    @Override
    public void playerBet(CSBetMessage message, Seat seat) {
        if (seat.index != currentSeat.index) {
            logger.warn("{}非法时间类下注", getLoggerStr(seat.player));
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
            return;
        }
        double chip = message.getChip();
        if (chip > seat.player.getPlayingChip()) {
            chip = seat.player.getPlayingChip();
        }
        if (chip == seat.player.getPlayingChip()) {
            allin(seat, chip);
        } else if (chip == 0) {
            if (seat.phaseBetChip < phaseMaxBetChip) {
                logger.debug("下注总和{}不足当前筹码 {} 不能过", seat.phaseBetChip, phaseMaxBetChip);
                ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
                return;
            }
            check(seat, false);
        } else {

            double beforePhaseMaxBetChip = phaseMaxBetChip;
            logger.debug("beforePhaseMaxBetChip = {}", beforePhaseMaxBetChip);
            if (seat.phaseBetChip + chip < phaseMaxBetChip) {
                logger.debug("下注总和{}不足当前筹码 {}", seat.phaseBetChip + chip, phaseMaxBetChip);
                ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
                return;
            }
            betChip(seat, chip);
            logger.debug("{}下注 {} 本轮Bet {}  当前阶段bet {} phaseMaxBetChip {}", getLoggerStr(seat), chip, seat.betChip, seat.phaseBetChip, phaseMaxBetChip);

            if (beforePhaseMaxBetChip == 0 || beforePhaseMaxBetChip >= phaseMaxBetChip) {
                roomMessage.playerBetMessage(seat, chip);
            } else {
                endIndex = seat.index;
                roomMessage.playerRaiseMessage(seat, chip);
            }

            nextPlayer(currentSeat.index, true);
        }


    }

    @Override
    public void playerCall(CSCallMessage message, Seat seat) {
        if (seat.index != currentSeat.index) {
            logger.warn("{}非法时间类跟注", getLoggerStr(seat.player));
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
            return;
        }
        double chip = phaseMaxBetChip - seat.phaseBetChip;
        logger.debug("{}跟注 playingChip {} betChip {} phaseMaxBetChip {}", getLoggerStr(seat.player), seat.getPlayer().getPlayingChip(), chip, phaseMaxBetChip);


        if (chip < 0) {
            logger.error("{}跟注筹码为负数", getLoggerStr(seat));
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
            return;
        }
        if (chip < seat.player.getPlayingChip()) {
            betChip(seat, chip);
            roomMessage.playerCallMessage(seat, chip);
            nextPlayer(seat.index, true);
        } else if (chip == seat.player.getPlayingChip()) {
            logger.debug("{} 跟注筹码为自己最大，转为allin", getLoggerStr(seat));
            allin(seat, chip);
        } else if (chip == 0) {
            logger.debug("{} 跟注筹码为零，转为check", getLoggerStr(seat));
            check(seat, false);
        } else {
            logger.warn("{}筹码不足跟注 playingChip {} betChip {} phaseMaxBetChip {}", getLoggerStr(seat.player), seat.getPlayer().getPlayingChip(), chip, phaseMaxBetChip);
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
        }

    }

    private void betChip(Seat seat, double chip) {
        seat.betChip += chip;
        seat.chipPool += chip;
        seat.phaseBetChip += chip;
        seat.player.setPlayingChip(seat.player.getPlayingChip() - chip);
        chipPool += chip;
        //all in 或check
        if (seat.phaseBetChip <= phaseMaxBetChip) {
            endIndexNextPhase = true;
        }
        //加注
        if (seat.phaseBetChip > phaseMaxBetChip) {
            phaseMaxBetChip = seat.phaseBetChip;
            endIndexNextPhase = false;
        }
        phaseMaxBetChip = phaseMaxBetChip > seat.phaseBetChip ? phaseMaxBetChip : seat.phaseBetChip;


    }

    private void allin(Seat seat, double chip) {
        logger.debug("{}allin {} ", getLoggerStr(seat), chip);
        seat.state = Constant.SEAT_STATE.ALLIN;
        betChip(seat, chip);
        currentPlayingCount--;
        roomMessage.playerAllMessage(seat, chip);
        nextPlayer(currentSeat.index, true);
    }

    @Override
    public void playerAllin(CSAllinMessage message, Seat seat) {
        if (seat.index != currentSeat.index) {
            logger.warn("{}非法时间内allin", getLoggerStr(seat.player));
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
            return;
        }
        double chip = seat.player.getPlayingChip();

        allin(seat, chip);
    }


    @Override
    public void playerCheck(CSCheckMessage message, Seat seat) {
        if (seat.index != currentSeat.index) {
            logger.warn("{}非法时间类过", getLoggerStr(seat.player));
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
            return;
        }
        if (seat.betChip < config.smallBindChip || seat.betChip < phaseMaxBetChip) {
            logger.warn("{}非法过请求", getLoggerStr(seat.player));
            ErrorMessageUtil.pushMessage(seat.player.getId(), Result.ERROR_DIM);
            return;
        }

        check(seat, false);

    }

    public void check(Seat seat, boolean system) {

        logger.debug("{}过牌  系统 {}", getLoggerStr(seat), system);
        roomMessage.playerCheckMessage(seat);
        betChip(seat, 0);
        nextPlayer(currentSeat.index, true);
    }

    @Override
    public void playerFold(CSFoldMessage message, Seat seat) {

        fold(seat, false);
    }


    private void nexEndIndex(int currentEndIndex) {
        int last = currentEndIndex == 0 ? config.seatNum - 1 : currentEndIndex - 1;
        Seat seat = seats.get(last);
        if (seat.state == Constant.SEAT_STATE.PLAYING || seat.state == Constant.SEAT_STATE.ALLIN) {

            endIndex = seat.index;
            return;
        }
        nexEndIndex(last);
    }

    //弃牌
    public void fold(Seat seat, boolean system) {

        logger.debug("{}弃牌{} 系统 {}", getLoggerStr(seat), seat.handCards, system);
        seat.state = Constant.SEAT_STATE.FOLDED;
        currentPlayingCount--;

        roomMessage.playerFoldMessage(seat);
        if (currentPlayingCount <= 1) {
            logger.debug("只剩最后一位玩家了");
            pk(true);
            return;
        }

        Constant.GAME_PHASE beforePhase = phase;
        if (seat.index == currentSeat.index) {
            nextPlayer(currentSeat.index, true);
        }
        Constant.GAME_PHASE afterPhase = phase;
        //第一次相等是大盲弃牌
        if (afterPhase == beforePhase && seat.index == endIndex) {
            //  nexEndIndex(endIndex);
        }


    }

    public void nextPhase() {
        long now = System.currentTimeMillis();
        if (now - phaseTime < 2000) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (phase == Constant.GAME_PHASE.PERFLOP) {
            prepNextPhase();
            flop();
        } else if (phase == Constant.GAME_PHASE.FLOP) {
            prepNextPhase();
            turn();
        } else if (phase == Constant.GAME_PHASE.TURN) {
            prepNextPhase();
            river();
        } else if (phase == Constant.GAME_PHASE.RIVER) {
            prepNextPhase();
            pk(false);
        }
    }

    private int nextPlayerCount = 0;
    private int nextPlayerErrorCount = 0;

    public void nextPlayer(int currentSeatIndex, boolean canNextPhase) {
        nextPlayerCount++;
        if (nextPlayerCount > 300) {
            nextPlayerErrorCount++;
            if (nextPlayerErrorCount < 20) {
                logger.error("nextPlayer error ");
                for (Seat s : seats) {

                    logger.debug("{} state {}", getLoggerStr(s), s.state);
                }
            }
        }
        if (currentSeatIndex == endIndex && endIndexNextPhase && canNextPhase) {
            nextPhase();
            nextPlayerCount = 0;
            return;
        }
        int nextSeat = currentSeatIndex == config.seatNum - 1 ? 0 : currentSeatIndex + 1;
        Seat seat = seats.get(nextSeat);
        if (seat.player != null && seat.state == Constant.SEAT_STATE.PLAYING) {
            seat.turnTime = System.currentTimeMillis();
            currentSeat = seat;
            logger.debug("{}轮到操作", getLoggerStr(seat));
            nextPlayerCount = 0;
            roomMessage.nextPlayerMessage();
        } else {
            nextPlayer(nextSeat, true);
        }
    }

    private void playerStand(Seat seat, Constant.STAND_TYPE type) {

        logger.debug("{}站起 原因 {}", getLoggerStr(seat), type);
        seat.player = null;
        seat.state = Constant.SEAT_STATE.IDLE;
        seatPlayerNum--;
        roomMessage.playerStandMessage(seat);
    }

    private void checkPlayerChip(Seat seat) {
        if (seat.player.getPlayingChip() <= 0) {
            playerStand(seat, Constant.STAND_TYPE.CHIP_LACK);
        }
    }

    private void roundOver() {
        playedRound++;
        //pkSeats.clear();
        lastBigBlindIndex = bigBlindIndex;
        for (Seat seat : seats) {
            seat.handCards.clear();
            seat.texasPoker5Cards = null;
            if (seat.player != null) {
                seat.state = Constant.SEAT_STATE.READY;
                // checkPlayerChip(seat);
            } else {
                seat.state = Constant.SEAT_STATE.IDLE;
            }
            seat.betChip = 0;
            seat.phaseBetChip = 0;
            seat.roundWinChip = 0;
            seat.chipPool = 0;
        }

        for (Seat seat : seats) {
            if (seat.player != null) {
                if (seat.player.getPlayingChip() <= 0) {
                    logger.debug("{}可玩筹码为零", getLoggerStr(seat));
                    if (seat.maxChip >= config.maxChip) {
                        logger.debug("{}补充筹码已达上限", getLoggerStr(seat));
                        playerStand(seat, Constant.STAND_TYPE.CHIP_LIMIT);
                    } else {
                        double leftChip = seat.getPlayer().getChip();
                        if (leftChip < config.bigBlindChip) {
                            logger.debug("{}补充筹码不足大盲", getLoggerStr(seat));
                            playerStand(seat, Constant.STAND_TYPE.CHIP_LACK);
                        } else {

                            leftChip = leftChip < config.chip ? leftChip : config.chip;
                            logger.debug("{}补充筹码 {}", getLoggerStr(seat), leftChip);
                            seat.player.setPlayingChip(leftChip);
                            seat.player.setChip(seat.player.getChip() - seat.player.getPlayingChip());
                        }
                    }

                }
            }
        }

        synchronized (this) {
            for (Seat seat : seats) {
                if (!seat.online && seat.player != null) {
                    DeskPlayer deskPlayer = seat.player;
                    playerStand(seat, Constant.STAND_TYPE.OFF_ONLINE);
                    playerExitRoom(deskPlayer);
                }
            }
        }
        state = Constant.ROOM_STATE.READYING;
        roundOverTime = System.currentTimeMillis();
    }

    public int nextBlindIndex(int last) {
        int next = last == config.seatNum - 1 ? 0 : last + 1;
        Seat seat = seats.get(next);
        if (seat.player != null && seat.state == Constant.SEAT_STATE.PLAYING) {
            return seat.getIndex();
        }
        return nextBlindIndex(next);
    }

    private long checkStart = 0;
    private int checkLogCount = 1;

    public void startCheck() {
        if (state == Constant.ROOM_STATE.READYING) {
            int readyCount = 0;
            for (Seat seat : seats) {

                if (seat.state == Constant.SEAT_STATE.READY) {
                    readyCount++;
                }
            }
            if (readyCount > 1) {
                checkLogCount = 0;
                logger.debug("准备人数为 {} 开始游戏", readyCount);
                checkStart = 0;
                startGame();
            } else if (checkStart == 0) {
                checkLogCount = 1;
                checkStart = System.currentTimeMillis();
            } else {
                long time = System.currentTimeMillis() - checkStart;
                if (time > 5000 * checkLogCount++) {
                    checkLogCount++;
                    logger.debug("超过秒没有开始游戏{}", time);
                    if (checkLogCount > 30) {

                        for (Seat seat : seats) {

                            logger.debug("{}  state {}", getLoggerStr(seat), seat.state);
                        }
                        roomGroup.close();
                    }
                }

            }
        }

    }

    public void startGame() {
        logger.debug("游戏开始 round = {}", playedRound + 1);
        state = Constant.ROOM_STATE.PLAYING;
        cardsable.prepareNextTime();
        publicCards.clear();
        phase = Constant.GAME_PHASE.PERFLOP;
        phaseTime = System.currentTimeMillis();
        chipPool = 0;
        currentPlayingCount = 0;
        for (Seat seat : seats) {
            if (seat.state == Constant.SEAT_STATE.READY) {
                seat.state = Constant.SEAT_STATE.PLAYING;

                currentPlayingCount++;
                seat.joinPlayerId = seat.player.getId();
                seat.handCards.clear();
                seat.handCards.addAll(cardsable.dealCards(2));
            }
        }
        bigBlindIndex = nextBlindIndex(lastBigBlindIndex);
        smallBlindIndex = nextBlindIndex(bigBlindIndex);

        logger.debug("大盲位置 = {} ，小盲位置= {} 参与玩家共 {} 位", bigBlindIndex, smallBlindIndex, currentPlayingCount);
        for (Seat seat : seats) {
            if (seat.state == Constant.SEAT_STATE.PLAYING) {
                logger.debug("{}手牌 {}", getLoggerStr(seat), seat.handCards);
            }
        }
        prepFlop();

    }

    public void prepFlop() {
        endIndex = bigBlindIndex;
        //startIndex = smallBlindIndex;

        phaseMaxBetChip = config.bigBlindChip;
        phaseTime = System.currentTimeMillis();

        Seat bigSeat = seats.get(bigBlindIndex);
        double bigChip = config.bigBlindChip;
        if (bigSeat.player.getPlayingChip() <= bigChip) {
            bigChip = bigSeat.player.getPlayingChip();
            bigSeat.state = Constant.SEAT_STATE.ALLIN;
        }
        betChip(bigSeat, bigChip);

        if (bigSeat.state == Constant.SEAT_STATE.ALLIN) {
            roomMessage.playerAllMessage(bigSeat, bigChip);
        } else {
            roomMessage.playerBetMessage(bigSeat, bigChip);
        }

        Seat smallSeat = seats.get(smallBlindIndex);
        double smallChip = config.smallBindChip;
        if (smallSeat.getPlayer().getPlayingChip() <= smallChip) {
            smallChip = smallSeat.getPlayer().getPlayingChip();
            smallSeat.state = Constant.SEAT_STATE.ALLIN;
        }
        betChip(smallSeat, smallChip);
        if (smallSeat.state == Constant.SEAT_STATE.ALLIN) {
            roomMessage.playerAllMessage(smallSeat, smallChip);
        } else {
            roomMessage.playerBetMessage(smallSeat, smallChip);
        }
        if (config.ante > 0) {
            for (Seat seat : seats) {
                if (seat.state == Constant.SEAT_STATE.PLAYING && seat.index != bigBlindIndex && seat.index != smallBlindIndex) {

                    double anteChip = config.ante;
                    if (seat.getPlayer().getPlayingChip() < config.ante) {
                        anteChip = seat.getPlayer().getPlayingChip();
                        seat.state = Constant.SEAT_STATE.ALLIN;
                    }
                    betChip(seat, anteChip);
                    if (seat.state == Constant.SEAT_STATE.ALLIN) {
                        roomMessage.playerAllMessage(seat, anteChip);
                    } else {
                        roomMessage.playerBetMessage(seat, anteChip);
                    }

                }
            }
        }
        roomMessage.startGameMessage();
        logger.debug("检测endIndex = {} ", endIndex);
        if (config.prepFlopExtTime > 0) {

            scheduler.schedule(() -> nextPlayer(endIndex, false), config.prepFlopExtTime, TimeUnit.MILLISECONDS);
        } else {
            nextPlayer(endIndex, false);
        }
    }

    private int nextStartIndexCount = 0;

    private void nextStartIndex(int curentIndex) {
        nextStartIndexCount++;
        if (nextStartIndexCount > 300) {
            logger.error("nextStartIndexCount error");
            for (Seat s : seats) {
                logger.debug("{} state {}", getLoggerStr(s), s.state);
            }
        }
        int next = curentIndex == config.seatNum - 1 ? 0 : curentIndex + 1;

        Seat seat = seats.get(next);
        if (seat.state == Constant.SEAT_STATE.PLAYING) {
            //startIndex = next;
            nextStartIndexCount = 0;
        } else {
            nextStartIndex(next);
        }
    }


    //分筹码池
    private void generateChipPool() {
        double minChip = 0;
        for (Seat seat : seats) {
            if (seat.state == Constant.SEAT_STATE.ALLIN) {
                if (seat.phaseBetChip > 0 && seat.phaseBetChip < phaseMaxBetChip) {
                    double seatLeftChip = seat.phaseBetChip;
                    minChip = minChip > seatLeftChip ? seatLeftChip : minChip;
                }
            }
        }

        if (minChip > 0) {
            ChipGroup chipGroup = new ChipGroup();
            for (Seat seat : seats) {
                if (seat.phaseBetChip > 0) {
                    double entryChip = minChip;
                    if (seat.phaseBetChip < entryChip) {
                        entryChip = seat.phaseBetChip;
                    }
                    seat.phaseBetChip -= entryChip;
                    chipGroup.chip += entryChip;
                    seat.chipPool -= entryChip;
                    chipGroup.seats.add(seat);
                }
            }
            edgePool.add(chipGroup);
            chipPool -= chipGroup.chip;
            generateChipPool();
        }

    }

    private void prepNextPhase() {
        endIndex = bigBlindIndex;
        boolean groupChip = false;
        logger.debug("check groupChip ");
        int betChipCount = 0;
        for (Seat seat : seats) {
            if (seat.state == Constant.SEAT_STATE.ALLIN) {
                logger.debug("{}seat.phaseBetChip = {} seat.state = {}", getLoggerStr(seat), seat.phaseBetChip, seat.state);
                if (seat.phaseBetChip > 0 && seat.phaseBetChip < phaseMaxBetChip) {
                    groupChip = true;
                    break;
                }

            } else if (seat.state == Constant.SEAT_STATE.PLAYING) {
                betChipCount++;
            }
        }
        if (!groupChip && betChipCount == 1) {
            groupChip = true;
        }
        if (groupChip) {
            logger.debug("分筹码到边池");
            generateChipPool();
            roomMessage.partChipMessage();
        }

        if (currentPlayingCount > 1) {
            // nextStartIndex(bigBlindIndex);
            // endIndexNextPhase = false;
        }

        phaseHasAllin = false;
        phaseMaxBetChip = 0;
        for (Seat seat : seats) {
            seat.phaseBetChip = 0;
        }
    }

    private void texasType() {

        for (Seat seat : seats) {
            if (seat.player != null && seat.joinPlayerId == seat.player.getId()) {
                List<Card> cards = new ArrayList<>();
                cards.addAll(seat.handCards);
                cards.addAll(publicCards);
                if (cards.size() > 4) {
                    seat.texasPoker5Cards = CardUtil.texasPoker(cards);
                }
            }
        }
    }

    public void flop() {
        phase = Constant.GAME_PHASE.FLOP;
        phaseTime = System.currentTimeMillis();
        publicCards.addAll(cardsable.dealCards(3));
        logger.debug("flop阶段，公共牌{}", publicCards);
        texasType();
        roomMessage.syncPublicCardsMessage();
        if (config.flopExtTime > 0) {
            scheduler.schedule(() -> nextPlayer(endIndex, false), config.flopExtTime, TimeUnit.MILLISECONDS);
        } else {
            nextPlayer(endIndex, false);
        }
    }

    public void turn() {

        phase = Constant.GAME_PHASE.TURN;
        phaseTime = System.currentTimeMillis();
        publicCards.addAll(cardsable.dealCards(1));
        texasType();
        logger.debug("turn阶段，公共牌{}", publicCards);
        roomMessage.syncPublicCardsMessage();
        if (config.turnExtTime > 0) {
            scheduler.schedule(() -> nextPlayer(endIndex, false), config.turnExtTime, TimeUnit.MILLISECONDS);
        } else {
            nextPlayer(endIndex, false);
        }
    }

    public void river() {
        phase = Constant.GAME_PHASE.RIVER;
        phaseTime = System.currentTimeMillis();
        publicCards.addAll(cardsable.dealCards(1));
        logger.debug("river阶段，公共牌{}", publicCards);
        texasType();

        roomMessage.syncPublicCardsMessage();
        if (config.riverExtTime > 0) {
            scheduler.schedule(() -> nextPlayer(endIndex, false), config.riverExtTime, TimeUnit.MILLISECONDS);
        } else {
            nextPlayer(endIndex, false);
        }

    }

    //fold true 玩家弃牌进入传true//流程走完传false
    public synchronized void pk(boolean fold) {
        state = Constant.ROOM_STATE.CLEARING;
        phaseTime = System.currentTimeMillis();
        List<Seat> pkSeats = new ArrayList<>();
        logger.debug("边池数量{}", edgePool.size());
        int chipIndex = 0;
        for (ChipGroup chipGroup : edgePool) {
            logger.debug("chipGroup {}", chipGroup);
            pkSeats.clear();
            for (Seat seat : chipGroup.seats) {
                seat.pkGroupChip = -chipGroup.chip / chipGroup.seats.size();
                seat.pkGroupWin = false;
                if (seat.state == Constant.SEAT_STATE.PLAYING || seat.state == Constant.SEAT_STATE.ALLIN) {

                    pkSeats.add(seat);
                }
            }
            // this.pkSeats.add(pkSeats);
            logger.debug("pk 数量 {}", pkSeats.size());
            List<Seat> winSeats = pkCards(pkSeats);
            logger.debug("win 数量 {} 分取筹码 {}", winSeats.size(), chipGroup.chip);

            winSeatChip(winSeats, chipGroup.chip);
            // roomMessage.headPkSeatMessage(pkSeats, chipIndex);
            roomMessage.pkSeatMessage(pkSeats, chipIndex);
            chipIndex++;

        }
        pkSeats.clear();
        for (Seat seat : seats) {
            if (seat.state == Constant.SEAT_STATE.PLAYING) {

                pkSeats.add(seat);
            }

        }
        //allin 后 其他弃牌
        if (pkSeats.size() == 0) {
            for (Seat seat : seats) {
                if (seat.state == Constant.SEAT_STATE.ALLIN) {
                    pkSeats.add(seat);
                }

            }
        }
        logger.debug("主池筹码 {} ", chipPool);
        boolean moreChip=false;
        if (pkSeats.size() > 0) {
            double chip=pkSeats.get(0).chipPool;

            for (Seat seat : pkSeats) {
                if(seat.chipPool!=chip)
                {
                    chip=seat.chipPool<chip?seat.chipPool:chip;
                    moreChip=true;
                }
                logger.debug("{}chipPool={}", getLoggerStr(seat), seat.chipPool);
                seat.pkGroupChip = -seat.chipPool;
                seat.pkGroupWin = false;
            }
        }
        if (pkSeats.size() > 1) {
            // this.pkSeats.add(pkSeats);
            logger.debug("pk 数量 {}", pkSeats.size());
            List<Seat> winSeats = pkCards(pkSeats);
            logger.debug("win 数量 {} 分取主池筹码 {}", winSeats.size(), chipPool);
            winSeatChip(winSeats, chipPool);
            //  roomMessage.headPkSeatMessage(pkSeats, -1);
            roomMessage.pkSeatMessage(pkSeats, -1);
        } else if (pkSeats.size() == 1) {
            Seat winSeat = pkSeats.get(0);
            winSeatChip(pkSeats, chipPool);
            if (winSeat.texasPoker5Cards != null) {
                logger.debug("{} 牌型{}", getLoggerStr(winSeat), winSeat.texasPoker5Cards);
            } else {
                logger.debug("{} 牌型{}", getLoggerStr(winSeat), winSeat.handCards);
            }
            if (fold) {
                roomMessage.foldWinMessage(winSeat);
            } else {
                roomMessage.chipOverMessage(winSeat);
            }
            // roomMessage.pkSeatMessage(pkSeats, -1);
            // roomMessage.getChipMessage(pkSeats.get(0), chipPool);

        }
        for (Seat seat : seats) {
            if (seat.joinPlayerId > 0) {

                boolean same = false;
                if (seat.player != null && seat.player.getId() == seat.joinPlayerId) {
                    same = true;
                }
                DeskPlayer player = null;
                if (same) {
                    player = seat.player;
                } else {
                    player = dataService.findPlayer(seat.joinPlayerId);
                }

                if (seat.roundWinChip > 0) {
                    player.setPlayingChip(player.getPlayingChip() + seat.roundWinChip);
                }
                seat.roundWinChip -= seat.betChip;
                if (same) {
                    logger.debug("{} 本轮收益 {}  playingChip {}", getLoggerStr(seat), seat.roundWinChip, seat.player.getPlayingChip());
                } else {
                    logger.debug("{} 本轮收益 {} playingChip {}", getLoggerStr(player), seat.roundWinChip, player.getPlayingChip());
                }
            }

        }
        roomMessage.roundClearMessage();
        roundOver();
    }

    private List<Seat> pkCards(List<Seat> pkSeats) {
        for (Seat seat : pkSeats) {
            if (seat.texasPoker5Cards == null) {
                List<Card> cards = new ArrayList<>();
                cards.addAll(seat.handCards);
                cards.addAll(publicCards);
                if (cards.size() > 4) {
                    seat.texasPoker5Cards = CardUtil.texasPoker(cards);
                }

            }
            logger.debug("{} 牌型{}", getLoggerStr(seat), seat.texasPoker5Cards);

        }
        List<Seat> winSeats = new ArrayList<>();
        int size = pkSeats.size() - 1;
        Seat lastSeat = pkSeats.get(0);
        winSeats.add(lastSeat);
        if (size > 1) {
            for (int i = 1; i < size; i++) {
                Seat turnSeat = pkSeats.get(i);
                int compare = CardUtil.compare(lastSeat.texasPoker5Cards, turnSeat.texasPoker5Cards);
                if (compare == 0) {
                    winSeats.add(turnSeat);
                } else if (compare < 0) {
                    winSeats.clear();
                    winSeats.add(turnSeat);
                }
            }
        }
        return winSeats;
    }

    private void winSeatChip(List<Seat> winSeats, double chip) {
        double winChip = chip / winSeats.size();

        double subChip = 0;
        for (Seat seat : winSeats) {

            if (winSeats.size() == 1) {
                logger.debug("{} before seat.pkGroupChip = {}", getLoggerStr(seat), seat.pkGroupChip);
            }
            seat.roundWinChip += winChip;
            seat.pkGroupWin = true;
            seat.pkGroupChip += winChip;
            if (winSeats.size() == 1) {
                logger.debug("{} after seat.pkGroupChip = {}", getLoggerStr(seat), seat.pkGroupChip);
            }
            subChip += winChip;
        }
        logger.info("筹码池分后剩余的筹码 {}", chip - subChip);
        winSeats.get(0).roundWinChip += (chip - subChip);

    }

    /**
     * 重大到小排序
     */
    protected Comparator<Seat> texasCompartorDesc = (one, two) -> CardUtil.compare(two.texasPoker5Cards, one.texasPoker5Cards);
}
