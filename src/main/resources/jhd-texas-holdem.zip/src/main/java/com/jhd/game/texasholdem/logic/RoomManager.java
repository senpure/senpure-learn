package com.jhd.game.texasholdem.logic;

import com.jhd.game.scheduler.SchedulerSupport;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.senpure.base.util.DateFormatUtil;
import com.senpure.base.util.RandomUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by 罗中正 on 2017/8/28.
 */
@Component
public class RoomManager extends SchedulerSupport {

    private static Map<Integer, RoomLogic> rooms = new ConcurrentHashMap<>();


    public static RoomLogic quickRoom(DeskPlayer deskPlayer) {

        Iterator<Map.Entry<Integer, RoomLogic>> iterator = rooms.entrySet().iterator();
        while (iterator.hasNext()) {
            RoomLogic roomLogic = iterator.next().getValue();
            if (roomLogic.config.seatNum > roomLogic.getSeatPlayerNum() &&
                    (roomLogic.state == Constant.ROOM_STATE.READYING || roomLogic.state == Constant.ROOM_STATE.PLAYING))

                return roomLogic;
        }
        return null;
    }

    public static void addRoom(RoomLogic room) {
        int roomId = room.getConfig().roomId;
        rooms.putIfAbsent(roomId, room);
    }

    public static void removeRoom(int roomId) {
        rooms.remove(roomId);
        EasyRoomManager.back(roomId);
    }

    public static int getRoomId() {
        int roomId = EasyRoomManager.getRoomId();
        if (roomId == 0) {
            roomId = RandomUtil.random(600000, 1000000);
        }
        while (getRoom(roomId) != null) {
            roomId = RandomUtil.random(600000, 1000000);
        }
        return roomId;
    }

    public static RoomLogic getRoom(Integer roomId) {
        return rooms.get(roomId);
    }

    @Scheduled(fixedDelay = 330)
    public void checkPlayerAction() throws InterruptedException {
        int fold = 0;
        int check = 0;
        long startTime = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, RoomLogic>> iterator = rooms.entrySet().iterator();
        while (iterator.hasNext()) {
            RoomLogic roomLogic = iterator.next().getValue();
            if (roomLogic.getState() == Constant.ROOM_STATE.PLAYING) {
                Seat seat = roomLogic.currentSeat;
                if (seat != null && seat.state == Constant.SEAT_STATE.PLAYING && startTime - seat.turnTime >= roomLogic.config.playerOutTime) {
                    logger.debug("startTime {} seat.turnTime {}  差 {} seatIndex  {}",
                            DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).format(new Date(startTime)),
                            DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).format(new Date(seat.turnTime))
                            , startTime - seat.turnTime, seat.index);
                    if (seat.phaseBetChip == roomLogic.phaseMaxBetChip) {
                        roomLogic.check(seat, true);
                        logger.debug("系统帮{}[{}] - >{} 过牌", roomLogic.config.name, roomLogic.config.roomId, roomLogic.getLoggerStr(seat));
                        check++;
                    } else {
                        roomLogic.fold(seat, true);
                        logger.debug("系统帮{}[{}] - >{} 弃牌:{}", roomLogic.config.name, roomLogic.config.roomId, roomLogic.getLoggerStr(seat),seat.handCards);
                        fold++;
                    }

                }
            } else if (roomLogic.getState() == Constant.ROOM_STATE.READYING) {

                if (roomLogic.playedRound > 0 && startTime - roomLogic.roundOverTime > roomLogic.config.nextRoundInterval) {
                    roomLogic.startCheck();
                }
            }
            //异常检测
            if(roomLogic.getState()!= Constant.ROOM_STATE.READYING )
            {}
        }
        long time = System.currentTimeMillis() - startTime;

        if (time > 100) {
            logger.info("检测玩家用过期操作 用时 {} 房间个数 {}", time, rooms.size());
        } else {
            logger.trace("检测玩家用过期操作 用时 {} ", time);
        }
        if (fold > 0) {
            logger.info("系统帮 {} 位玩家弃牌 ", fold);
        }
        if (check > 0) {
            logger.info("系统帮 {} 位玩家过牌 ", check);
        }

    }
}
