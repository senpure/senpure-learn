package com.jhd.game.texasholdem.logic;

import com.jhd.game.texasholdem.bean.*;
import com.jhd.game.texasholdem.message.*;
import com.jhd.game.texasholdem.struct.Card;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.jhd.game.texasholdem.struct.TEXAS_POKER_TYPE;
import com.jhd.game.texasholdem.util.CardUtil;
import com.jhd.game.texasholdem.util.ChannelUtil;
import com.senpure.io.message.Message;
import io.netty.channel.Channel;
import io.netty.channel.group.ChannelMatcher;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public class RoomMessage {
    private RoomBase room;

    private List<PkSeatGroup> pkSeatGroups = new ArrayList<>();

    public RoomMessage(RoomBase room) {
        this.room = room;
    }

    private Channel writeAndFlush(int playerId, Message message) {

        Channel channel = ChannelUtil.getChannel(playerId);
        if (channel != null) {

            channel.writeAndFlush(message);
        }
        return channel;
    }

    private void writeAndFlush(Message message) {
        room.roomGroup.writeAndFlush(message);


    }

    private void writeAndFlush(Message message, ChannelMatcher channelMatcher) {
        room.roomGroup.writeAndFlush(message, channelMatcher);
    }

    public void playerSitMessage(Seat seat) {

        com.jhd.game.texasholdem.bean.Seat
                messageSeat = Convert.convert(seat);
        SCSitMessage scSitMessage = new SCSitMessage();
        scSitMessage.setSeat(messageSeat);
        writeAndFlush(scSitMessage);

    }

    public void playerReadyGameMessage(boolean ready, Seat seat) {

        SCReadyGameMessage readyGameMessage = new SCReadyGameMessage();
        readyGameMessage.setReady(ready);
        readyGameMessage.setSeatIndex(seat.index);

        writeAndFlush(readyGameMessage);
        //  writeAndFlush(readyGameMessage);
    }

    public void playerStandMessage(Seat seat) {
        SCStandMessage standMessage = new SCStandMessage();
        standMessage.setSeatIndex(seat.index);
        writeAndFlush(standMessage);

    }

    public void playerBetMessage(Seat seat, double chip) {

        SCBetMessage betMessage = new SCBetMessage();
        betMessage.setChip(chip);
        betMessage.setSeatIndex(seat.index);
        betMessage.setChipPool(room.chipPool);
        betMessage.setType(Constant.BET_TYPE.BET.toString());
        writeAndFlush(betMessage);
    }
    public void playerRaiseMessage(Seat seat, double chip) {

        SCBetMessage betMessage = new SCBetMessage();
        betMessage.setChip(chip);
        betMessage.setSeatIndex(seat.index);
        betMessage.setChipPool(room.chipPool);
        betMessage.setType(Constant.BET_TYPE.RAISE.toString());
        writeAndFlush(betMessage);
    }

    public void playerCallMessage(Seat seat, double chip) {
        SCCallMessage message = new SCCallMessage();
        message.setSeatIndex(seat.index);
        message.setChip(chip);
        //writeAndFlush(message);

        SCBetMessage betMessage = new SCBetMessage();
        betMessage.setChip(chip);
        betMessage.setSeatIndex(seat.index);
        betMessage.setChipPool(room.chipPool);
        betMessage.setType(Constant.BET_TYPE.CALL.toString());
        writeAndFlush(betMessage);
    }

    public void playerAllMessage(Seat seat, double chip) {

        SCAllinMessage allinMessage = new SCAllinMessage();
        allinMessage.setSeatIndex(seat.index
        );
        allinMessage.setChip(chip);
        //  writeAndFlush(allinMessage);

        SCBetMessage betMessage = new SCBetMessage();
        betMessage.setChip(chip);
        betMessage.setSeatIndex(seat.index);
        betMessage.setChipPool(room.chipPool);
        betMessage.setType(Constant.BET_TYPE.ALLIN.toString());
        writeAndFlush(betMessage);
    }

    public void playerEntryRoomMessage(DeskPlayer player) {
        int selfIndex = -1;
        for (Seat seat : room.seats) {
            if (seat.player != null && seat.player.getId() == player.getId()) {
                selfIndex = seat.index;
                break;
            }
        }
        GameRoom gameRoom = Convert.convert(room, selfIndex);
        SCEntryRoomMessage entryRoomMessage = new SCEntryRoomMessage();
        entryRoomMessage.setRoom(gameRoom);
        writeAndFlush(player.getId(), entryRoomMessage);


    }

    public void playerCheckMessage(Seat seat) {
        SCCheckMessage checkMessage = new SCCheckMessage();
        checkMessage.setSeatIndex(seat.index);

        SCBetMessage betMessage = new SCBetMessage();
        betMessage.setChip(0);
        betMessage.setSeatIndex(seat.index);
        betMessage.setChipPool(room.chipPool);
        betMessage.setType(Constant.BET_TYPE.CHECK.toString());
        writeAndFlush(betMessage);

    }

    public void playerFoldMessage(Seat seat) {
       // SCFoldMessage foldMessage = new SCFoldMessage();
       // foldMessage.setSeatIndex(seat.index);
       // writeAndFlush(foldMessage);


        SCBetMessage betMessage = new SCBetMessage();
        betMessage.setChip(0);
        betMessage.setSeatIndex(seat.index);
        betMessage.setChipPool(room.chipPool);
        betMessage.setType(Constant.BET_TYPE.FOLD.toString());
        writeAndFlush(betMessage);
    }


    private List<TexasAction> seatActions() {
        Seat seat = room.currentSeat;
        List<com.jhd.game.texasholdem.bean.TexasAction> texasActions = new ArrayList<>();
        com.jhd.game.texasholdem.bean.TexasAction texasAction = new com.jhd.game.texasholdem.bean.TexasAction();
        texasAction.setType(Constant.TEXAS_ACTION.FOLD.toString());
        texasActions.add(texasAction);
        if (seat.phaseBetChip == room.phaseMaxBetChip) {
            texasAction = new com.jhd.game.texasholdem.bean.TexasAction();
            texasAction.setType(Constant.TEXAS_ACTION.CHECK.toString());
            texasActions.add(texasAction);

        } else if (seat.phaseBetChip < room.phaseMaxBetChip) {
            texasAction = new com.jhd.game.texasholdem.bean.TexasAction();
            texasAction.setType(Constant.TEXAS_ACTION.CALL.toString());
            texasAction.setChip(room.phaseMaxBetChip-seat.phaseBetChip);
            texasActions.add(texasAction);
        }
        double tempChip = seat.phaseBetChip + seat.player.getChip() - room.phaseMaxBetChip;
        boolean raise = false;
        if (tempChip > room.config.smallBindChip) {
            raise = true;
            texasAction = new com.jhd.game.texasholdem.bean.TexasAction();
            texasAction.setType(Constant.TEXAS_ACTION.RAISE.toString());
            texasActions.add(texasAction);
        }
        if (!raise) {
            texasAction = new com.jhd.game.texasholdem.bean.TexasAction();
            texasAction.setType(Constant.TEXAS_ACTION.ALLIN.toString());
            texasActions.add(texasAction);
        }

        return texasActions;
    }

    public void reconnectActionMessage() {
        SCActionTurnMessage actionTurnMessage = new SCActionTurnMessage();
        actionTurnMessage.setSeatIndex(room.currentSeat.index);

        if (room.currentSeat != null) {
            writeAndFlush(room.currentSeat.player.getId(), actionTurnMessage);
        }


    }

    public void nextPlayerMessage() {

        SCActionTurnMessage actionTurnMessage = new SCActionTurnMessage();
        actionTurnMessage.setSeatIndex(room.currentSeat.index);
        actionTurnMessage.setActions(seatActions());
        writeAndFlush(actionTurnMessage);

    }

    public void startGameMessage() {
        List<Channel> joinChannels = new ArrayList<>();
        for (Seat seat : room.seats) {
            if (seat.getPlayer() != null) {
                SCStartGameMessage scStartGameMessage = new SCStartGameMessage();
                GameRoom gameRoom = Convert.convert(room, seat.index);
                scStartGameMessage.setRoom(gameRoom);
                Channel channel = writeAndFlush(seat.player.getId(), scStartGameMessage);
                if (channel != null) {
                    joinChannels.add(channel);
                }
                if (seat.joinPlayerId > 0) {
                    TexasCards texasCards = new TexasCards();
                    if (CardUtil.isPair(seat.handCards.get(0), seat.handCards.get(1))) {
                        texasCards.setType(TEXAS_POKER_TYPE.PAIR_CARD.toString());
                    } else {
                        texasCards.setType(TEXAS_POKER_TYPE.HIGH_CARD.toString());
                    }
                    texasCards.getCards().add(seat.handCards.get(0).getIntValue());
                    texasCards.getCards().add(seat.handCards.get(1).getIntValue());
                    SCTexasCardsTypeMessage texasCardsTypeMessage = new SCTexasCardsTypeMessage();
                    texasCardsTypeMessage.setTexas(texasCards);
                    writeAndFlush(seat.player.getId(), texasCardsTypeMessage);
                }

            }

        }
        SCStartGameMessage scStartGameMessage = new SCStartGameMessage();
        GameRoom gameRoom = Convert.convert(room);
        scStartGameMessage.setRoom(gameRoom);

        writeAndFlush(scStartGameMessage, channel -> !joinChannels.contains(channel));

    }

    public void syncPublicCardsMessage() {
        SCPublicCardsMessage message = new SCPublicCardsMessage();
        message.setPhase(room.phase.toString());
        List<Integer> cards = new ArrayList<>(5);

        for (Card card : room.publicCards) {
            cards.add(card.getIntValue());
        }
        message.setPublicCards(cards);
        writeAndFlush(message);
        for (Seat seat : room.seats) {
            if (seat.player != null && seat.online && seat.joinPlayerId > 0) {
                SCTexasCardsTypeMessage texasCardsTypeMessage = new SCTexasCardsTypeMessage();
                TexasCards texasCards = Convert.convertTexas(seat.texasPoker5Cards);
                texasCardsTypeMessage.setTexas(texasCards);
                writeAndFlush(seat.player.getId(), texasCardsTypeMessage);

                room.logger.debug("{} 牌型 {}",room.getLoggerStr(seat),seat.texasPoker5Cards);
            }
        }

    }

    public void partChipMessage() {
        SCPartChipMessage partChipMessage = new SCPartChipMessage();

        for (ChipGroup chipGroup : room.edgePool) {
            partChipMessage.getEdgePool().add(chipGroup.chip);
        }
        partChipMessage.setChipPool(room.chipPool);
        writeAndFlush(partChipMessage);

    }

    //堆积消息
    public void headPkSeatMessage(List<Seat> seats, int poolIndex) {
        PkSeatGroup pkSeatGroup = new PkSeatGroup();
        for (Seat seat : seats) {
            PkSeat pkSeat = new PkSeat();
            pkSeat.setTexasCards(Convert.convertTexas(seat));
            pkSeat.setChip(seat.pkGroupChip);
            pkSeat.setIndex(seat.index);
            pkSeat.setPoolIndex(poolIndex);
            pkSeat.setWin(seat.pkGroupWin);
            pkSeatGroup.getPkSeats().add(pkSeat);
        }
        pkSeatGroups.add(pkSeatGroup);
    }

    public void pkSeatMessage(List<Seat> seats, int poolIndex) {
        SCPKSeatMessage scpkSeatMessage = new SCPKSeatMessage();
        for (Seat seat : seats) {
            PkSeat pkSeat = new PkSeat();
            pkSeat.setTexasCards(Convert.convertTexas(seat));
            pkSeat.setChip(seat.pkGroupChip);

            pkSeat.setPoolIndex(poolIndex);
            pkSeat.setIndex(seat.index);
            pkSeat.setWin(seat.pkGroupWin);
            scpkSeatMessage.getPkSeats().add(pkSeat);

        }
        writeAndFlush(scpkSeatMessage);

    }
    public void foldWinMessage(Seat seat) {
        SCPKSeatMessage scpkSeatMessage = new SCPKSeatMessage();
        PkSeat pkSeat = new PkSeat();

        TexasCards texasCards = new TexasCards();
        if (CardUtil.isPair(seat.handCards.get(0), seat.handCards.get(1))) {
            texasCards.setType(TEXAS_POKER_TYPE.PAIR_CARD.toString());
        } else {
            texasCards.setType(TEXAS_POKER_TYPE.HIGH_CARD.toString());
        }
        texasCards.getCards().add(seat.handCards.get(0).getIntValue());
        texasCards.getCards().add(seat.handCards.get(1).getIntValue());
        pkSeat.setTexasCards(texasCards);
        pkSeat.setChip(seat.pkGroupChip);
        pkSeat.setPoolIndex(-1);
        pkSeat.setWin(true);
        pkSeat.setIndex(seat.index);

        scpkSeatMessage.getPkSeats().add(pkSeat);
        writeAndFlush(scpkSeatMessage);
    }
    public void chipOverMessage(Seat seat) {
        SCPKSeatMessage scpkSeatMessage = new SCPKSeatMessage();
        PkSeat pkSeat = new PkSeat();
        pkSeat.setTexasCards(Convert.convertTexas(seat));
        pkSeat.setChip(room.chipPool);
        pkSeat.setPoolIndex(-1);
        pkSeat.setIndex(seat.index);
        pkSeat.setWin(false);
        scpkSeatMessage.getPkSeats().add(pkSeat);
        writeAndFlush(scpkSeatMessage);
    }

    public void getChipMessage(Seat seat, double chip) {
        SCGetChipPoolMessage message = new SCGetChipPoolMessage();
        message.setChip(chip);
        writeAndFlush(message);

    }

    public void roundClearMessage() {
        SCRoundClearMessage clearMessage = new SCRoundClearMessage();

        for (Seat seat : room.seats) {
            clearMessage.getSeats().add(Convert.convert(seat));
        }

        pkSeatGroups.clear();
        writeAndFlush(clearMessage);

    }

    public void playerOnlienChange(Seat seat) {

        SCOnlineChangeMessage onlineChangeMessage = new SCOnlineChangeMessage();

        onlineChangeMessage.setOnline(seat.online);
        onlineChangeMessage.setSeatIndex(seat.index);

        writeAndFlush(onlineChangeMessage);


    }
}
