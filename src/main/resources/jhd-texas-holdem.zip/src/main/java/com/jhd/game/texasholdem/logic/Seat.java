package com.jhd.game.texasholdem.logic;

import com.jhd.game.texasholdem.struct.Card;
import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.jhd.game.texasholdem.struct.TexasPoker5Cards;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public class Seat {
    public Seat(int index) {
        this.index = index;
        state = Constant.SEAT_STATE.IDLE;
        handCards = new ArrayList<>();
    }

    public int index;
    public DeskPlayer player;

    public boolean online;
    public double phaseBetChip;
    public double betChip;
    public double roundWinChip;
    public double chipPool;
    public int joinPlayerId;
    public double maxChip;

    public Constant.SEAT_STATE state;
    public TexasPoker5Cards texasPoker5Cards;

    public long turnTime;
    public List<Card> handCards;
    public double pkGroupChip;
    public boolean pkGroupWin;

    public DeskPlayer getPlayer() {
        return player;
    }

    public void setPlayer(DeskPlayer player) {
        this.player = player;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public String toString() {
        return "Seat{" +
                "index=" + index +
                ", player=" + player +
                ", online=" + online +
                ", phaseBetChip=" + phaseBetChip +
                ", betChip=" + betChip +
                ", roundWinChip=" + roundWinChip +
                ", joinPlayerId=" + joinPlayerId +
                ", maxChip=" + maxChip +
                ", state=" + state +
                ", texasPoker5Cards=" + texasPoker5Cards +
                ", turnTime=" + turnTime +
                ", handCards=" + handCards +
                '}';
    }
}
