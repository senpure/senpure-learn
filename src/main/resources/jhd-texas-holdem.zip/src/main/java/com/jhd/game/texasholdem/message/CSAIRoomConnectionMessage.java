package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * ai房间连接
 * 
 * @author senpure-generator
 * @version 2017-9-13 15:11:09
 */
public class CSAIRoomConnectionMessage extends  Message {
    //连接凭证
    private String token;
    //房间ID
    private int roomId;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //连接凭证
        writeStr(buf,token);
        //房间ID
        writeInt(buf,roomId);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //连接凭证
        this.token=readStr(buf);
        //房间ID
        this.roomId=readInt(buf);
    }

    /**
     * get 连接凭证
     * @return
     */
    public  String getToken(){
        return token;
}

    /**
     * set 连接凭证
     */
    public CSAIRoomConnectionMessage setToken(String token){
        this.token=token;
        return this;
}
    /**
     * get 房间ID
     * @return
     */
    public  int getRoomId(){
        return roomId;
}

    /**
     * set 房间ID
     */
    public CSAIRoomConnectionMessage setRoomId(int roomId){
        this.roomId=roomId;
        return this;
}

    @Override
    public int getMessageId() {
    return 200100;
    }

    @Override
    public String toString() {
        return "CSAIRoomConnectionMessage{"
                +"token=" + token
                +",roomId=" + roomId
                + "}";
   }

    //最长字段长度 6
    private int filedPad = 6;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSAIRoomConnectionMessage").append("{");
        //连接凭证
        sb.append("\n");
        sb.append(indent).append(rightPad("token", filedPad)).append(" = ").append(token);
        //房间ID
        sb.append("\n");
        sb.append(indent).append(rightPad("roomId", filedPad)).append(" = ").append(roomId);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}