package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 请求下注
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class CSBetMessage extends  Message {
    //下注筹码
    private double chip;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //下注筹码
        writeDouble(buf,chip);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //下注筹码
        this.chip = readDouble(buf);
    }

    /**
     * get 下注筹码
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 下注筹码
     */
    public CSBetMessage setChip(double chip){
        this.chip=chip;
        return this;
}

    @Override
    public int getMessageId() {
    return 100109;
    }

    @Override
    public String toString() {
        return "CSBetMessage{"
                +"chip=" + chip
                + "}";
   }

    //最长字段长度 4
    private int filedPad = 4;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSBetMessage").append("{");
        //下注筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}