package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 请求创建房间
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class CSCreateRoomMessage extends  Message {
    //房间名
    private String name;
    //前注
    private double ante;
    //大盲注
    private double bigBlind;
    //玩多久(毫秒数)
    private double howLongTime;
    //初始筹码
    private double chip;
    //最大筹码
    private double maxChip;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //房间名
        writeStr(buf,name);
        //前注
        writeDouble(buf,ante);
        //大盲注
        writeDouble(buf,bigBlind);
        //玩多久(毫秒数)
        writeDouble(buf,howLongTime);
        //初始筹码
        writeDouble(buf,chip);
        //最大筹码
        writeDouble(buf,maxChip);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //房间名
        this.name= readStr(buf);
        //前注
        this.ante = readDouble(buf);
        //大盲注
        this.bigBlind = readDouble(buf);
        //玩多久(毫秒数)
        this.howLongTime = readDouble(buf);
        //初始筹码
        this.chip = readDouble(buf);
        //最大筹码
        this.maxChip = readDouble(buf);
    }

    /**
     * get 房间名
     * @return
     */
    public  String getName(){
        return name;
}

    /**
     * set 房间名
     */
    public CSCreateRoomMessage setName(String name){
        this.name=name;
        return this;
}
    public  double getAnte(){
        return ante;
}

    public CSCreateRoomMessage setAnte(double ante){
        this.ante=ante;
        return this;
}
    /**
     * get 大盲注
     * @return
     */
    public  double getBigBlind(){
        return bigBlind;
}

    /**
     * set 大盲注
     */
    public CSCreateRoomMessage setBigBlind(double bigBlind){
        this.bigBlind=bigBlind;
        return this;
}
    /**
     * get 玩多久(毫秒数)
     * @return
     */
    public  double getHowLongTime(){
        return howLongTime;
}

    /**
     * set 玩多久(毫秒数)
     */
    public CSCreateRoomMessage setHowLongTime(double howLongTime){
        this.howLongTime=howLongTime;
        return this;
}
    /**
     * get 初始筹码
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 初始筹码
     */
    public CSCreateRoomMessage setChip(double chip){
        this.chip=chip;
        return this;
}
    /**
     * get 最大筹码
     * @return
     */
    public  double getMaxChip(){
        return maxChip;
}

    /**
     * set 最大筹码
     */
    public CSCreateRoomMessage setMaxChip(double maxChip){
        this.maxChip=maxChip;
        return this;
}

    @Override
    public int getMessageId() {
    return 100103;
    }

    @Override
    public String toString() {
        return "CSCreateRoomMessage{"
                +"name=" + name
                +",ante=" + ante
                +",bigBlind=" + bigBlind
                +",howLongTime=" + howLongTime
                +",chip=" + chip
                +",maxChip=" + maxChip
                + "}";
   }

    //最长字段长度 11
    private int filedPad = 11;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSCreateRoomMessage").append("{");
        //房间名
        sb.append("\n");
        sb.append(indent).append(rightPad("name", filedPad)).append(" = ").append(name);
        //前注
        sb.append("\n");
        sb.append(indent).append(rightPad("ante", filedPad)).append(" = ").append(ante);
        //大盲注
        sb.append("\n");
        sb.append(indent).append(rightPad("bigBlind", filedPad)).append(" = ").append(bigBlind);
        //玩多久(毫秒数)
        sb.append("\n");
        sb.append(indent).append(rightPad("howLongTime", filedPad)).append(" = ").append(howLongTime);
        //初始筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        //最大筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("maxChip", filedPad)).append(" = ").append(maxChip);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}