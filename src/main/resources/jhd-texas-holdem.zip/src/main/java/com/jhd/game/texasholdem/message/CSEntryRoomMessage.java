package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 请求进入房间
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class CSEntryRoomMessage extends  Message {
    //房间Id
    private int roomId;
    //是否坐下
    private boolean sit;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //房间Id
        writeInt(buf,roomId);
        //是否坐下
        writeBoolean(buf,sit);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //房间Id
        this.roomId = readInt(buf);
        //是否坐下
        this.sit = readBoolean(buf);
    }

    /**
     * get 房间Id
     * @return
     */
    public  int getRoomId(){
        return roomId;
}

    /**
     * set 房间Id
     */
    public CSEntryRoomMessage setRoomId(int roomId){
        this.roomId=roomId;
        return this;
}
    /**
     * get 是否坐下
     * @return
     */
    public  boolean  isSit(){
        return sit;
}

    /**
     * set 是否坐下
     */
    public CSEntryRoomMessage setSit(boolean sit){
        this.sit=sit;
        return this;
}

    @Override
    public int getMessageId() {
    return 100105;
    }

    @Override
    public String toString() {
        return "CSEntryRoomMessage{"
                +"roomId=" + roomId
                +",sit=" + sit
                + "}";
   }

    //最长字段长度 6
    private int filedPad = 6;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSEntryRoomMessage").append("{");
        //房间Id
        sb.append("\n");
        sb.append(indent).append(rightPad("roomId", filedPad)).append(" = ").append(roomId);
        //是否坐下
        sb.append("\n");
        sb.append(indent).append(rightPad("sit", filedPad)).append(" = ").append(sit);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}