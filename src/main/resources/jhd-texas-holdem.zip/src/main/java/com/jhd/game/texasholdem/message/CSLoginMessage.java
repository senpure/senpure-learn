package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 请求登录
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class CSLoginMessage extends  Message {
    //服务器给的唯一标识
    private String token;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //服务器给的唯一标识
        writeStr(buf,token);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //服务器给的唯一标识
        this.token= readStr(buf);
    }

    /**
     * get 服务器给的唯一标识
     * @return
     */
    public  String getToken(){
        return token;
}

    /**
     * set 服务器给的唯一标识
     */
    public CSLoginMessage setToken(String token){
        this.token=token;
        return this;
}

    @Override
    public int getMessageId() {
    return 100101;
    }

    @Override
    public String toString() {
        return "CSLoginMessage{"
                +"token=" + token
                + "}";
   }

    //最长字段长度 5
    private int filedPad = 5;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSLoginMessage").append("{");
        //服务器给的唯一标识
        sb.append("\n");
        sb.append(indent).append(rightPad("token", filedPad)).append(" = ").append(token);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}