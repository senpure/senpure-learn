package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 快速游戏
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class CSQuickGameMessage extends  Message {

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
    }


    @Override
    public int getMessageId() {
    return 100117;
    }

    @Override
    public String toString() {
        return "CSQuickGameMessage{"
                + "}";
   }


    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSQuickGameMessage").append("{");
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}