package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 请求坐下
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class CSSitMessage extends  Message {
    //座位Id(下标为开始为0)
    private int seatIndex;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位Id(下标为开始为0)
        writeInt(buf,seatIndex);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位Id(下标为开始为0)
        this.seatIndex = readInt(buf);
    }

    /**
     * get 座位Id(下标为开始为0)
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位Id(下标为开始为0)
     */
    public CSSitMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}

    @Override
    public int getMessageId() {
    return 100107;
    }

    @Override
    public String toString() {
        return "CSSitMessage{"
                +"seatIndex=" + seatIndex
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("CSSitMessage").append("{");
        //座位Id(下标为开始为0)
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}