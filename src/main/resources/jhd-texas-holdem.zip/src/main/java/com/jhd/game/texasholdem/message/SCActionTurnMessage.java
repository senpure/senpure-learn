package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.TexasAction;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
 * 轮到玩家操作
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCActionTurnMessage extends  Message {
    //座位编号
    private int seatIndex;
    //可操作选项
    private List<TexasAction> actions=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号
        writeInt(buf,seatIndex);
        //可操作选项
        int actionsSize=actions.size();
        writeShort(buf,actionsSize);
        for(int i=0;i< actionsSize;i++){
            writeBean(buf,actions.get(i),false);
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号
        this.seatIndex = readInt(buf);
        //可操作选项
        int actionsSize=readShort(buf);
        for(int i=0;i<actionsSize;i++){
            this.actions.add((TexasAction)readBean(buf,TexasAction.class,false));
         }
    }

    /**
     * get 座位编号
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位编号
     */
    public SCActionTurnMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}
     /**
      * get 可操作选项
      * @return
      */
    public List<TexasAction> getActions(){
        return actions;
    }
     /**
      * set 可操作选项
      */
    public SCActionTurnMessage setActions (List<TexasAction> actions){
        this.actions=actions;
        return this;
    }


    @Override
    public int getMessageId() {
    return 100203;
    }

    @Override
    public String toString() {
        return "SCActionTurnMessage{"
                +"seatIndex=" + seatIndex
                +",actions=" + actions
                + "}";
   }

    //9 + 3 = 12 个空格
    private String nextIndent ="            ";
    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCActionTurnMessage").append("{");
        //座位编号
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        //可操作选项
        sb.append("\n");
        sb.append(indent).append(rightPad("actions", filedPad)).append(" = ");
        int actionsSize = actions.size();
        if (actionsSize > 0) {
            sb.append("[");
            for (int i = 0; i<actionsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(actions.get(i).toString(indent + nextIndent));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}