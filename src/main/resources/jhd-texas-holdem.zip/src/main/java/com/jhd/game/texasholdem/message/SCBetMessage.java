package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 玩家下注通知,过，跟，加, allin 都是这一个消息
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCBetMessage extends  Message {
    //下注筹码
    private double chip;
    //下注座位编号(0开始)
    private int seatIndex;
    //下注下注类型 CHECK,CALL,RAISE,ALLIN
    private String type;
    //当前奖池筹码
    private double chipPool;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //下注筹码
        writeDouble(buf,chip);
        //下注座位编号(0开始)
        writeInt(buf,seatIndex);
        //下注下注类型 CHECK,CALL,RAISE,ALLIN
        writeStr(buf,type);
        //当前奖池筹码
        writeDouble(buf,chipPool);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //下注筹码
        this.chip = readDouble(buf);
        //下注座位编号(0开始)
        this.seatIndex = readInt(buf);
        //下注下注类型 CHECK,CALL,RAISE,ALLIN
        this.type= readStr(buf);
        //当前奖池筹码
        this.chipPool = readDouble(buf);
    }

    /**
     * get 下注筹码
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 下注筹码
     */
    public SCBetMessage setChip(double chip){
        this.chip=chip;
        return this;
}
    /**
     * get 下注座位编号(0开始)
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 下注座位编号(0开始)
     */
    public SCBetMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}
    /**
     * get 下注下注类型 CHECK,CALL,RAISE,ALLIN
     * @return
     */
    public  String getType(){
        return type;
}

    /**
     * set 下注下注类型 CHECK,CALL,RAISE,ALLIN
     */
    public SCBetMessage setType(String type){
        this.type=type;
        return this;
}
    /**
     * get 当前奖池筹码
     * @return
     */
    public  double getChipPool(){
        return chipPool;
}

    /**
     * set 当前奖池筹码
     */
    public SCBetMessage setChipPool(double chipPool){
        this.chipPool=chipPool;
        return this;
}

    @Override
    public int getMessageId() {
    return 100110;
    }

    @Override
    public String toString() {
        return "SCBetMessage{"
                +"chip=" + chip
                +",seatIndex=" + seatIndex
                +",type=" + type
                +",chipPool=" + chipPool
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCBetMessage").append("{");
        //下注筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        //下注座位编号(0开始)
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        //下注下注类型 CHECK,CALL,RAISE,ALLIN
        sb.append("\n");
        sb.append(indent).append(rightPad("type", filedPad)).append(" = ").append(type);
        //当前奖池筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chipPool", filedPad)).append(" = ").append(chipPool);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}