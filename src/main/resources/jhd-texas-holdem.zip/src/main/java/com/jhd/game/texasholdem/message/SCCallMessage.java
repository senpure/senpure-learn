package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 请求跟注返回
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCCallMessage extends  Message {
    //座位编号(0开始)
    private int seatIndex;
    //跟注的筹码
    private double chip;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号(0开始)
        writeInt(buf,seatIndex);
        //跟注的筹码
        writeDouble(buf,chip);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号(0开始)
        this.seatIndex = readInt(buf);
        //跟注的筹码
        this.chip = readDouble(buf);
    }

    /**
     * get 座位编号(0开始)
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位编号(0开始)
     */
    public SCCallMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}
    /**
     * get 跟注的筹码
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 跟注的筹码
     */
    public SCCallMessage setChip(double chip){
        this.chip=chip;
        return this;
}

    @Override
    public int getMessageId() {
    return 100124;
    }

    @Override
    public String toString() {
        return "SCCallMessage{"
                +"seatIndex=" + seatIndex
                +",chip=" + chip
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCCallMessage").append("{");
        //座位编号(0开始)
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        //跟注的筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}