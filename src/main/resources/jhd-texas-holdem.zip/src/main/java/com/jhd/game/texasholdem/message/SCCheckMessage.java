package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 玩家过牌通知
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCCheckMessage extends  Message {
    //座位编号(0开始)
    private int seatIndex;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号(0开始)
        writeInt(buf,seatIndex);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号(0开始)
        this.seatIndex = readInt(buf);
    }

    /**
     * get 座位编号(0开始)
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位编号(0开始)
     */
    public SCCheckMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}

    @Override
    public int getMessageId() {
    return 100112;
    }

    @Override
    public String toString() {
        return "SCCheckMessage{"
                +"seatIndex=" + seatIndex
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCCheckMessage").append("{");
        //座位编号(0开始)
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}