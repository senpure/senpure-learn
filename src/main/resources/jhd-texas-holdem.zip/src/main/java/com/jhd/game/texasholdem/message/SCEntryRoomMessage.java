package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.GameRoom;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 玩家进入房间返回
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCEntryRoomMessage extends  Message {
    //房间信息
    private GameRoom room;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //房间信息
        writeBean(buf,room,true);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //房间信息
        this.room = (GameRoom)readBean(buf,GameRoom.class,true);
    }

    /**
     * get 房间信息
     * @return
     */
    public  GameRoom getRoom(){
        return room;
}

    /**
     * set 房间信息
     */
    public SCEntryRoomMessage setRoom(GameRoom room){
        this.room=room;
        return this;
}

    @Override
    public int getMessageId() {
    return 100106;
    }

    @Override
    public String toString() {
        return "SCEntryRoomMessage{"
                +"room=" + room
                + "}";
   }

    //4 + 3 = 7 个空格
    private String nextIndent ="       ";
    //最长字段长度 4
    private int filedPad = 4;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCEntryRoomMessage").append("{");
        //房间信息
        sb.append("\n");
        sb.append(indent).append(rightPad("room", filedPad)).append(" = ");
        if(room!=null){
            sb.append(room.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}