package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 获取筹码消息
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCGetChipPoolMessage extends  Message {
    //获取多少筹码
    private double chip;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //获取多少筹码
        writeDouble(buf,chip);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //获取多少筹码
        this.chip = readDouble(buf);
    }

    /**
     * get 获取多少筹码
     * @return
     */
    public  double getChip(){
        return chip;
}

    /**
     * set 获取多少筹码
     */
    public SCGetChipPoolMessage setChip(double chip){
        this.chip=chip;
        return this;
}

    @Override
    public int getMessageId() {
    return 100208;
    }

    @Override
    public String toString() {
        return "SCGetChipPoolMessage{"
                +"chip=" + chip
                + "}";
   }

    //最长字段长度 4
    private int filedPad = 4;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCGetChipPoolMessage").append("{");
        //获取多少筹码
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}