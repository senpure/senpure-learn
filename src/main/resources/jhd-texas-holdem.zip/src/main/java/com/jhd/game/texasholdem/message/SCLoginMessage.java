package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.Player;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 登录返回
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCLoginMessage extends  Message {
    //玩家信息
    private Player player;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //玩家信息
        writeBean(buf,player,true);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //玩家信息
        this.player = (Player)readBean(buf,Player.class,true);
    }

    /**
     * get 玩家信息
     * @return
     */
    public  Player getPlayer(){
        return player;
}

    /**
     * set 玩家信息
     */
    public SCLoginMessage setPlayer(Player player){
        this.player=player;
        return this;
}

    @Override
    public int getMessageId() {
    return 100102;
    }

    @Override
    public String toString() {
        return "SCLoginMessage{"
                +"player=" + player
                + "}";
   }

    //6 + 3 = 9 个空格
    private String nextIndent ="         ";
    //最长字段长度 6
    private int filedPad = 6;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCLoginMessage").append("{");
        //玩家信息
        sb.append("\n");
        sb.append(indent).append(rightPad("player", filedPad)).append(" = ");
        if(player!=null){
            sb.append(player.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}