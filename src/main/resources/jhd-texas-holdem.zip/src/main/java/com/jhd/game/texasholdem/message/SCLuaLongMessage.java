package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * luaLong型数据的支持
 * 
 * @author senpure-generator
 * @version 2017-9-14 16:56:24
 */
public class SCLuaLongMessage extends  Message {
    //chip
    private long chip;
    //time
    private long time;
    //num
    private long num;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //chip
        writeLong(buf,chip);
        //time
        writeLong(buf,time);
        //num
        writeLong(buf,num);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //chip
        this.chip = readLong(buf);
        //time
        this.time = readLong(buf);
        //num
        this.num = readLong(buf);
    }

    /**
     * get chip
     * @return
     */
    public  long getChip(){
        return chip;
}

    /**
     * set chip
     */
    public SCLuaLongMessage setChip(long chip){
        this.chip=chip;
        return this;
}
    /**
     * get time
     * @return
     */
    public  long getTime(){
        return time;
}

    /**
     * set time
     */
    public SCLuaLongMessage setTime(long time){
        this.time=time;
        return this;
}
    /**
     * get num
     * @return
     */
    public  long getNum(){
        return num;
}

    /**
     * set num
     */
    public SCLuaLongMessage setNum(long num){
        this.num=num;
        return this;
}

    @Override
    public int getMessageId() {
    return 100132;
    }

    @Override
    public String toString() {
        return "SCLuaLongMessage{"
                +"chip=" + chip
                +",time=" + time
                +",num=" + num
                + "}";
   }

    //最长字段长度 4
    private int filedPad = 4;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCLuaLongMessage").append("{");
        //chip
        sb.append("\n");
        sb.append(indent).append(rightPad("chip", filedPad)).append(" = ").append(chip);
        //time
        sb.append("\n");
        sb.append(indent).append(rightPad("time", filedPad)).append(" = ").append(time);
        //num
        sb.append("\n");
        sb.append(indent).append(rightPad("num", filedPad)).append(" = ").append(num);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}