package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 玩家在线状态改变
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCOnlineChangeMessage extends  Message {
    //是否在线true/false
    private boolean online;
    //座位编号
    private int seatIndex;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //是否在线true/false
        writeBoolean(buf,online);
        //座位编号
        writeInt(buf,seatIndex);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //是否在线true/false
        this.online = readBoolean(buf);
        //座位编号
        this.seatIndex = readInt(buf);
    }

    /**
     * get 是否在线true/false
     * @return
     */
    public  boolean  isOnline(){
        return online;
}

    /**
     * set 是否在线true/false
     */
    public SCOnlineChangeMessage setOnline(boolean online){
        this.online=online;
        return this;
}
    /**
     * get 座位编号
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位编号
     */
    public SCOnlineChangeMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}

    @Override
    public int getMessageId() {
    return 100202;
    }

    @Override
    public String toString() {
        return "SCOnlineChangeMessage{"
                +"online=" + online
                +",seatIndex=" + seatIndex
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCOnlineChangeMessage").append("{");
        //是否在线true/false
        sb.append("\n");
        sb.append(indent).append(rightPad("online", filedPad)).append(" = ").append(online);
        //座位编号
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}