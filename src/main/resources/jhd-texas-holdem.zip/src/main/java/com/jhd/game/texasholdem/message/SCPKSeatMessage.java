package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.PkSeat;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
 * 玩家比牌消息
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCPKSeatMessage extends  Message {
    private List<PkSeat> pkSeats=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        int pkSeatsSize=pkSeats.size();
        writeShort(buf,pkSeatsSize);
        for(int i=0;i< pkSeatsSize;i++){
            writeBean(buf,pkSeats.get(i),false);
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        int pkSeatsSize=readShort(buf);
        for(int i=0;i<pkSeatsSize;i++){
            this.pkSeats.add((PkSeat)readBean(buf,PkSeat.class,false));
         }
    }

    public List<PkSeat> getPkSeats(){
        return pkSeats;
    }
    public SCPKSeatMessage setPkSeats (List<PkSeat> pkSeats){
        this.pkSeats=pkSeats;
        return this;
    }


    @Override
    public int getMessageId() {
    return 100207;
    }

    @Override
    public String toString() {
        return "SCPKSeatMessage{"
                +"pkSeats=" + pkSeats
                + "}";
   }

    //7 + 3 = 10 个空格
    private String nextIndent ="          ";
    //最长字段长度 7
    private int filedPad = 7;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCPKSeatMessage").append("{");
        sb.append("\n");
        sb.append(indent).append(rightPad("pkSeats", filedPad)).append(" = ");
        int pkSeatsSize = pkSeats.size();
        if (pkSeatsSize > 0) {
            sb.append("[");
            for (int i = 0; i<pkSeatsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(pkSeats.get(i).toString(indent + nextIndent));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}