package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
 * 分筹码池
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCPartChipMessage extends  Message {
    //边池
    private List<Double> edgePool=new ArrayList();
    //主池
    private double chipPool;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //边池
        int edgePoolSize=edgePool.size();
        writeShort(buf,edgePoolSize);
        for(int i=0;i< edgePoolSize;i++){
            writeDouble(buf,edgePool.get(i));
           }
        //主池
        writeDouble(buf,chipPool);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //边池
        int edgePoolSize=readShort(buf);
        for(int i=0;i<edgePoolSize;i++){
            this.edgePool.add(readDouble(buf));
         }
        //主池
        this.chipPool = readDouble(buf);
    }

    public List<Double> getEdgePool(){
        return edgePool;
    }
    public SCPartChipMessage setEdgePool (List<Double> edgePool){
        this.edgePool=edgePool;
        return this;
    }

    public  double getChipPool(){
        return chipPool;
}

    public SCPartChipMessage setChipPool(double chipPool){
        this.chipPool=chipPool;
        return this;
}

    @Override
    public int getMessageId() {
    return 100205;
    }

    @Override
    public String toString() {
        return "SCPartChipMessage{"
                +"edgePool=" + edgePool
                +",chipPool=" + chipPool
                + "}";
   }

    //8 + 3 = 11 个空格
    private String nextIndent ="           ";
    //最长字段长度 8
    private int filedPad = 8;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCPartChipMessage").append("{");
        //边池
        sb.append("\n");
        sb.append(indent).append(rightPad("edgePool", filedPad)).append(" = ");
        int edgePoolSize = edgePool.size();
        if (edgePoolSize > 0) {
            sb.append("[");
            for (int i = 0; i<edgePoolSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(edgePool.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        //主池
        sb.append("\n");
        sb.append(indent).append(rightPad("chipPool", filedPad)).append(" = ").append(chipPool);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}