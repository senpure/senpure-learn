package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
 * 当前的所有公共牌
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCPublicCardsMessage extends  Message {
    //牌局阶段 PERFLOP,FLOP,TURN,RIVER
    private String phase;
    //当前的所有公共牌
    private List<Integer> publicCards=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //牌局阶段 PERFLOP,FLOP,TURN,RIVER
        writeStr(buf,phase);
        //当前的所有公共牌
        int publicCardsSize=publicCards.size();
        writeShort(buf,publicCardsSize);
        for(int i=0;i< publicCardsSize;i++){
            writeInt(buf,publicCards.get(i));
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //牌局阶段 PERFLOP,FLOP,TURN,RIVER
        this.phase= readStr(buf);
        //当前的所有公共牌
        int publicCardsSize=readShort(buf);
        for(int i=0;i<publicCardsSize;i++){
            this.publicCards.add(readInt(buf));
         }
    }

    /**
     * get 牌局阶段 PERFLOP,FLOP,TURN,RIVER
     * @return
     */
    public  String getPhase(){
        return phase;
}

    /**
     * set 牌局阶段 PERFLOP,FLOP,TURN,RIVER
     */
    public SCPublicCardsMessage setPhase(String phase){
        this.phase=phase;
        return this;
}
     /**
      * get 当前的所有公共牌
      * @return
      */
    public List<Integer> getPublicCards(){
        return publicCards;
    }
     /**
      * set 当前的所有公共牌
      */
    public SCPublicCardsMessage setPublicCards (List<Integer> publicCards){
        this.publicCards=publicCards;
        return this;
    }


    @Override
    public int getMessageId() {
    return 100201;
    }

    @Override
    public String toString() {
        return "SCPublicCardsMessage{"
                +"phase=" + phase
                +",publicCards=" + publicCards
                + "}";
   }

    //11 + 3 = 14 个空格
    private String nextIndent ="              ";
    //最长字段长度 11
    private int filedPad = 11;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCPublicCardsMessage").append("{");
        //牌局阶段 PERFLOP,FLOP,TURN,RIVER
        sb.append("\n");
        sb.append(indent).append(rightPad("phase", filedPad)).append(" = ").append(phase);
        //当前的所有公共牌
        sb.append("\n");
        sb.append(indent).append(rightPad("publicCards", filedPad)).append(" = ");
        int publicCardsSize = publicCards.size();
        if (publicCardsSize > 0) {
            sb.append("[");
            for (int i = 0; i<publicCardsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(publicCards.get(i));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}