package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 准备/取消通知
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCReadyGameMessage extends  Message {
    //座位编号
    private int seatIndex;
    //准备/取消 true/false
    private boolean ready;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号
        writeInt(buf,seatIndex);
        //准备/取消 true/false
        writeBoolean(buf,ready);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号
        this.seatIndex = readInt(buf);
        //准备/取消 true/false
        this.ready = readBoolean(buf);
    }

    /**
     * get 座位编号
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位编号
     */
    public SCReadyGameMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}
    /**
     * get 准备/取消 true/false
     * @return
     */
    public  boolean  isReady(){
        return ready;
}

    /**
     * set 准备/取消 true/false
     */
    public SCReadyGameMessage setReady(boolean ready){
        this.ready=ready;
        return this;
}

    @Override
    public int getMessageId() {
    return 100120;
    }

    @Override
    public String toString() {
        return "SCReadyGameMessage{"
                +"seatIndex=" + seatIndex
                +",ready=" + ready
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCReadyGameMessage").append("{");
        //座位编号
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        //准备/取消 true/false
        sb.append("\n");
        sb.append(indent).append(rightPad("ready", filedPad)).append(" = ").append(ready);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}