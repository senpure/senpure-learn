package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.Seat;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

import java.util.List;
import java.util.ArrayList;

/**
 * 当局结算
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCRoundClearMessage extends  Message {
    //座位
    private List<Seat> seats=new ArrayList();

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位
        int seatsSize=seats.size();
        writeShort(buf,seatsSize);
        for(int i=0;i< seatsSize;i++){
            writeBean(buf,seats.get(i),false);
           }
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位
        int seatsSize=readShort(buf);
        for(int i=0;i<seatsSize;i++){
            this.seats.add((Seat)readBean(buf,Seat.class,false));
         }
    }

    public List<Seat> getSeats(){
        return seats;
    }
    public SCRoundClearMessage setSeats (List<Seat> seats){
        this.seats=seats;
        return this;
    }


    @Override
    public int getMessageId() {
    return 100204;
    }

    @Override
    public String toString() {
        return "SCRoundClearMessage{"
                +"seats=" + seats
                + "}";
   }

    //5 + 3 = 8 个空格
    private String nextIndent ="        ";
    //最长字段长度 5
    private int filedPad = 5;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCRoundClearMessage").append("{");
        //座位
        sb.append("\n");
        sb.append(indent).append(rightPad("seats", filedPad)).append(" = ");
        int seatsSize = seats.size();
        if (seatsSize > 0) {
            sb.append("[");
            for (int i = 0; i<seatsSize;i++) {
                sb.append("\n");
                sb.append(nextIndent);
                sb.append(indent).append(seats.get(i).toString(indent + nextIndent));
            }
            sb.append("\n");
        sb.append(nextIndent);
            sb.append(indent).append("]");
        }else {
            sb.append("null");
        }

        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}