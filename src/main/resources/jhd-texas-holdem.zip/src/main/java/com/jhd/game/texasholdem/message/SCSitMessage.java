package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.Seat;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 玩家坐下通知
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCSitMessage extends  Message {
    //玩家坐下的位置
    private Seat seat;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //玩家坐下的位置
        writeBean(buf,seat,true);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //玩家坐下的位置
        this.seat = (Seat)readBean(buf,Seat.class,true);
    }

    /**
     * get 玩家坐下的位置
     * @return
     */
    public  Seat getSeat(){
        return seat;
}

    /**
     * set 玩家坐下的位置
     */
    public SCSitMessage setSeat(Seat seat){
        this.seat=seat;
        return this;
}

    @Override
    public int getMessageId() {
    return 100108;
    }

    @Override
    public String toString() {
        return "SCSitMessage{"
                +"seat=" + seat
                + "}";
   }

    //4 + 3 = 7 个空格
    private String nextIndent ="       ";
    //最长字段长度 4
    private int filedPad = 4;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCSitMessage").append("{");
        //玩家坐下的位置
        sb.append("\n");
        sb.append(indent).append(rightPad("seat", filedPad)).append(" = ");
        if(seat!=null){
            sb.append(seat.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}