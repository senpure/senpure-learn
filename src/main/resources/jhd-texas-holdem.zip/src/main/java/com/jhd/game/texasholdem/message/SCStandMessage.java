package com.jhd.game.texasholdem.message;

import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 玩家站起通知
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCStandMessage extends  Message {
    //座位编号
    private int seatIndex;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //座位编号
        writeInt(buf,seatIndex);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //座位编号
        this.seatIndex = readInt(buf);
    }

    /**
     * get 座位编号
     * @return
     */
    public  int getSeatIndex(){
        return seatIndex;
}

    /**
     * set 座位编号
     */
    public SCStandMessage setSeatIndex(int seatIndex){
        this.seatIndex=seatIndex;
        return this;
}

    @Override
    public int getMessageId() {
    return 100122;
    }

    @Override
    public String toString() {
        return "SCStandMessage{"
                +"seatIndex=" + seatIndex
                + "}";
   }

    //最长字段长度 9
    private int filedPad = 9;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCStandMessage").append("{");
        //座位编号
        sb.append("\n");
        sb.append(indent).append(rightPad("seatIndex", filedPad)).append(" = ").append(seatIndex);
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}