package com.jhd.game.texasholdem.message;

import com.jhd.game.texasholdem.bean.TexasCards;
import com.senpure.io.message.Message;
import io.netty.buffer.ByteBuf;

/**
 * 我的牌型
 * 
 * @author senpure-generator
 * @version 2017-9-28 16:08:07
 */
public class SCTexasCardsTypeMessage extends  Message {
    //牌型
    private TexasCards texas;

    /**
     * 写入字节缓存
     */
    @Override
    public void write(ByteBuf buf){
        //牌型
        writeBean(buf,texas,true);
    }


    /**
     * 读取字节缓存
     */
    @Override
    public void read(ByteBuf buf){
        //牌型
        this.texas = (TexasCards)readBean(buf,TexasCards.class,true);
    }

    public  TexasCards getTexas(){
        return texas;
}

    public SCTexasCardsTypeMessage setTexas(TexasCards texas){
        this.texas=texas;
        return this;
}

    @Override
    public int getMessageId() {
    return 100206;
    }

    @Override
    public String toString() {
        return "SCTexasCardsTypeMessage{"
                +"texas=" + texas
                + "}";
   }

    //5 + 3 = 8 个空格
    private String nextIndent ="        ";
    //最长字段长度 5
    private int filedPad = 5;

    @Override
    public String toString(String indent) {
        indent = indent == null ? "" : indent;
        StringBuilder sb = new StringBuilder();
        sb.append("SCTexasCardsTypeMessage").append("{");
        //牌型
        sb.append("\n");
        sb.append(indent).append(rightPad("texas", filedPad)).append(" = ");
        if(texas!=null){
            sb.append(texas.toString(indent+nextIndent));
        } else {
            sb.append("null");
        }
        sb.append("\n");
        sb.append(indent).append("}");
        return sb.toString();
    }

}