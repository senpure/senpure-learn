package com.jhd.game.texasholdem.result;

import com.senpure.base.result.Message;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/8/28.
 */
@Component(value = "com.jhd.game.texasholdem.result.result")
public class Result extends com.senpure.base.result.Result {

    @Message(message = "房间人数过多")
    public static final int ROOM_PLAYER_NUM_OVERMUCH = 200;
    @Message(message = "房间不存在")
    public static final int ROOM_NOT_EXIST = 201;
    @Message(message = "玩家未进入房间")
    public static final int PLAYER_HAS_NOT_ROOM = 202;
    @Message(message = "玩家未坐下")
    public static final int PLAYER_HAS_NOT_SEAT = 203;

    @Message(message = "座位上已经有人")
    public static final int SEAT_HAS_PLAYER = 204;

    @Message(message = "玩牌时不允许站起")
    public static final int CAN_NOT_STAND= 205;

    @Message(message = "玩家筹码不足")
    public static final int PLAYER_CHIP_LACK = 300;
    @Message(message = "玩家筹码不足{0}")
    public static final int PLAYER_CHIP_LACK_NUM = 301;

}
