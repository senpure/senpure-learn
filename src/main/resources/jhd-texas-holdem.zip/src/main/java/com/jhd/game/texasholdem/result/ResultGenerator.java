package com.jhd.game.texasholdem.result;


import com.senpure.base.result.ResultHelper;

/**
 * Created by 罗中正 on 2017/8/29.
 */
public class ResultGenerator {
    public static void main(String[] args) throws InstantiationException, IllegalAccessException {


        new Thread(){

            @Override
            public void run() {
                try {
                    ResultHelper.devSyncResult(new Class[]{com.senpure.base.result.Result.class,Result.class});
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }
}
