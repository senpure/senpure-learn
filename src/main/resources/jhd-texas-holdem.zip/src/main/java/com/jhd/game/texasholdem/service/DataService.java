package com.jhd.game.texasholdem.service;


import com.jhd.game.texasholdem.struct.DeskPlayer;

/**
 * Created by 罗中正 on 2017/8/23.
 */
public interface DataService {

   DeskPlayer loginByToken(String token);
   DeskPlayer findPlayer(int playerId);

   void cache(DeskPlayer deskPlayer);


}
