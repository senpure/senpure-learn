package com.jhd.game.texasholdem.service;

import com.jhd.game.texasholdem.struct.DeskPlayer;
import com.jhd.store.entity.Player;
import com.jhd.store.service.PlayerService;
import com.senpure.base.util.RandomUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/8/25.
 */
@Service
public class DataServiceDefaultImpl implements DataService {

    @Autowired
    private PlayerService playerService;

    private Map<Integer, DeskPlayer> playerMap = new HashMap<>();

    @Override
    public DeskPlayer loginByToken(String token) {

        Player player = playerService.playerLoginByToken(token);
        if (player != null) {

            DeskPlayer deskPlayer = new DeskPlayer();
            deskPlayer.setId(player.getId());
            deskPlayer.setHead(player.getHead()
            );
            deskPlayer.setChip(RandomUtil.random(500000,800000000));
            deskPlayer.setNick(player.getNick());
            playerMap.put(player.getId(), deskPlayer);
            return deskPlayer;
        }

        return null;
    }

    @Override
    public DeskPlayer findPlayer(int playerId) {

        DeskPlayer deskPlayer = playerMap.get(playerId);
        return deskPlayer;
    }

    @Override
    public void cache(DeskPlayer deskPlayer) {
        playerMap.put(deskPlayer.getId(), deskPlayer);
    }
}
