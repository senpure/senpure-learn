package com.jhd.game.texasholdem.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * Created by 罗中正 on 2017/8/22.
 */
public class ServiceSupport {
    protected Logger logger;
    public ServiceSupport() {
        logger = LoggerFactory.getLogger(getClass());
    }
}
