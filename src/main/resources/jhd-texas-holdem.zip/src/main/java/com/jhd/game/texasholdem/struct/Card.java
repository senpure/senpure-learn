package com.jhd.game.texasholdem.struct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Comparator;


public class Card implements Comparator<Card>, Comparable<Card> {

    private static Logger logger = LoggerFactory.getLogger(Card.class);

    public static enum SUIT {
        // 黑桃
        SPADES,
        // 红心
        HEARTS,
        // 方片
        DIAMONDS,
        // 梅花
        CLUBS,

    }

    ;

    public static enum RANK {

        TWO(2), THREE(3), FOUR(4), FIVE(5), SIX(6), SEVEN(7), EIGHT(8), NINE(9), TEN(10), JACK(11), QUEEN(12), KING(13), ACE(
                14);
        // 数值
        private int value = 0;
        // 显示给客户端，保存数据库 10-A 11>B 12->C 13-D 14-E
        private String _value;

        private RANK(int value) {
            this.value = value;
            this._value = Integer.toHexString(value).toUpperCase();
        }

        public int getValue() {
            return value;
        }

        public static RANK getRank(int value) {

            if (value > ACE.getValue() || value < TWO.getValue()) {
                // throw new Exception("点数不合法");

                logger.warn("点数不合法" + value + "->>" + TWO.getValue());
                // value = TWO.getValue();
                return TWO;
            }

            return RANK.values()[value - 2];
        }

        public String show() {
            return _value;
        }
    }

    ;

    private SUIT suit;

    private RANK rank;
    private int value;
    private String _value;

    public Card(SUIT suit, RANK rank) {
        super();

        this.suit = suit;
        this.rank = rank;
        value = rank.getValue();
        _value = suit.ordinal() + rank.show();
    }

    public SUIT getSuit() {
        return suit;
    }

    public RANK getRank() {
        return rank;
    }

    /**
     * 扑克点数
     *
     * @return
     */
    public int getValue() {

        return value;
    }

    /**
     * int 数字格式的一张牌
     */
    public int getIntValue() {

        return suit.ordinal() * 16 + value;
    }

    public String show() {

        return _value;
    }

    @Override
    public String toString() {
        // return "Card [" + show() + "][suit=" + suit + ", rank=" + rank + "]";
        return zhSuitString() + zhRankString();
    }

    private String zhSuitString() {
        switch (suit) {
            case SPADES:
                return "黑桃";
            case HEARTS:
                return "红心";

            case CLUBS:
                return "梅花";
            case DIAMONDS:
                return "方片";
            default:
                break;
        }
        return null;
    }

    private String zhRankString() {

        if (rank.getValue() < RANK.TEN.getValue()) {
            return " " + rank.getValue();
        } else if (rank == RANK.TEN) {
            return rank.getValue() + "";
        } else if (rank == RANK.JACK) {
            return " J";
        } else if (rank == RANK.QUEEN) {
            return " Q";
        } else if (rank == RANK.KING) {
            return " K";
        } else if (rank == RANK.ACE) {
            return " A";
        }
        return null;
    }

    @Override
    public int compare(Card one, Card two) {

        int r = Integer.compare(one.getValue(), two.getValue());

        return r == 0 ? one.suit.compareTo(two.suit) : r;
    }

    @Override
    public int compareTo(Card card) {

        return compare(this, card);
    }

}
