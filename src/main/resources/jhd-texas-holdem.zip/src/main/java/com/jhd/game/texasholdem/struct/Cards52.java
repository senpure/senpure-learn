package com.jhd.game.texasholdem.struct;


import com.jhd.game.texasholdem.util.CardUtil;
import com.jhd.game.texasholdem.util.Cardsable;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * TODO：52张牌
 * 
 * @author 罗中正
 * @version 1.0
 */
public class Cards52 implements Cardsable {

	public Cards52() {
		super();
		this.cards = CardUtil.generateTexasPokerCards();
		removes = new ArrayList<>(52);
	}

	private List<Card> cards, removes;

	public List<Card> getCards() {
		return cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	@Override
	public Card dealOneCard() {

		return dealCards(1).get(0);
	}

	@Override
	public List<Card> currentCards() {

		return cards;
	}

	@Override
	public List<Card> dealCards(int count) {

		List<Card> cs = new ArrayList<>(count);

		for (int  j = 0; j < count; ) {

			Card rCard = cards.remove(0);
			cs.add(rCard);
			removes.add(rCard);
		
			j++;
		}
		return cs;
	}

	@Override
	public void shuffle() {

		CardUtil.shuffle(cards);

	}

	@Override
	public void prepareNextTime() {
		cards.addAll(removes);
		removes.clear();
		CardUtil.shuffle(cards);

	}

}
