package com.jhd.game.texasholdem.struct;

import com.jhd.game.texasholdem.bean.Player;

/**
 * Created by 罗中正 on 2017/8/23.
 */
public class DeskPlayer extends Player {


}
