package com.jhd.game.texasholdem.struct;

/**
 * 
 * TODO：德州扑克牌型
 * 
 * @author 罗中正
 * @version 1.0
 */
public enum TEXAS_POKER_TYPE {

 HIGH_CARD, PAIR_CARD, TWO_PAIRS_CARD, THREE_CARD, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH

}
