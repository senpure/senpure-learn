package com.jhd.game.texasholdem.struct;

import org.springframework.util.Assert;

import java.util.List;

/**
 * 要求牌的排列顺序为从大大小<br>
 * <b>皇家同花顺</b> 10JQKA <b>同花顺 </b> 78910JQ ,A12345 <b>4条 </b> 44442, 5555A <br>
 * <b>葫芦</b> 22233 ,9991010 ,AAA33 , 444AA <b>同花 </bK4321 ,AJ1095 <br>
 * <b>顺子 </b>A12345, 23456 ,78910J <b>3条</b> 2223A ,88824 <b>2对</b> 88772, AA22K <br>
 * <b>1对 </b>88A21,77KJ10 <b>高牌 </b>109852 ，AJ1093
 * 
 * @author 罗中正
 * @version 1.0
 */
public class TexasPoker5Cards {

	private List<Card> cards;
	private TEXAS_POKER_TYPE type;

	public TexasPoker5Cards(List<Card> cards, TEXAS_POKER_TYPE type) {
		super();
		Assert.isTrue(cards != null && cards.size() == 5 && type != null, "不是德州扑克，要求5张牌");
		this.cards = cards;
		this.type = type;
	}

	public List<Card> getCards() {
		return cards;
	}

	public TEXAS_POKER_TYPE getType() {

		return type;
	}

	public void setType(TEXAS_POKER_TYPE type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return cards.toString() + " "+type;
	}

	public String show() {

		String cards = "";
		for (Card card : this.cards) {
			cards += card.show();
		}
		return cards;
	}

}
