package com.jhd.game.texasholdem.util;


import com.jhd.game.texasholdem.struct.Card;
import com.jhd.game.texasholdem.struct.Card.RANK;
import com.jhd.game.texasholdem.struct.Card.SUIT;
import com.jhd.game.texasholdem.struct.TEXAS_POKER_TYPE;
import com.jhd.game.texasholdem.struct.TexasPoker5Cards;
import org.springframework.util.Assert;

import java.util.*;
import java.util.Map.Entry;

public class CardUtil {

    /**
     * 不含大小王的全新扑克
     *
     * @return
     */
    public static List<Card> generateTexasPokerCards() {
        List<Card> cards = new ArrayList<Card>(52);
        Card.RANK ranks[] = Card.RANK.values();
        for (Card.RANK rank : ranks) {
            cards.add(new Card(Card.SUIT.SPADES, rank));
            cards.add(new Card(Card.SUIT.HEARTS, rank));
            cards.add(new Card(Card.SUIT.DIAMONDS, rank));
            cards.add(new Card(Card.SUIT.CLUBS, rank));
        }
        return cards;
    }

    /**
     * 洗牌
     *
     * @param cards
     * @return
     */
    public static List<Card> shuffle(List<Card> cards) {
        Collections.shuffle(cards);
        return cards;
    }

    public static Cardsable shuffle(Cardsable cardsable) {
        Collections.shuffle(cardsable.currentCards());
        return cardsable;
    }

    public static Card dealOneCard(Cardsable cardsable) {
        return cardsable.dealOneCard();
    }

    /**
     * 洗好一副德州扑克的牌
     *
     * @return
     */
    public static List<Card> shuffleTexasPoker() {
        return shuffle(generateTexasPokerCards());
    }

    /**
     * 给牌排序，从小到大
     */
    public static List<Card> sort(List<Card> cards) {
        Collections.sort(cards);

        return cards;
    }

    public static List<Card> sortDesc(List<Card> cards) {
        Collections.sort(cards, desc);
        return cards;
    }

    /**
     * 排序德州扑克
     *
     * @param texasPoker5Cards
     * @return
     */
    public static List<TexasPoker5Cards> sortTexas(List<TexasPoker5Cards> texasPoker5Cards) {

        int size = texasPoker5Cards.size();
        for (int i = 0; i < size - 1; i++) {
            for (int j = i + 1; j < size; j++) {

                TexasPoker5Cards out = texasPoker5Cards.get(i);
                TexasPoker5Cards inner = texasPoker5Cards.get(j);
                if (compare(out, inner) > 0) {
                    texasPoker5Cards.set(j, texasPoker5Cards.set(i, inner));
                }
            }

        }

        return texasPoker5Cards;
    }

    public static boolean  isPair(Card one,Card two)
    {
        return  one.getValue()==two.getValue();
    }
    public static TexasPoker5Cards texasPoker(List<Card> cards) {
        sort(cards);
        // 顺子
        List<Card> c = get5Straight(cards);
        if (c != null) {
            if (isFlush(c)) {
                // 皇家同花顺
                if (c.get(4).getRank() == RANK.ACE) {
                    return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.ROYAL_FLUSH);
                } else {
                    // 同花顺
                    return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.STRAIGHT_FLUSH);
                }
            }
            // 可能和其他牌型有冲突
            // return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.STRAIGHT);
        }
        // 4条
        c = get5FourOfAKind(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.FOUR_OF_A_KIND);
        }
        // 葫芦
        c = getFullHouse(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.FULL_HOUSE);
        }
        // 同花
        c = get5Flush(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.FLUSH);
        }
        // 顺子
        c = get5Straight(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.STRAIGHT);
        }
        // 3条
        c = get5ThreeCard(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.THREE_CARD);
        }
        // 2对
        c = get5TwoPairsCard(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.TWO_PAIRS_CARD);
        }
        // 1对
        c = get5PairCard(cards);
        if (c != null) {
            return new TexasPoker5Cards(c, TEXAS_POKER_TYPE.PAIR_CARD);
        }
        // 高牌
        List<Card> high = new ArrayList<>();
        int size = cards.size();
        for (int j = size - 1; j > size - 6; j--) {
            high.add(cards.get(j));
        }
        return new TexasPoker5Cards(high, TEXAS_POKER_TYPE.HIGH_CARD);
    }

    /**
     * 是否是同花
     */
    public static boolean isFlush(List<Card> cards) {
        Card.SUIT suit = cards.get(0).getSuit();
        int size = cards.size();
        for (int i = 1; i < size; i++) {
            if (cards.get(i).getSuit() != suit) {
                return false;
            }
        }
        return true;
    }

    /**
     * 检查是否是5张或5张以上的牌,以免测试的时候的疏漏
     */
    private static void checkCardsUp5(List<Card> cards) {
        Assert.isTrue(cards != null && cards.size() >= 5, "牌数不足5张");
    }

    public static List<Card> get5TwoPairsCard(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);

        Map<RANK, List<Card>> map = rankCard(cards);
        List<Card> onePair = getSameCards(map, 2, false, 0);
        if (onePair == null) {
            return null;
        }
        for (int index = onePair.size() - 1; index > 1; index--) {
            onePair.remove(index);
        }
        int ov = onePair.get(0).getValue();
        List<Card> onePair2 = getSameCards(map, 2, false, ov);
        if (onePair2 == null) {
            return null;
        }
        for (int index = onePair2.size() - 1; index > 1; index--) {
            onePair2.remove(index);
        }
        onePair.addAll(onePair2);
        for (int size = cards.size(), i = size - 1; i > -1; i--) {
            Card c = cards.get(i);
            if (c.getValue() != ov && c.getValue() != onePair2.get(0).getValue()) {
                onePair.add(c);
                break;
            }
        }
        return onePair;
    }

    /**
     * <b>请确定没有比一对更大的牌了<b>
     */
    public static List<Card> get5PairCard(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);
        Map<RANK, List<Card>> map = rankCard(cards);
        List<Card> onePair = getSameCards(map, 2, false, 0);
        if (onePair == null) {
            return null;
        }
        for (int index = onePair.size() - 1; index > 1; index--) {
            onePair.remove(index);
        }
        int ov = onePair.get(0).getValue();
        List<Card> three = new ArrayList<>(3);
        int index = cards.size() - 1;
        do {
            Card c = cards.get(index--);
            if (c.getValue() != ov) {
                three.add(c);
            }
        } while (three.size() < 3);
        onePair.addAll(sortDesc(three));
        return onePair;
    }

    /**
     * 5554432 > 55534<br>
     * 55554432 > 55534
     */
    public static List<Card> get5ThreeCard(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);
        List<Card> three = getSameCards(cards, 3, false, 0);
        if (three == null) {
            return null;
        }
        for (int index = three.size() - 1; index > 2; index--) {
            three.remove(index);
        }
        RANK t = three.get(0).getRank();
        Card big = null;
        Card min = null;
        int size = cards.size();
        int index = size - 1;
        for (; index > -1; index--) {
            Card c = cards.get(index);
            if (c.getRank() != t) {
                big = c;
                break;
            }
        }
        for (; index > -1; index--) {
            Card c = cards.get(index);
            if (c.getRank() != t && c.getRank() != big.getRank()) {
                min = c;

                break;
            }
        }
        three.add(big);
        three.add(min);

        return three;
    }

    public static List<Card> getFullHouse(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);
        Map<RANK, List<Card>> map = rankCard(cards);
        List<Card> three = null;
        three = getSameCards(map, 3, false, 0);
        if (three == null) {
            return null;
        }
        //剩三张
        for (int index = three.size() - 1; index > 2; index--) {
            three.remove(index);
        }
        List<Card> onePair = getSameCards(map, 2, false, three.get(0).getRank().getValue());
        if (onePair == null) {
            return null;
        }
        for (int index = onePair.size() - 1; index > 1; index--) {
            onePair.remove(index);
        }
        three.addAll(onePair);
        return three;
    }

    /**
     * 23457A >3457A 234567K >4567K
     *
     * @param cards
     * @return
     */
    public static List<Card> get5Flush(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);
        Map<SUIT, List<Card>> map = suitCard(cards);
        List<Card> temp = null;
        int point = 0;
        List<Card> cList = null;

        SUIT[] ss = SUIT.values();
        for (SUIT s : ss) {
            temp = map.get(s);
            int tsize = temp == null ? 0 : temp.size();
            if (tsize >= 5) {
                int tp = temp.get(tsize - 1).getRank().getValue();
                if (tp > point) {
                    point = tp;
                    cList = temp;
                }
            }
        }
        if (cList == null) {
            return null;
        }
        List<Card> straightCards = new ArrayList<>(5);
        // 取最后5张牌
        int size = cList.size();
        for (int j = size - 5; j < size; j++) {
            straightCards.add(cList.get(j));
        }

        return sortDesc(straightCards);
    }

    /**
     * 相同点数的牌只保留一张
     *
     * @param cards
     * @return
     */
    public static List<Card> getRemoveDuplicate(List<Card> cards) {
        List<Card> dCards = new ArrayList<>();
        Set<RANK> rank = new HashSet<>();
        for (Card card : cards) {

            if (rank.add(card.getRank())) {
                dCards.add(card);
            }
        }
        return dCards;
    }


    /**
     * @param cards
     * @return 是顺子的话返回5张最大的顺子
     */
    public static List<Card> get5Straight(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);
        List<Card> dCards = getRemoveDuplicate(cards);
        int size = dCards.size();
        if (size < 5) {
            return null;
        }
        int index = -1;
        int index2 = -1;
        int count = 1;
        int count2 = 1;
        int rank = cards.get(0).getRank().getValue();
        boolean first = true;
        for (int i = 1; i < size; i++) {
            if (dCards.get(i).getRank().getValue() == ++rank) {

                if (first) {
                    count++;
                    index = i;
                } else {
                    count2++;
                    index2 = i;
                    if (count2 >= 5) {
                        count = count2;
                        index = index2;
                    }
                }
            }
            // 剩下的牌不够5张
            else if (size - i < 5) {
                break;
            } else {
                rank = dCards.get(i).getRank().getValue();
                first = false;
                count2 = 1;
                index2 = -1;
            }
        }
        if (count >= 5) {
            List<Card> straightCards = new ArrayList<>(5);
            for (int j = index - 4; j <= index; j++) {
                straightCards.add(dCards.get(j));
            }
            return straightCards;
        }
        // a12345
        if (dCards.get(size - 1).getRank() == RANK.ACE && dCards.get(0).getRank() == RANK.TWO
                && dCards.get(1).getRank() == RANK.THREE && dCards.get(2).getRank() == RANK.FOUR
                && dCards.get(3).getRank() == RANK.FIVE) {
            List<Card> straightCards = new ArrayList<>(5);
            straightCards.add(dCards.get(size - 1));
            straightCards.add(dCards.get(0));
            straightCards.add(dCards.get(1));
            straightCards.add(dCards.get(2));
            straightCards.add(dCards.get(3));
            return straightCards;
        }
        return null;
    }

    public static List<Card> get5FourOfAKind(List<Card> cards) {
        checkCardsUp5(cards);
        sort(cards);
        Map<RANK, List<Card>> map = rankCard(cards);
        List<Card> four = null;
        int point = 0;
        Iterator<Entry<RANK, List<Card>>> it = map.entrySet().iterator();
        int size = cards.size();
        RANK big = null;
        // 找出最大的四条
        while (it.hasNext()) {
            Map.Entry<RANK, List<Card>> entry = it.next();
            List<Card> cs = entry.getValue();
            if (cs.size() == 4) {
                RANK tr = entry.getKey();
                if (tr.getValue() > point) {
                    point = tr.getValue();
                    four = cs;
                    big = tr;
                }
            }
        }
        if (four != null) {
            for (int i = size - 1; i > -1; i--) {
                Card c = cards.get(i);
                if (c.getRank() != big) {
                    four.add(c);
                    break;
                }
            }
        }
        return four;
    }

    private static List<Card> getSameCards(List<Card> cards, int count, boolean only, int outValue) {
        return getSameCards(rankCard(cards), count, only, outValue);
    }

    /**
     * @param map
     * @param count
     * @param only  刚好这么多张
     * @return
     */
    private static List<Card> getSameCards(Map<RANK, List<Card>> map, int count, boolean only, int outValue) {
        List<Card> temp = null;
        int point = 0;
        Iterator<Entry<RANK, List<Card>>> it = map.entrySet().iterator();
        // 找出最大相同牌
        while (it.hasNext()) {
            Map.Entry<RANK, List<Card>> entry = it.next();
            List<Card> cs = entry.getValue();
            if (only ? cs.size() == count : cs.size() >= count) {
                RANK tr = entry.getKey();
                if (tr.getValue() != outValue && tr.getValue() > point) {
                    point = tr.getValue();
                    temp = cs;
                }
            }
        }
        return temp;
    }

    /**
     * 点数相同的牌
     */
    private static Map<RANK, List<Card>> rankCard(List<Card> cards) {
        Map<RANK, List<Card>> map = new HashMap<RANK, List<Card>>();
        Card c = null;
        List<Card> rankList = null;
        for (int i = 0; i < cards.size(); i++) {
            c = cards.get(i);
            rankList = map.get(c.getRank());
            if (rankList == null) {
                rankList = new ArrayList<Card>();
            }
            rankList.add(c);
            map.put(c.getRank(), rankList);
        }
        return map;
    }

    /**
     * 花色相同的牌
     *
     * @param cards
     * @return
     */
    private static Map<SUIT, List<Card>> suitCard(List<Card> cards) {
        Map<SUIT, List<Card>> map = new HashMap<SUIT, List<Card>>();
        Card c = null;
        List<Card> suitList = null;
        for (int i = 0; i < cards.size(); i++) {
            c = cards.get(i);
            suitList = map.get(c.getSuit());
            if (suitList == null) {
                suitList = new ArrayList<Card>();
            }
            suitList.add(c);
            map.put(c.getSuit(), suitList);
        }
        return map;
    }

    /**
     * one > two 1<br>
     * one ==two 0 <br>
     * one < two -1
     *
     * @param one
     * @param two
     * @return
     */
    public static int compare(TexasPoker5Cards one, TexasPoker5Cards two) {
        TEXAS_POKER_TYPE otype = one.getType();
        if (otype == two.getType()) {
            switch (otype) {
                case ROYAL_FLUSH:
                    return 0;
                // 依次从大比到小

                case STRAIGHT:
                case STRAIGHT_FLUSH:
                    int cs = 0;
                    for (int i = 4; i > -1; i--) {
                        cs = Integer.compare(one.getCards().get(i).getValue(), two.getCards().get(i).getValue());
                        if (cs != 0) {
                            break;
                        }
                    }
                    return cs;
                case HIGH_CARD:

                case FLUSH:

                    int c = 0;
                    for (int i = 0; i < 5; i++) {
                        c = Integer.compare(one.getCards().get(i).getValue(), two.getCards().get(i).getValue());
                        if (c != 0) {
                            break;
                        }
                    }
                    return c;
                case TWO_PAIRS_CARD:
                    List<Card> os = one.getCards();
                    List<Card> ts = two.getCards();
                    int compare = Integer.compare(os.get(0).getValue(), ts.get(0).getValue());
                    if (compare != 0) {
                        return compare;
                    }
                    compare = Integer.compare(os.get(2).getValue(), ts.get(2).getValue());
                    if (compare != 0) {
                        return compare;
                    }
                    return Integer.compare(os.get(4).getValue(), ts.get(4).getValue());
                case PAIR_CARD:
                    int cp = Integer.compare(one.getCards().get(0).getValue(), two.getCards().get(0).getValue());
                    if (cp != 0) {
                        return cp;
                    }
                    for (int i = 2; i < 5; i++) {
                        cp = Integer.compare(one.getCards().get(i).getValue(), two.getCards().get(i).getValue());
                        if (cp != 0) {
                            break;
                        }
                    }
                    return cp;
                case FULL_HOUSE:
                case FOUR_OF_A_KIND:
                    int cf = Integer.compare(one.getCards().get(0).getValue(), two.getCards().get(0).getValue());

                    if (cf != 0) {
                        return cf;
                    }
                    cf = Integer.compare(one.getCards().get(4).getValue(), two.getCards().get(4).getValue());
                    return cf;
                case THREE_CARD:

                    int ct = Integer.compare(one.getCards().get(0).getValue(), two.getCards().get(0).getValue());
                    if (ct != 0) {
                        return ct;
                    }
                    for (int i = 3; i < 5; i++) {
                        ct = Integer.compare(one.getCards().get(i).getValue(), two.getCards().get(i).getValue());
                        if (ct != 0) {
                            break;
                        }
                    }
                    return ct;
                default:
                    break;
            }
        }
        return Integer.compare(one.getType().ordinal(), two.getType().ordinal());
    }

    public static List<Card> getCards(String cardsStr) {
        int l = cardsStr.length();
        List<Card> cards = new ArrayList<>();
        SUIT suit = null;
        RANK rank = null;
        SUIT[] suits = SUIT.values();
        for (int i = 0; i < l; i++) {
            if (i % 2 == 0) {
                for (SUIT suit2 : suits) {

                    if (Integer.valueOf(cardsStr.charAt(i) + "") == suit2.ordinal()) {
                        suit = suit2;
                    }
                }
            } else {

                rank = RANK.getRank(Integer.valueOf(cardsStr.charAt(i) + "", 16));
            }

            if ((i - 1) % 2 == 0) {
                cards.add(new Card(suit, rank));

            }
        }
        return cards;
    }

    private static Comparator<Card> desc = new Comparator<Card>() {

        public int compare(Card one, Card two) {

            int r = Integer.compare(two.getValue(), one.getValue());

            return r == 0 ? two.getSuit().compareTo(one.getSuit()) : r;
        }

    };
    private static Comparator<TEXAS_POKER_TYPE> texasComparator = new Comparator<TEXAS_POKER_TYPE>() {

        @Override
        public int compare(TEXAS_POKER_TYPE o1, TEXAS_POKER_TYPE o2) {

            return compare(o1, o2);
        }
    };


}
