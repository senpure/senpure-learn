package com.jhd.game.texasholdem.util;


import com.jhd.game.texasholdem.struct.Card;

import java.util.List;

public interface Cardsable {
	Card dealOneCard();
	List<Card> dealCards(int count);
	List<Card> currentCards();
	/**
	 * 洗牌
	 */
	void shuffle();
	void prepareNextTime();

}
