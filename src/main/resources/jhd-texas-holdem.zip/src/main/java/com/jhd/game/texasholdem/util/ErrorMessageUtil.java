package com.jhd.game.texasholdem.util;

import com.jhd.game.message.SCServerErrorMessage;
import com.senpure.base.result.ResultHelper;
import io.netty.channel.Channel;

import java.util.Locale;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public class ErrorMessageUtil {

    public static void pushMessage(Channel channel, int code) {

        Locale locale = Locale.CHINESE;
        SCServerErrorMessage message = new SCServerErrorMessage();
        message.setCode(code);
        message.setMesssage(ResultHelper.getMessage(code, locale));
        channel.writeAndFlush(message);

    }

    public static void pushMessage(int playerId, int code) {
        Channel channel = ChannelUtil.getChannel(playerId);
        if (channel != null) {

            pushMessage(channel, code);
        }

    }
}
