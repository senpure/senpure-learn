package com.jhd.store;


import com.senpure.base.generator.Config;
import com.senpure.base.generator.MybatisGenerator;

/**
 * Created by 罗中正 on 2017/10/10.
 */
public class MybatisCodeGenerator {
    public static void main(String[] args) {


        MybatisGenerator mybatisGenerator = new MybatisGenerator();
        Config config = new Config();

        config.setAllCover(true);
        config.setSingleCheck(true);
        config.addCoverCofig("Student", false);
        mybatisGenerator.generator("com.jhd.store", config);
    }
}
