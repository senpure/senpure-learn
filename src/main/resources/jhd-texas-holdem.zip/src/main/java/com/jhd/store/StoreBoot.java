package com.jhd.store;

import com.senpure.base.util.BannerShow;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by 罗中正 on 2017/8/23.
 */
@SpringBootApplication
public class StoreBoot {


        public static void main(String[] args) {

            AnsiConsole.systemInstall();
            AnsiConsole.systemUninstall();
            SpringApplication application = new SpringApplication(StoreBoot.class);
            application.setBannerMode(Banner.Mode.LOG);
            application.run(args);
            BannerShow.show();
        }

}
