package com.jhd.store;

/**
 * Created by 罗中正 on 2017/8/23.
 */
public class StoreConstant {
  public static  final  String  DATA_BASE_PREFIX="GAME";
  public static final String PLAYER_ID_SEQUENCE_TYPE="PLAYER_ID_SEQUENCE";
  public static  int PLAYER_ID_SEQUENCE_START_VALUE=10000;

  public static  int PLAYER_SESSION_TIME_OUT=1000*60*5;
  public static enum ACCOUNT_TYPE{
    WECHAT,
    VISITOR
  }
}
