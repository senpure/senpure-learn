package com.jhd.store.configuration;


import com.senpure.base.configuration.BaseConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

/**
 * Created by 罗中正 on 2017/8/25.
 * 直接使用默认的注册，支持mybatis和jpa
 */

public class TransactionConfiguration extends BaseConfiguration implements TransactionManagementConfigurer {


    @Resource(name = "transactionManager")
    private PlatformTransactionManager jpa;


    @Bean(name = "transactionManager")
    public PlatformTransactionManager jpaTransactionManager(EntityManagerFactory entityManagerFactory) {
        PlatformTransactionManager platformTransactionManager=new JpaTransactionManager(entityManagerFactory);
       logger.debug("注册jpa 事务管理器 {}",platformTransactionManager);
        return platformTransactionManager;
    }

    @Override
    public PlatformTransactionManager annotationDrivenTransactionManager() {
        logger.debug("默认事务管理器 {}", jpa);
        return jpa;
    }
}
