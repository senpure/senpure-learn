package com.jhd.store.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.senpure.base.spring.BaseController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;


/**
 * Created by 罗中正 on 2017/8/24.
 */
public class ClientController  extends BaseController {
    protected Logger logger;

    public ClientController() {
        this.logger = LoggerFactory.getLogger(getClass());

    }

    public JSONObject josn(String clientJson) throws UnsupportedEncodingException {
        logger.debug("--- befor-clientJson:{}", clientJson);
        clientJson = URLDecoder.decode(clientJson, "utf-8");
        logger.debug("--- after -clientJson:{}", clientJson);
        if (clientJson.endsWith("=")) {
            clientJson = clientJson.substring(0, clientJson.length() - 1);
            logger.debug("--- after -clientJson:{}", clientJson);
        }
        JSONObject jsonObject = JSON.parseObject(clientJson);
        return jsonObject;
    }
}
