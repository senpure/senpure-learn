package com.jhd.store.controller;

import com.alibaba.fastjson.JSONObject;
import com.jhd.store.service.PlayerService;
import com.jhd.store.struct.LoginArgs;
import com.senpure.base.init.IPGeter;
import com.senpure.base.result.ResultHelper;
import com.senpure.base.result.ResultMap;
import com.senpure.base.util.Http;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

/**
 * Created by 罗中正 on 2017/8/24.
 */
@Controller
@RequestMapping(value = "/game")
public class PlayerLoginController extends ClientController {

    @Autowired
    private PlayerService playerService;

    @RequestMapping("/login")
    @ResponseBody
    public Object playerLogin(HttpServletRequest request, @RequestBody(required = false) String clientJson) {

        try {
            JSONObject json = josn(clientJson);
            LoginArgs loginArgs = new LoginArgs();
            loginArgs.setIpChian(Http.getIP(request));
            loginArgs.setIp(Http.getIP(loginArgs.getIpChian(), true));
            loginArgs.setIpNum(Http.ipToLong(loginArgs.getIp()));

            loginArgs.setAccount(json.getString("account"));
            loginArgs.setType(json.getString("type"));

            String token = playerService.playerToken(loginArgs);
            ResultMap resultMap = ResultMap.success();
            resultMap.put("token", token);
            resultMap.put("ip", IPGeter.getIp());
            resultMap.put("port", 1111);
            return resultMap;

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        ResultMap resultMap = ResultMap.dim();
        ResultHelper.wrapMessage(resultMap, localeResolver.resolveLocale(request));
        return resultMap;
    }
}
