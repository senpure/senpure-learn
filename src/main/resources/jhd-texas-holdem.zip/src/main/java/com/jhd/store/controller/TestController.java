package com.jhd.store.controller;


import com.senpure.base.AppEvn;
import com.senpure.base.result.ResultHelper;
import com.senpure.base.result.ResultMap;
import com.senpure.base.spring.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by 罗中正 on 2017/8/24.
 */
@Controller
public class TestController extends BaseController {

    @RequestMapping("/store/test")
    @ResponseBody
    public ResultMap home(HttpServletRequest request) {

        ResultMap resultMap = ResultMap.dim();

        resultMap.put("location", AppEvn.getCallerPath());
        resultMap.put("path", request.getServletContext().getRealPath(""));


        logger.debug(localeResolver.toString());
        ResultHelper.wrapMessage(resultMap, getLocaleResolver().resolveLocale(request));
        return resultMap;
    }
}
