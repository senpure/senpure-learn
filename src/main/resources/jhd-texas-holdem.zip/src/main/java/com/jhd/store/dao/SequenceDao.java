package com.jhd.store.dao;


import com.jhd.store.entity.Sequence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 罗中正 on 2017/3/31.
 */
@Repository
public interface SequenceDao extends JpaRepository<Sequence,Integer> {

    public Sequence findSequenceByType(String type);



}
