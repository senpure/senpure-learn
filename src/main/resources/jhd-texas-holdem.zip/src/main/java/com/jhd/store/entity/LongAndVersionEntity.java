package com.jhd.store.entity;

/**
 * Created by 罗中正 on 2017/8/25.
 */
public class LongAndVersionEntity extends  VersionEntity {
}
