package com.jhd.store.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * Created by 罗中正 on 2017/8/25.
 */
@MappedSuperclass
public class LongEntity {
    @Id
    @GenericGenerator(name="idGenerator", strategy="com.jhd.store.util.IDGeneratorHibernate")
    @GeneratedValue(generator="idGenerator")
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
