package com.jhd.store.entity;

import com.jhd.store.StoreConstant;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/8/23.
 */
@Entity
@Table(name = StoreConstant.DATA_BASE_PREFIX+"_Player")
public class Player  {
    @Id
    @GenericGenerator(name = "hibernate", strategy = "assigned")
    private Integer id;
    @Version
    @Column(nullable = false)
    private Integer version;


    @Column(nullable = false)
    private String nick;
    @Column(nullable = false,length = 255)
    private String head;
    @Column(nullable = false,length = 12)
    private Boolean online=false;
    @Column
    private String loginType;
    private String logoutType;
    private Long loginTime;
    private Date loginDate;
    private Long logoutTime;
    private Date logoutDate;
    private String loginIP;
    private String lastLoginIP;
    @Column(nullable = true,length = 32)
    private String loginSession;
    private Long loginSessionTime;
    private Date loginSessionDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public Boolean getOnline() {
        return online;
    }

    public void setOnline(Boolean online) {
        this.online = online;
    }

    public String getLoginType() {
        return loginType;
    }

    public void setLoginType(String loginType) {
        this.loginType = loginType;
    }

    public String getLogoutType() {
        return logoutType;
    }

    public void setLogoutType(String logoutType) {
        this.logoutType = logoutType;
    }

    public Long getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Long loginTime) {
        this.loginTime = loginTime;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public void setLoginDate(Date loginDate) {
        this.loginDate = loginDate;
    }

    public Long getLogoutTime() {
        return logoutTime;
    }

    public void setLogoutTime(Long logoutTime) {
        this.logoutTime = logoutTime;
    }

    public Date getLogoutDate() {
        return logoutDate;
    }

    public void setLogoutDate(Date logoutDate) {
        this.logoutDate = logoutDate;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public void setLoginIP(String loginIP) {
        this.loginIP = loginIP;
    }

    public String getLastLoginIP() {
        return lastLoginIP;
    }

    public void setLastLoginIP(String lastLoginIP) {
        this.lastLoginIP = lastLoginIP;
    }

    public String getLoginSession() {
        return loginSession;
    }

    public void setLoginSession(String loginSession) {
        this.loginSession = loginSession;
    }

    public Long getLoginSessionTime() {
        return loginSessionTime;
    }

    public void setLoginSessionTime(Long loginSessionTime) {
        this.loginSessionTime = loginSessionTime;
    }

    public Date getLoginSessionDate() {
        return loginSessionDate;
    }

    public void setLoginSessionDate(Date loginSessionDate) {
        this.loginSessionDate = loginSessionDate;
    }


    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}
