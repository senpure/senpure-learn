package com.jhd.store.entity;

import com.jhd.store.StoreConstant;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/3/30.
 */
@Entity
@Table(name = StoreConstant.DATA_BASE_PREFIX + "_Player_Account")
public class PlayerAccount extends LongEntity{

    @Column(nullable = false)
    private Integer playerId;
    private String type;
    @Column(nullable = false, length = 128)
    private String account;
    private Long bindTime;
    private Date bindDate;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public Long getBindTime() {
        return bindTime;
    }

    public void setBindTime(Long bindTime) {
        this.bindTime = bindTime;
    }

    public Date getBindDate() {
        return bindDate;
    }

    public void setBindDate(Date bindDate) {
        this.bindDate = bindDate;
    }

    public Integer getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Integer playerId) {
        this.playerId = playerId;
    }
}
