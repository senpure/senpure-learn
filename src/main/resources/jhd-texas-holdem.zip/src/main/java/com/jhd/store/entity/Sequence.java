package com.jhd.store.entity;


import com.jhd.store.StoreConstant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Version;


@Entity
@Table(name = StoreConstant.DATA_BASE_PREFIX+"_Sequence")
public class Sequence extends SnowflakeEntity {
    private static final long serialVersionUID = 849244885236870774L;
    @Version
    @Column(nullable = false)
    private Integer version;
    @Column
    //前缀
    private String prefix="";
    @Column
   // 后缀
    private String suffix="";
    @Column
    private Integer sequence=1;
    @Column
    private Integer digit=6;
    @Column
    private Integer span=1;
    @Column
    private String type;

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public int getDigit() {
        return digit;
    }

    public void setDigit(int digit) {
        this.digit = digit;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSpan() {
        return span;
    }

    public void setSpan(int span) {
        this.span = span;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }
}
