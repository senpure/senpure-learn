package com.jhd.store.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * Created by 罗中正 on 2017/9/5.
 */
@MappedSuperclass
public class SnowflakeEntity {
    @Id
    @GenericGenerator(name="idGenerator", strategy="com.jhd.store.util.IDGeneratorHibernate")
    @GeneratedValue(generator="idGenerator")
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
