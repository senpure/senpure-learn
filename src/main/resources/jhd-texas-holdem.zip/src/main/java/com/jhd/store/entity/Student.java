package com.jhd.store.entity;

import com.jhd.store.StoreConstant;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/8/23.
 */
@Entity
@Table(name = StoreConstant.DATA_BASE_PREFIX+"_Student")
public class Student  extends IntAndVersionEntity {
    private static final long serialVersionUID = -8147043031044860016L;
    private String name;
    private int age;
    private String userName;
    private Date date;
    private long time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }
}
