package com.jhd.store.entity;

import com.jhd.store.StoreConstant;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by 罗中正 on 2017/8/23.
 */
@Entity
@Table(name = StoreConstant.DATA_BASE_PREFIX+"_Student2")
public class Student2 extends VersionEntity {
    @Id
    @GenericGenerator(name="idGenerator", strategy="com.jhd.store.util.IDGeneratorHibernate")
    @GeneratedValue(generator="idGenerator")
    private Long id;
    private static final long serialVersionUID = -8147043031044860016L;
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
