package com.jhd.store.init;

import com.jhd.store.service.PlayerService;
import com.senpure.base.AppEvn;
import com.senpure.base.spring.SpringContextRefreshEvent;
import com.senpure.io.MessageHandlerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/8/25.
 */
@Component
public class PlayerOnlineSyncService extends SpringContextRefreshEvent {
    @Autowired
    private PlayerService playerService;
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {

        MessageHandlerUtil.execute(new Runnable() {
            @Override
            public void run() {
                logger.debug("====================={}",AppEvn.getClassRootPath());
            }
        });


    }
}
