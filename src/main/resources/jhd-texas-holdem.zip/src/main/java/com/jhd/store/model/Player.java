package com.jhd.store.model;
import java.io.Serializable;
import java.util.Date;
/**
* @author senpure-database
* @version 2017-10-10 17:21:55
*/
public class Player implements Serializable  {
private static final long serialVersionUID = 1507627315925L;

    private Integer id;
    private Integer version;
    private String nick;
    private String head;
    private Boolean online;
    private String loginType;
    private String logoutType;
    private Long loginTime;
    private Date loginDate;
    private Long logoutTime;
    private Date logoutDate;
    private String loginIP;
    private String lastLoginIP;
    private String loginSession;
    private Long loginSessionTime;
    private Date loginSessionDate;


    public Integer getId() {
        return id;
    }

    public Player setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getNick() {
        return nick;
    }

    public Player setNick(String nick) {
        this.nick = nick;
        return this;
    }

    public String getHead() {
        return head;
    }

    public Player setHead(String head) {
        this.head = head;
        return this;
    }

    public Boolean isOnline() {
        return online;
    }

    public Player setOnline(Boolean online) {
        this.online = online;
        return this;
    }

    public String getLoginType() {
        return loginType;
    }

    public Player setLoginType(String loginType) {
        this.loginType = loginType;
        return this;
    }

    public String getLogoutType() {
        return logoutType;
    }

    public Player setLogoutType(String logoutType) {
        this.logoutType = logoutType;
        return this;
    }

    public Long getLoginTime() {
        return loginTime;
    }

    public Player setLoginTime(Long loginTime) {
        this.loginTime = loginTime;
        return this;
    }

    public Date getLoginDate() {
        return loginDate;
    }

    public Player setLoginDate(Date loginDate) {
        this.loginDate = loginDate;
        return this;
    }

    public Long getLogoutTime() {
        return logoutTime;
    }

    public Player setLogoutTime(Long logoutTime) {
        this.logoutTime = logoutTime;
        return this;
    }

    public Date getLogoutDate() {
        return logoutDate;
    }

    public Player setLogoutDate(Date logoutDate) {
        this.logoutDate = logoutDate;
        return this;
    }

    public String getLoginIP() {
        return loginIP;
    }

    public Player setLoginIP(String loginIP) {
        this.loginIP = loginIP;
        return this;
    }

    public String getLastLoginIP() {
        return lastLoginIP;
    }

    public Player setLastLoginIP(String lastLoginIP) {
        this.lastLoginIP = lastLoginIP;
        return this;
    }

    public String getLoginSession() {
        return loginSession;
    }

    public Player setLoginSession(String loginSession) {
        this.loginSession = loginSession;
        return this;
    }

    public Long getLoginSessionTime() {
        return loginSessionTime;
    }

    public Player setLoginSessionTime(Long loginSessionTime) {
        this.loginSessionTime = loginSessionTime;
        return this;
    }

    public Date getLoginSessionDate() {
        return loginSessionDate;
    }

    public Player setLoginSessionDate(Date loginSessionDate) {
        this.loginSessionDate = loginSessionDate;
        return this;
    }

    public Integer getVersion() {
        return version;
    }

    public Player setVersion(Integer version) {
        this.version = version;
        return this;
    }

    /**
     * 用于数据库更新
     */
    public Integer getVersionUpdate() {
        return version + 1;
    }
    @Override
    public String toString() {
        return "Player{"
                + "id=" + id
                + ",nick=" + nick
                + ",head=" + head
                + ",online=" + online
                + ",loginType=" + loginType
                + ",logoutType=" + logoutType
                + ",loginTime=" + loginTime
                + ",loginDate=" + loginDate
                + ",logoutTime=" + logoutTime
                + ",logoutDate=" + logoutDate
                + ",loginIP=" + loginIP
                + ",lastLoginIP=" + lastLoginIP
                + ",loginSession=" + loginSession
                + ",loginSessionTime=" + loginSessionTime
                + ",loginSessionDate=" + loginSessionDate
                + ",version=" + version
                + "}";
    }

}