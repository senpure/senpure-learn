package com.jhd.store.model;
import java.io.Serializable;
import java.util.Date;
/**
* @author senpure-database
* @version 2017-10-10 17:21:55
*/
public class PlayerAccount implements Serializable  {
private static final long serialVersionUID = 1507627315827L;

    private int id;
    private Integer playerId;
    private String type;
    private String account;
    private Long bindTime;
    private Date bindDate;


    public int getId() {
        return id;
    }

    public PlayerAccount setId(int id) {
        this.id = id;
        return this;
    }

    public Integer getPlayerId() {
        return playerId;
    }

    public PlayerAccount setPlayerId(Integer playerId) {
        this.playerId = playerId;
        return this;
    }

    public String getType() {
        return type;
    }

    public PlayerAccount setType(String type) {
        this.type = type;
        return this;
    }

    public String getAccount() {
        return account;
    }

    public PlayerAccount setAccount(String account) {
        this.account = account;
        return this;
    }

    public Long getBindTime() {
        return bindTime;
    }

    public PlayerAccount setBindTime(Long bindTime) {
        this.bindTime = bindTime;
        return this;
    }

    public Date getBindDate() {
        return bindDate;
    }

    public PlayerAccount setBindDate(Date bindDate) {
        this.bindDate = bindDate;
        return this;
    }

    @Override
    public String toString() {
        return "PlayerAccount{"
                + "id=" + id
                + ",playerId=" + playerId
                + ",type=" + type
                + ",account=" + account
                + ",bindTime=" + bindTime
                + ",bindDate=" + bindDate
                + "}";
    }

}