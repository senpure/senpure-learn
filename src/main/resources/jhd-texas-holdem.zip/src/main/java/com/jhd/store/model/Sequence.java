package com.jhd.store.model;
import java.io.Serializable;
/**
* @author senpure-database
* @version 2017-10-10 17:21:55
*/
public class Sequence implements Serializable  {
private static final long serialVersionUID = 1507627315940L;

    private Long id;
    private Integer version;
    private String prefix;
    private String suffix;
    private Integer sequence;
    private Integer digit;
    private Integer span;
    private String type;


    public Long getId() {
        return id;
    }

    public Sequence setId(Long id) {
        this.id = id;
        return this;
    }

    public String getPrefix() {
        return prefix;
    }

    public Sequence setPrefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public String getSuffix() {
        return suffix;
    }

    public Sequence setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public Integer getSequence() {
        return sequence;
    }

    public Sequence setSequence(Integer sequence) {
        this.sequence = sequence;
        return this;
    }

    public Integer getDigit() {
        return digit;
    }

    public Sequence setDigit(Integer digit) {
        this.digit = digit;
        return this;
    }

    public Integer getSpan() {
        return span;
    }

    public Sequence setSpan(Integer span) {
        this.span = span;
        return this;
    }

    public String getType() {
        return type;
    }

    public Sequence setType(String type) {
        this.type = type;
        return this;
    }

    public Integer getVersion() {
        return version;
    }

    public Sequence setVersion(Integer version) {
        this.version = version;
        return this;
    }

    /**
     * 用于数据库更新
     */
    public Integer getVersionUpdate() {
        return version + 1;
    }
    @Override
    public String toString() {
        return "Sequence{"
                + "id=" + id
                + ",prefix=" + prefix
                + ",suffix=" + suffix
                + ",sequence=" + sequence
                + ",digit=" + digit
                + ",span=" + span
                + ",type=" + type
                + ",version=" + version
                + "}";
    }

}