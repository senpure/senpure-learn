package com.jhd.store.model;
import java.io.Serializable;
/**
* @author senpure-database
* @version 2017-10-10 17:21:55
*/
public class Student2 implements Serializable  {
private static final long serialVersionUID = 1507627315913L;

    private Long id;
    private int version;
    private String name;
    private int age;


    public Long getId() {
        return id;
    }

    public Student2 setId(Long id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Student2 setName(String name) {
        this.name = name;
        return this;
    }

    public int getAge() {
        return age;
    }

    public Student2 setAge(int age) {
        this.age = age;
        return this;
    }

    public int getVersion() {
        return version;
    }

    public Student2 setVersion(int version) {
        this.version = version;
        return this;
    }

    /**
     * 用于数据库更新
     */
    public int getVersionUpdate() {
        return version + 1;
    }
    @Override
    public String toString() {
        return "Student2{"
                + "id=" + id
                + ",name=" + name
                + ",age=" + age
                + ",version=" + version
                + "}";
    }

}