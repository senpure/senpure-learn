package com.jhd.store.service;

import com.jhd.store.entity.Player;

/**
 * Created by 罗中正 on 2017/8/25.
 */
public interface PlayerCacheService {

    public void put(String token, Player player) ;
    public void put(int id, Player player) ;
    Player get(String token);
    Player get(int  id);

    void remove(int id);

    void remove(String token);


}
