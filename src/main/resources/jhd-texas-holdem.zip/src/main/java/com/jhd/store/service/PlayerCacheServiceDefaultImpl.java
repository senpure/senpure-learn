package com.jhd.store.service;

import com.jhd.store.entity.Player;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentMap;

/**
 * Created by 罗中正 on 2017/8/25.
 */
@Service
public class PlayerCacheServiceDefaultImpl implements PlayerCacheService {

    private ConcurrentMap<String, Player> tokenMap = new java.util.concurrent.ConcurrentHashMap<>();
    private ConcurrentMap<Integer, Player> idMap = new java.util.concurrent.ConcurrentHashMap<>();

    @Override
    public void put(String token, Player player) {
        tokenMap.put(token, player);

    }

    @Override
    public void put(int id, Player player) {
        idMap.put(id, player);

    }

    @Override
    public Player get(String token) {
        return tokenMap.get(token);
    }

    @Override
    public Player get(int id) {
        return idMap.get(id);
    }

    @Override
    public void remove(int id) {
        Player player = idMap.remove(id);

        if (player != null) {
            tokenMap.remove(player.getLoginSession());
        }
    }

    @Override
    public void remove(String token) {
        Player player = tokenMap.remove(token);
        if (player != null) {

            idMap.remove(player.getId());
        }
    }

}
