package com.jhd.store.service;

import com.jhd.game.texasholdem.service.ServiceSupport;
import com.jhd.store.StoreConstant;
import com.jhd.store.dao.PlayerAccountDao;
import com.jhd.store.dao.PlayerDao;
import com.jhd.store.entity.Player;
import com.jhd.store.entity.PlayerAccount;
import com.jhd.store.struct.LoginArgs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Date;

/**
 * Created by 罗中正 on 2017/8/25.
 *
 *
 */
@Service
public class PlayerService extends ServiceSupport {

    @Autowired
    private PlayerAccountDao playerAccountDao;

    @Autowired
    private PlayerDao playerDao;
    @Autowired
    private SequenceService sequenceService;

    @Autowired
    private WeChatService weChatService;
    @Autowired
    PlayerCacheService playerCacheService;


    // private Map<String,Player>

    public Player playerLoginByToken(String token) {
        Player player = playerCacheService.get(token);

        return player;
    }

    @Transactional
    public String playerToken(LoginArgs args) {

        String loginSession = java.util.UUID.randomUUID().toString().replace("-", "");
        Date now = new Date();
        Player player = null;
        PlayerAccount playerAccount = null;
        if (args.getType().equalsIgnoreCase(StoreConstant.ACCOUNT_TYPE.WECHAT.toString())) {
            Player tempPlayer = new Player();
            PlayerAccount tempPalyerAccount = new PlayerAccount();
            if (weChatService.getWechatInfo(args.getAccount(), tempPlayer, tempPalyerAccount)) {
                playerAccount = playerAccountDao.findByTypeAndAccount(StoreConstant.ACCOUNT_TYPE.WECHAT.toString(), tempPalyerAccount.getAccount());
                if (playerAccount == null) {
                    player = newPlayer();
                    playerAccount = bindPlayerAccount(player.getId(), tempPalyerAccount.getAccount(), StoreConstant.ACCOUNT_TYPE.WECHAT.toString(), now);
                    playerAccountDao.save(playerAccount);
                } else {
                    player = playerDao.findOne(playerAccount.getPlayerId());
                    player.setHead(tempPlayer.getHead());
                    player.setNick(tempPlayer.getNick());

                }

            }
        } else {
            playerAccount = playerAccountDao.findByTypeAndAccount(StoreConstant.ACCOUNT_TYPE.VISITOR.toString(), args.getAccount());
            if (playerAccount == null) {
                player = newPlayer();
                playerAccount = bindPlayerAccount(player.getId(), args.getAccount(), StoreConstant.ACCOUNT_TYPE.VISITOR.toString(), now);
                playerAccountDao.save(playerAccount);
            } else {
                player = playerDao.findOne(playerAccount.getPlayerId());
            }


        }

        player.setOnline(true);
        player.setLoginSession(loginSession);
        player.setLoginSessionDate(now);
        player.setLoginSessionTime(now.getTime());
        playerDao.save(player);
        playerCacheService.put(loginSession, player);
        playerCacheService.put(player.getId(), player);
        return loginSession;
    }


    public PlayerAccount bindPlayerAccount(int playerId, String account, String type, Date date) {
        PlayerAccount playerAccount = new PlayerAccount();
        playerAccount.setAccount(account);
        playerAccount.setType(type);
        playerAccount.setPlayerId(playerId);
        playerAccount.setBindDate(date);
        playerAccount.setBindTime(date.getTime());
        return playerAccount;

    }

    public Player newPlayer() {

        int playerId = sequenceService.nextSequenceNum(StoreConstant.PLAYER_ID_SEQUENCE_TYPE);
        Player player = new Player();
        player.setId(playerId);
        player.setNick("玩家[" + playerId + "]");
        player.setHead("1");
        return player;
    }
}
