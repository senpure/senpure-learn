package com.jhd.store.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jhd.game.texasholdem.service.ServiceSupport;
import com.jhd.store.entity.Player;
import com.jhd.store.entity.PlayerAccount;
import com.senpure.base.util.HttpsConnect;
import org.springframework.stereotype.Service;

/**
 * Created by 罗中正 on 2017/5/2.
 */
@Service
public class WeChatService extends ServiceSupport {

    protected String weChatAppId = "wxe61c486ef1bca73f";
    protected String weChatAppSecret = "3e97fb435a2db283fdb620175cbb8734";
    public  boolean getWechatInfo(String code, Player player, PlayerAccount playerAccount) {

        StringBuilder sb = new StringBuilder();
        sb.append("https://api.weixin.qq.com/sns/oauth2/access_token?");
        sb.append("appid=").append(weChatAppId).append("&");
        sb.append("secret=").append(weChatAppSecret).append("&");
        sb.append("code=").append(code).append("&");
        sb.append("grant_type=authorization_code");

        try {
            logger.debug("微信获取accesstoken 请求 {}", sb.toString());
            String reslut = HttpsConnect.sendGetRequest(sb.toString());
            logger.debug("微信获取accesstoken 返回:{}", reslut);
            JSONObject json = JSON.parseObject(reslut);
            String thirdId = json.getString("openid");
            playerAccount.setAccount(thirdId);
            if (thirdId != null) {
                String accessToken = json.getString("access_token");
                sb = new StringBuilder();
                sb.append("https://api.weixin.qq.com/sns/userinfo?");
                sb.append("access_token").append("=").append(accessToken).append("&");
                sb.append("openId").append("=").append(thirdId);
                reslut = HttpsConnect.sendGetRequest(sb.toString());
                logger.debug("微信获取userinfo 返回:{}", reslut);
                json = JSON.parseObject(reslut);
                if (json.getString("openid") != null) {
                    String head = json.getString("headimgurl");
                    String name = json.getString("nickname");
                    player.setNick(name);
                    player.setHead(head);

                    return true;
                }


            }
            return false;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
