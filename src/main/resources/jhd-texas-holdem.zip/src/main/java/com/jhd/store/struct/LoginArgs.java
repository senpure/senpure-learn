package com.jhd.store.struct;

/**
 * Created by 罗中正 on 2017/8/25.
 */
public class LoginArgs {
    private  String token;
    private String type;
    private String account;
    private String ip;
    private  String ipChian;

    private long ipNum;

    private String source;

    private String comment;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public long getIpNum() {
        return ipNum;
    }

    public void setIpNum(long ipNum) {
        this.ipNum = ipNum;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getIpChian() {
        return ipChian;
    }

    public void setIpChian(String ipChian) {
        this.ipChian = ipChian;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
}
