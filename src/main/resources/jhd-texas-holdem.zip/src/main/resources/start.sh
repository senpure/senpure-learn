#!/usr/bin/env bash
nohup java -jar texas.jar > /dev/null &
sh outToshell.sh texas.jar