package com.jhd.game;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Pattern;

/**
 * Created by 罗中正 on 2017/9/7.
 */
public class LoggerTest {

    private Logger logger = LoggerFactory.getLogger("druid.sql.Statement");

    @Test
    public void log()
    {
        String str="{conn-10004, pstmt-20001} created.executed. insert into game_student (name,age,version) VALUES(?,?,0)";
    String str2="{conn-10004, pstmt-20001} executed. insert into game_student (name, age, version) " +
            " values ('10088', 123, 0)";

        logger.debug(str);
        logger.debug(str2);
        String regEx=".*executed. insert[\\s\\S]*";
        Pattern pattern = Pattern.compile(regEx);
        System.out.println(pattern.matcher(str).matches());
        System.out.println(pattern.matcher(str2).matches());
       ;
    }
}
