package com.jhd.game.texasholdem;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import org.junit.Test;



/**
 * Created by 罗中正 on 2017/9/19.
 */
public class BinTest {
    @Test
    public  void bin()
    {
        ByteBuf buf= Unpooled.buffer();


        buf.writeInt(654321);
        StringBuilder sb = new StringBuilder();
        ByteBufUtil.appendPrettyHexDump(sb, buf);
        System.out.println(sb.toString());

    }
    @Test
    public void t()
    {
        int m=1000 << 12;
        System.out.println();
        System.out.println(5000&m);
    }
}
