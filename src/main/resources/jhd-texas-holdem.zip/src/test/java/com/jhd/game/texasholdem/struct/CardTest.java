package com.jhd.game.texasholdem.struct;

import org.junit.Test;

import java.io.File;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/8/28.
 */
public class CardTest {

    @Test
    public void card()
    {


        Cards52 cards52=new Cards52();
        List<Card> cards = new ArrayList<>();
        for (Card.SUIT suit:Card.SUIT.values())
        for (Card.RANK rank:Card.RANK.values())
        {
            cards.add(new Card(suit, rank));
        }

        for (Card card:cards)
        {
           int value= card.getSuit().ordinal()*16+card.getValue();
            System.out.println(card.toString()+" , "+value +","+Integer.toHexString(value));
        }
    }

    @Test
    public void a() throws URISyntaxException {
        File file=new File(getClass().getResource("").toURI().getPath());
        System.out.println(file.getAbsolutePath()+","+file.exists());
    }
}