package com.jhd.game.texasholdem.struct;

import org.junit.Test;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;

/**
 * Created by 罗中正 on 2017/8/29.
 */
public class UserDirTest {

    @Test
    public  void dir()
    {
        System.out.println(System.getProperty("user.dir"));
String sl=System.getProperty("java.class.path");
        RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
      sl=  runtimeMXBean.getClassPath();
String sls[]=sl.split(";");
        for (String s : sls) {
            File file = new File(s);
            System.out.println(s);
            if (file.isDirectory()) {


            }
        }
    System.out.println(System.getProperty("java.class.path"));
        System.out.println(System.getProperty("user.name"));

    }
}
