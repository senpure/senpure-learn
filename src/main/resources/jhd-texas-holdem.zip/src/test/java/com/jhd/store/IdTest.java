package com.jhd.store;

import org.junit.Test;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by 罗中正 on 2017/8/24.
 */
public class IdTest {

    @Test
    public void id()
    {
        Integer   prefix=600000;
        System.out.println(Integer.toHexString(prefix));
        System.out.println(Integer.toBinaryString(prefix));
    }

    public static int getServerKey(int webId, int serverId)
    {
        return (((webId & 0xFF) << 14) + (serverId & 0xFFFF));
    }

    public static int getServerId(int serverKey) {
        int webid = serverKey >> 14 & 0xFF;
        if ((webid > 1) && (webid <= 4)) {
            return ((serverKey & 0x3FFF) + 16384 * (webid - 1));
        }
        return (serverKey & 0x3FFF);
    }

    public static int getWebId(int serverKey)
    {
        int webid = serverKey >> 14 & 0xFF;
        if ((webid >= 1) && (webid <= 4)) {
            return 1;
        }
        return webid;
    }
    private static long time = System.currentTimeMillis() / 1000L;
    private static AtomicLong id = new AtomicLong((time & 0x1FFFFFFF) << 13);
    public static long getId(int serverKey)
    {
        return ((serverKey & 0x3FFFFF) << 42 | id.getAndIncrement());
    }
    public static void main(String[] args)
            throws Exception
    {

        System.out.println(time);
        System.out.println(Integer.toBinaryString((int) time));
        int webid = 123;
        int serverid = 20004;

        int s2 = getServerKey(webid, serverid);
        System.out.println("webid=" + webid + ",serverid=" + serverid + ",组合ServerKey=" + s2);
        System.out.println("拆解ServerKey" + s2 + ",得到webid=" + getWebId(s2) + ",serverid=" + getServerId(s2));

        for (int i = 0; i < 2; ++i) {
            long id = getId(s2);
            System.out.println("得到当前唯一ID=" + id);
            System.out.println("拆解获得自增数= " + (id & 0x1FFF));
            System.out.println("拆解获得时间=" + (id >> 13 & 0x1FFFFFFF));
            System.out.println("对比系统时间=" + (System.currentTimeMillis() / 1000L & 0x1FFFFFFF));
            System.out.println("拆解获得ServerKey=" + (id >> 42 & 0x3FFFFF));
        }
    }
}
