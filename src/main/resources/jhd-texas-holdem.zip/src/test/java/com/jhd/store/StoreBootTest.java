package com.jhd.store;

import com.jhd.store.dao.PlayerDao;
import com.jhd.store.dao.StudentDao;
import com.jhd.store.entity.Player;
import com.jhd.store.entity.Student;
import com.jhd.store.entity.Student2;

import com.jhd.store.service.PlayerService;
import com.jhd.store.struct.LoginArgs;
import com.senpure.base.util.DateFormatUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

/**
 * Created by 罗中正 on 2017/8/23.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes =StoreBoot.class)
public class StoreBootTest  {

    private Logger logger = LoggerFactory.getLogger(StoreBootTest.class);
   // @Autowired
   // private StudentMapper studentMapper;
    @Autowired
    private PlayerDao playerDao;
    @Autowired
    private StudentDao StudentDao ;
    @Autowired
    private PlayerService playerService;
  //  @Autowired
   // private StudentService studentService;
    @Test
    public void save()
    {
        Student student=new Student();
        student.setAge(11);
        student.setName("student2");

      //  studentService.save(student);

        LoginArgs loginArgs=new LoginArgs();
        loginArgs.setType(StoreConstant.ACCOUNT_TYPE.VISITOR.toString());
        loginArgs.setAccount("abc1");

        //playerService.playerToken(loginArgs);
        Player player = new Player();
        player.setId(1);
       // playerDao.save(player);

    }
    @Test
    public void save2()
    {

        Student2 student=new Student2();
        student.setAge(11);
        student.setName("student2");

        //studentService.save2(student);
    }

    @Test
    public void find()
    {

    //  Student student=  studentMapper.find(40);
       // System.out.println(student.getAge()+student.getName()+","+student.getUserName());
    }
    @Test
    public void finds()
    {

       /// Object obj=  studentMapper.finds();
       // logger.debug("{}",obj.getClass());
    }

    @Test
    public void studentSaveAndFind()
    {

        Student student=new Student();
        Date date = new Date();
        student.setAge(5);
        student.setName("s");
        student.setUserName("444");
        student.setDate(date);


        student.setTime(date.getTime());
        System.out.println(DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).
                format(student.getDate()));

        System.out.println(DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).
                format(new Date(student.getTime())));
        StudentDao.save(student);
        System.out.println(DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).
                format(student.getDate()));

        System.out.println(DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).
                format(new Date(student.getTime())));
        System.out.println(student.getId());
    }
    @Test
    public void findStudent()
    {
      Student student=StudentDao.findOne(96);
        System.out.println(DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).
                format(student.getDate()));

        System.out.println(DateFormatUtil.getDateFormat(DateFormatUtil.DFP_Y2MS).
                format(new Date(student.getTime())));
    }

    @Test
    public void update()
    {
     Player p=   playerDao.findOne(4);
     p.setHead("jjj");
        playerDao.save(p);
    }
}