package com.jhd.store.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jhd.SpringBootTestSupport;
import com.jhd.store.StoreConstant;
import com.jhd.store.service.PlayerService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/8/25.
 */
public class PlayerLoginControllerTest extends SpringBootTestSupport {
    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @Autowired
    private PlayerService playerService;
    @Before
    public void setupMockMvc() throws Exception {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    public void login() throws Exception {

        Map json = new HashMap();
        json.put("account", "7777777");
        json.put("type", StoreConstant.ACCOUNT_TYPE.VISITOR.toString());
        MvcResult result = mockMvc.perform(
                MockMvcRequestBuilders.get("/game/login")
                        .accept(MediaType.APPLICATION_JSON)
                        .content(JSON.toJSONString(json))
        ).andReturn();
        JSONObject obj=JSON.parseObject(result.getResponse().getContentAsString());
        logger.debug(obj.toJSONString());

        playerService.playerLoginByToken(obj.getString("token"));

    }

}