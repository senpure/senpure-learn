package com.jhd.game.demo.handler;

import com.jhd.game.demo.message.SCStudentMessage;
import com.senpure.io.message.AbsMessageHandler;
import io.netty.channel.Channel;
import org.springframework.stereotype.Component;

/**
 * 学生信息处理器
 * 
 * @author senpure-generator
 * @version 2017-10-24 13:54:24
 */
@Component
public class SCStudentMessageHandler extends AbsMessageHandler<SCStudentMessage> {

    @Override
    public void execute(Channel channel, SCStudentMessage message) {
        //TODO 请在这里写下你的代码

        logger.debug("recive ----\n{}",message.toString(""));

    }

    @Override
    public int handlerId() {
    return 66102;
    }

    @Override
    public SCStudentMessage getEmptyMessage() {
    return new SCStudentMessage();
    }

    }