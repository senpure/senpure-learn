package com.jhd.game.mahjong;

import com.senpure.base.util.BannerShow;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by 罗中正 on 2017/9/5.
 */
@SpringBootApplication(scanBasePackages = "com")

public class ClientBoot {
    public static void main(String[] args) {
        AnsiConsole.systemInstall();
        AnsiConsole.systemUninstall();
        SpringApplication application = new SpringApplication(ClientBoot.class);
        application.setBannerMode(Banner.Mode.LOG);
        application.run(args);
        BannerShow.show();


    }
}
