package com.jhd.game.mahjong;

import com.jhd.game.demo.message.CSStudentMessage;
import io.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;


/**
 * Created by 罗中正 on 2017/9/5.
 */
@Component
@EnableScheduling
public class StartClient {

    private static Logger logger = LoggerFactory.getLogger(StartClient.class);


    @PostConstruct
    public void init()
    {
        Client client = Spring.getBean(Client.class);
        Channel channel = client.getChannel();
        CSStudentMessage studentMessage = new CSStudentMessage();
        channel.writeAndFlush(studentMessage);

    }





}
