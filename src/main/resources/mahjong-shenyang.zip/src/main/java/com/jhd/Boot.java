package com.jhd;

import com.senpure.base.AppEvn;
import com.senpure.base.util.BannerShow;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by 罗中正 on 2017/10/24.
 */
@SpringBootApplication(scanBasePackages ="com.senpure,com.jhd")
public class Boot {

    public static void main(String[] args) {

       String string= AppEvn.getClassRootPath();
        System.out.println(string);
        AnsiConsole.systemInstall();
        AnsiConsole.systemUninstall();
        SpringApplication application = new SpringApplication(Boot.class);
        application.setBannerMode(Banner.Mode.LOG);
        application.run(args);
        BannerShow.show();

    }

    public static void main3(String[] args) {
        StackTraceElement[] statcks = Thread.currentThread().getStackTrace();


        int count = 1;
        Class clazz = null;

        try {
            do {
                ++count;
                StackTraceElement statck = statcks[count];
                System.out.println(statck.getClassName());
                clazz = Class.forName(statck.getClassName());
            } while(AppEvn.classInJar(clazz) && count < statcks.length - 1);
        } catch (ClassNotFoundException var4) {
            var4.printStackTrace();
        }
    }
}
