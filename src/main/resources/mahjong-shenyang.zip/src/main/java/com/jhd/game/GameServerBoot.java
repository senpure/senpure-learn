package com.jhd.game;

import com.senpure.base.AppEvn;
import com.senpure.base.util.BannerShow;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by 罗中正 on 2017/10/24.
 */

@SpringBootApplication(scanBasePackages ="com.senpure.io,com.jhd.game")
public class GameServerBoot {


    public static void main(String[] args) {

        String string= AppEvn.getClassRootPath();
        System.out.println(string);
        AnsiConsole.systemInstall();
        AnsiConsole.systemUninstall();
        SpringApplication application = new SpringApplication(GameServerBoot.class);
        application.setBannerMode(Banner.Mode.LOG);
        application.run(args);
        BannerShow.show();

    }
}
