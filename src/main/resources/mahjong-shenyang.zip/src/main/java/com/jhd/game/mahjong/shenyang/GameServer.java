package com.jhd.game.mahjong.shenyang;

import com.senpure.io.*;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.SelfSignedCertificate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.net.ssl.SSLException;
import java.security.cert.CertificateException;

/**
 * Created by 罗中正 on 2017/8/21.
 */

@ConfigurationProperties(
        prefix = "game"
)
@Component
public class GameServer {
    protected Logger logger = LoggerFactory.getLogger(com.senpure.io.GameServer.class);
    static final boolean SSL = System.getProperty("ssl") != null;
    private int port = 1234;
    private boolean inFormat;
    private boolean outFormat;
    private ChannelFuture channelFuture;
    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;

    private IOMessageProperties ioMessageProperties;

    @PostConstruct
    public void init() throws CertificateException, SSLException {
        {
            ioMessageProperties = new IOMessageProperties();
            ioMessageProperties.setInFormat(inFormat);
            ioMessageProperties.setOutFormat(outFormat);
            logger.debug("启动游戏服务器，监听端口号 {}", port);
            // Configure SSL.
            final SslContext sslCtx;
            if (SSL) {
                SelfSignedCertificate ssc = new SelfSignedCertificate();
                sslCtx = SslContextBuilder.forServer(ssc.certificate(), ssc.privateKey()).build();
            } else {
                sslCtx = null;
            }
            // Configure the server.
            bossGroup = new NioEventLoopGroup(1);
            workerGroup = new NioEventLoopGroup();
            try {

                ServerBootstrap b = new ServerBootstrap();
                b.group(bossGroup, workerGroup)
                        .channel(NioServerSocketChannel.class)
                        .option(ChannelOption.SO_BACKLOG, 100)
                        .handler(new LoggingHandler(LogLevel.INFO))
                        .childHandler(new ChannelInitializer<SocketChannel>() {
                            @Override
                            public void initChannel(SocketChannel ch) throws Exception {
                                ChannelPipeline p = ch.pipeline();
                                if (sslCtx != null) {
                                    p.addLast(sslCtx.newHandler(ch.alloc()));
                                }
                               // p.addLast(new LoggingHandler(LogLevel.DEBUG));
                                p.addLast(new ByteBufToMessageDecoder());
                                p.addLast(new MessageToByteBufEncoder());
                                OffLineHandler offLineHandler = new OffLineHandler();
                                ChannelAttributeUtil.setOfflineHandler(ch, offLineHandler);
                                p.addLast(offLineHandler);
                                p.addLast(new MessageLoggingHandler(LogLevel.DEBUG, ioMessageProperties));
                                p.addLast(new ServerHandler());

                            }
                        });

                // Start the server.
                channelFuture = b.bind(port).sync();

            } catch (InterruptedException e) {
                logger.error("", e);
            }

        }
    }

    @PreDestroy
    public void destory() {
        channelFuture.channel().close();
        bossGroup.shutdownGracefully();
        workerGroup.shutdownGracefully();
        logger.debug("关闭io服务器并释放资源 ");

    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public boolean isInFormat() {
        return inFormat;
    }

    public void setInFormat(boolean inFormat) {
        this.inFormat = inFormat;
    }

    public boolean isOutFormat() {
        return outFormat;
    }

    public void setOutFormat(boolean outFormat) {
        this.outFormat = outFormat;
    }
}
