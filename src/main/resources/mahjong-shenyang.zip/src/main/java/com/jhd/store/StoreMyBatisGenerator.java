package com.jhd.store;

import com.senpure.base.AppEvn;
import com.senpure.base.generator.Config;
import com.senpure.base.generator.MybatisGenerator;

/**
 * Created by 罗中正 on 2017/10/24.
 */
public class StoreMyBatisGenerator {
    public static void main(String[] args) {
        AppEvn.getClassRootPath();
        System.setProperty("PID", AppEvn.getPid());
        MybatisGenerator mybatisGenerator=new MybatisGenerator();
        Config config=new Config();
        config.setAllCover(true);
        config.setDefaultCache(false, false, false, false);
        mybatisGenerator.generator("com.jhd.store.demo",config);
    }
}
