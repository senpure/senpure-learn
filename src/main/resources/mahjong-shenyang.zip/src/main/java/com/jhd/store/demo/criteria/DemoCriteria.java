package com.jhd.store.demo.criteria;

import com.jhd.store.demo.model.Demo;
import com.senpure.base.criterion.Criteria;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

/**
 * @author senpure-generator
 * @version 2017-10-24 13:24:24
 */
public class DemoCriteria extends Criteria implements Serializable {
    private static final long serialVersionUID = 1508822664997L;

    //主键
    private Long id;
    //乐观锁，版本控制
    private Integer version;
    private String name;
    private Integer age;
    //创建时间
    private Date createDate;
    //创建时间,时间戳格式
    private Long createTime;
    private String type;

    public static Demo toDemo(DemoCriteria criteria, Demo demo) {
        demo.setId(criteria.getId());
        demo.setName(criteria.getName());
        demo.setAge(criteria.getAge());
        demo.setCreateDate(criteria.getCreateDate());
        demo.setCreateTime(criteria.getCreateTime());
        demo.setType(criteria.getType());
        demo.setVersion(criteria.getVersion());
        return demo;
    }

    public Demo toDemo() {
        Demo demo = new Demo();
        return toDemo(this, demo);
    }

    @Override
    protected void beforeStr(StringBuilder sb) {
        sb.append("DemoCriteria{");
        if (id != null) {
            sb.append("id=").append(id).append(",");
        }
        if (version != null) {
            sb.append("version=").append(version).append(",");
        }
        if (name != null) {
            sb.append("name=").append(name).append(",");
        }
        if (age != null) {
            sb.append("age=").append(age).append(",");
        }
        if (createDate != null) {
            sb.append("createDate=").append(createDate).append(",");
        }
        if (createTime != null) {
            sb.append("createTime=").append(createTime).append(",");
        }
        if (type != null) {
            sb.append("type=").append(type).append(",");
        }
    }

    /**
     * get 主键
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * set 主键
     *
     * @return
     */
    public DemoCriteria setId(Long id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }


    public DemoCriteria setName(String name) {
        if (name != null && name.trim().length() == 0) {
            return this;
        }
        this.name = name;
        return this;
    }

    public Integer getAge() {
        return age;
    }


    public DemoCriteria setAge(Integer age) {
        this.age = age;
        return this;
    }

    /**
     * get 创建时间
     *
     * @return
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * set 创建时间
     *
     * @return
     */
    public DemoCriteria setCreateDate(Date createDate) {
        this.createDate = createDate;
        return this;
    }

    /**
     * get 创建时间,时间戳格式
     *
     * @return
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * set 创建时间,时间戳格式
     *
     * @return
     */
    public DemoCriteria setCreateTime(Long createTime) {
        this.createTime = createTime;
        return this;
    }

    public String getType() {
        return type;
    }


    public DemoCriteria setType(String type) {
        if (type != null && type.trim().length() == 0) {
            return this;
        }
        this.type = type;
        return this;
    }

    /**
     * get 乐观锁，版本控制
     *
     * @return
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * set 乐观锁，版本控制
     *
     * @return
     */
    public DemoCriteria setVersion(Integer version) {
        this.version = version;
        return this;
    }

}