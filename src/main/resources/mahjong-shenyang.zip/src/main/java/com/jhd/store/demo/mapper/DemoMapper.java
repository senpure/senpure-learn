package com.jhd.store.demo.mapper;

import com.jhd.store.demo.model.Demo;
import com.jhd.store.demo.criteria.DemoCriteria;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author senpure-generator
 * @version 2017-10-24 13:24:24
 */
@Mapper
public interface DemoMapper {

    Demo find(Long id);

    /**
     * 根据主键删除
     *
     * @return 影响的行数
     */
    int delete(Long id);

    /**
     * <b>主键会无效化,不会进行条件对比</b>
     *
     * @return 影响的行数
     */
    int deleteByCriteria(DemoCriteria criteria);

    /**
     * 取对象的值，直接插入数据库(包括空值)
     * version字段(版本控制)，被初始化为0
     *
     * @return 影响的行数
     */
    int save(Demo demo);

    /**
     * 取对象的值，直接插入数据库(包括空值)
     * version字段(版本控制)，被初始化为0
     *
     * @return 影响的行数
     */
    int saveBatch(List<Demo> demos);

    /**
     * 会进行对象的空值判断，不为空才更新，以主键进行where判断
     * version字段(版本控制)，必须有有效值
     *
     * @return 影响的行数
     */
    int update(Demo demo);

    /**
     * 直接将值覆盖到数据库，不会做为空判断，以主键进行where判断
     * version字段(版本控制)，必须有有效值
     *
     * @return 影响的行数
     */
    int cover(Demo demo);

    /**
     * 会进行对象的空值判断，不为空才更新，主键无值时，可以进行批量更新
     *
     * @return 影响的行数
     */
    int updateByCriteria(DemoCriteria criteria);

    int count();

    List<Demo> findAll();

    /**
     * <b>主键会无效化,不会进行条件对比</b>
     *
     * @return 满足条件的总行数
     */
    int countByCriteria(DemoCriteria criteria);

    /**
     * <b>主键会无效化,不会进行条件对比</b>
     *
     * @return
     */
    List<Demo> findByCriteria(DemoCriteria criteria);
}
