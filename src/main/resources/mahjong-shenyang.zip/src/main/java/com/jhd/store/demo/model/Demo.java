package com.jhd.store.demo.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @author senpure-generator
 * @version 2017-10-24 13:24:24
 */
public class Demo implements Serializable {
    private static final long serialVersionUID = 1508822664909L;

    //主键
    private Long id;
    //乐观锁，版本控制
    private Integer version;
    private String name;
    private Integer age;
    //创建时间
    private Date createDate;
    //创建时间,时间戳格式
    private Long createTime;
    private String type;

    /**
     * get 主键
     *
     * @return
     */
    public Long getId() {
        return id;
    }

    /**
     * set 主键
     *
     * @return
     */
    public Demo setId(Long id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }


    public Demo setName(String name) {
        this.name = name;
        return this;
    }

    public Integer getAge() {
        return age;
    }


    public Demo setAge(Integer age) {
        this.age = age;
        return this;
    }

    /**
     * get 创建时间
     *
     * @return
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * set 创建时间
     *
     * @return
     */
    public Demo setCreateDate(Date createDate) {
        this.createDate = createDate;
        return this;
    }

    /**
     * get 创建时间,时间戳格式
     *
     * @return
     */
    public Long getCreateTime() {
        return createTime;
    }

    /**
     * set 创建时间,时间戳格式
     *
     * @return
     */
    public Demo setCreateTime(Long createTime) {
        this.createTime = createTime;
        return this;
    }

    public String getType() {
        return type;
    }


    public Demo setType(String type) {
        this.type = type;
        return this;
    }

    /**
     * get 乐观锁，版本控制
     *
     * @return
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * set 乐观锁，版本控制
     *
     * @return
     */
    public Demo setVersion(Integer version) {
        this.version = version;
        return this;
    }

    @Override
    public String toString() {
        return "Demo{"
                + "id=" + id
                + ",version=" + version
                + ",name=" + name
                + ",age=" + age
                + ",createDate=" + createDate
                + ",createTime=" + createTime
                + ",type=" + type
                + "}";
    }

}