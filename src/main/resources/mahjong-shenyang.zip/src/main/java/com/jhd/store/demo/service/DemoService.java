package com.jhd.store.demo.service;

import com.jhd.store.demo.model.Demo;
import com.jhd.store.demo.criteria.DemoCriteria;
import com.jhd.store.demo.mapper.DemoMapper;
import com.senpure.base.exception.OptimisticLockingFailureException;
import com.senpure.base.service.BaseService;
import com.senpure.base.result.ResultMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author senpure-generator
 * @version 2017-10-24 13:24:25
 */
@Service
public class DemoService extends BaseService {

    @Autowired
    private DemoMapper demoMapper;

    public Demo find(Long id) {
        return demoMapper.find(id);
    }

    public int count() {
        return demoMapper.count();
    }

    public List<Demo> findAll() {
        return demoMapper.findAll();
    }

    @Transactional
    public boolean delete(Long id) {
        int result = demoMapper.delete(id);
        return result == 1;
    }

    @Transactional
    public int delete(DemoCriteria criteria) {
        return demoMapper.deleteByCriteria(criteria);
    }

    @Transactional
    public boolean save(Demo demo) {
        demo.setId(idGenerator.nextId());
        int result = demoMapper.save(demo);
        return result == 1;
    }

    @Transactional
    public int save(List<Demo> demos) {
        if (demos == null || demos.size() == 0) {
            return 0;
        }
        for (Demo demo : demos) {
            demo.setId(idGenerator.nextId());
        }
        return demoMapper.saveBatch(demos);
    }

    @Transactional
    public boolean save(DemoCriteria criteria) {
        criteria.setId(idGenerator.nextId());
        int result = demoMapper.save(criteria.toDemo());
        return result == 1;
    }

    /**
     * 更新失败会抛出OptimisticLockingFailureException
     *
     * @return
     */
    @Transactional
    public boolean update(Demo demo) {
        int updateCount = demoMapper.update(demo);
        if (updateCount == 0) {
            throw new OptimisticLockingFailureException(demo.getClass() + ",[" + demo.getId() + "],版本号冲突");
        }
        return true;
    }

    /**
     * 当版本号，和主键不为空时，更新失败会抛出OptimisticLockingFailureException
     *
     * @return
     */
    @Transactional
    public int update(DemoCriteria criteria) {
        int updateCount = demoMapper.updateByCriteria(criteria);
        if (updateCount == 0 && criteria.getVersion() != null
                && criteria.getId() != null) {
            throw new OptimisticLockingFailureException(criteria.getClass() + ",[" + criteria.getId() + "],版本号冲突");
        }
        return updateCount;
    }

    public ResultMap findPage(DemoCriteria criteria) {
        ResultMap resultMap = ResultMap.success();
        int total = demoMapper.countByCriteria(criteria);
        resultMap.putTotal(total);
        if (total == 0) {
            return resultMap;
        }
        //检查页数是否合法
        checkPage(criteria, total);
        List<Demo> demos = demoMapper.findByCriteria(criteria);
        resultMap.putItems(demos);
        return resultMap;
    }

    public List<Demo> find(DemoCriteria criteria) {
        List<Demo> demos = demoMapper.findByCriteria(criteria);
        return demos;
    }

    public Demo findOne(DemoCriteria criteria) {
        List<Demo> demos = demoMapper.findByCriteria(criteria);
        if (demos.size() == 0) {
            return null;
        }
        return demos.get(0);
    }

    public Demo findByName(String name) {
        DemoCriteria criteria = new DemoCriteria();
        criteria.setUsePage(false);
        criteria.setName(name);
        List<Demo> demos = demoMapper.findByCriteria(criteria);
        if (demos.size() == 0) {
            return null;
        }
        return demos.get(0);
    }

    public List<Demo> findByType(String type) {
        DemoCriteria criteria = new DemoCriteria();
        criteria.setUsePage(false);
        criteria.setType(type);
        List<Demo> demos = demoMapper.findByCriteria(criteria);
        return demos;
    }

}