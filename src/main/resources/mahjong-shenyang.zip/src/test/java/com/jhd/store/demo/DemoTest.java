package com.jhd.store.demo;

import com.alibaba.fastjson.JSON;
import com.jhd.store.StoreBoot;
import com.jhd.store.demo.criteria.DemoCriteria;
import com.jhd.store.demo.model.Demo;
import com.jhd.store.demo.service.DemoService;
import com.senpure.base.result.ResultMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by 罗中正 on 2017/10/24.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes =StoreBoot.class)
public class DemoTest {

    private Logger logger = LoggerFactory.getLogger(DemoTest.class);
    @Autowired
    private DemoService demoService;

    @Test
    public  void saveTest()
    {
        Demo demo=new Demo();
        demo.setAge(12);
        Date date = new Date();
        demo.setCreateDate(date);
        demo.setCreateTime(date.getTime());
        demo.setType("test1");
        demo.setName("test");

        demoService.save(demo);
    }
    @Test
    public  void saveBatchTest()
    {
        List<Demo> demos = new ArrayList<>(128);
        for (int i = 0; i <50 ; i++) {
            Demo demo=new Demo();
            demo.setAge(12);
            Date date = new Date();
            demo.setCreateDate(date);
            demo.setCreateTime(date.getTime());
            demo.setType("test");
            demo.setName("demo"+i);
            demos.add(demo);
        }
        demoService.save(demos);
    }


    @Test
    public  void findTest()
    {

        DemoCriteria demoCriteria = new DemoCriteria();

        demoCriteria.setType("test");

        logger.debug(demoCriteria.toString());

        ResultMap resultMap = demoService.findPage(demoCriteria);

        demoCriteria.setUsePage(false);
        logger.debug("size {}, {} ",resultMap.getItemSize(),JSON.toJSONString(resultMap));

        List<Demo> demos = demoService.find(demoCriteria);
        logger.debug("size{}, {}",demos.size(),demos.toString());

       Demo demo= demoService.findByName("test100");

       logger.debug("demo {}",demo);


         demo= demoService.findByName("demo6");

        logger.debug("demo {}",demo);
    }

}
