package com.senpure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

public class AppContext {

    private static Logger logger = LoggerFactory.getLogger(AppContext.class);


    private static int topRoleId;
    private static int topContainerId;
    private static ConcurrentHashMap<String, DateFormat> dateFormatMap = new ConcurrentHashMap<>();

    static {


    }

    /**
     * class 所在包的根绝对路径<br>
     * 如 /class 或/bin
     *
     * @return str
     */
    public static String getClassRootPath() {
        String classRootPath = null;
        try {
            classRootPath = AppContext.class.getResource("").toURI().getPath();
            int index = classRootPath.indexOf("/");
            if (index == 0) {
                classRootPath = classRootPath.substring(1);
            }
            classRootPath = classRootPath.replace("/", File.separator);
            String packpath = AppContext.class.getPackage().getName();
            packpath = packpath.replace(".", File.separator);
            classRootPath = classRootPath.replace(packpath, "");
            while (classRootPath.charAt(classRootPath.length() - 1) == File.separatorChar) {
                classRootPath = classRootPath.substring(0, classRootPath.length() - 1);
            }
            logger.info("classRootPath {}", classRootPath);
        } catch (URISyntaxException e) {


            logger.error("", e);
        }
        return classRootPath;
    }

    public static boolean isWindowsOS() {

        String os = System.getProperty("os.name").toLowerCase();

        return os.contains("windows");
    }

    public static int getTopRoleId() {
        return topRoleId;
    }

    public static void setTopRoleId(int topRoleId) {
        AppContext.topRoleId = topRoleId;
    }

    public static int getTopContainerId() {
        return topContainerId;
    }

    public static void setTopContainerId(int topContainerId) {
        AppContext.topContainerId = topContainerId;
    }


    public static DateFormat getDateFormat(String pattern) {

        DateFormat dateFormat = dateFormatMap.get(pattern);
        if (dateFormat == null) {
            dateFormat = new SimpleDateFormat(pattern);
            try {
                dateFormat.format(new Date());
                dateFormatMap.putIfAbsent(pattern, dateFormat);
            } catch (Exception e) {
                logger.debug("格式化日期参数不对 " + pattern, e);
            }
        }
        return dateFormat;
    }

    public static void main(String[] args) {


        getDateFormat("78");
    }
}
