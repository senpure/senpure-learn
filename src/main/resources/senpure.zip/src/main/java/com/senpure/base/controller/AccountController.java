package com.senpure.base.controller;

import com.senpure.AppConstant;
import com.senpure.base.annotation.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.annotation.ResourceVerify;
import com.senpure.base.criterion.AccountCreateCriteria;
import com.senpure.base.criterion.AccountCriteria;
import com.senpure.base.result.ResultMap;
import com.senpure.base.service.*;
import com.senpure.base.spring.BaseController;
import com.senpure.base.struct.LoginedAccount;
import com.senpure.base.util.Http;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

/**
 * Created by 罗中正 on 2017/6/15.
 */
@Controller
@RequestMapping("/authorize")
@MenuGenerator(id = 1, text = "组织架构" ,icon = "glyphicon glyphicon-fire faa-float")
public class AccountController extends BaseController {

    @Autowired
    private AuthorizeService authorizeService;
    private String view = "authorize/account";
    @Autowired
    private ResourcesVerifyService resourcesVerifyService;

    @Autowired
    private ResourceVerifyContainerService resourceVerifyContainerService;

    private void reliable(HttpServletRequest request, AccountCriteria criteria) {
        criteria.reliable();
        LoginedAccount account = Http.getSubject(request);
        if (criteria.getContainers() != null) {
            List<Integer> containers = resourceVerifyContainerService.check(account.getId(), criteria.getContainers());
            if (containers == null) {
                criteria.setParentId(account.getContainerId());
            } else {
                criteria.setContainers(containers);
            }
        } else if (criteria.getContainerId() == AppConstant.ALL_OPOTION_INT) {
            criteria.setParentId(account.getContainerId());
        } else if (criteria.getContainerId() > 0) {
            boolean check = resourceVerifyContainerService.verify(account.getId(), criteria.getContainerId() + "");
            if (!check) {
                criteria.setParentId(account.getContainerId());
            }

        }
    }

    @MenuGenerator(id = 2, text = "人员管理",icon = "glyphicon glyphicon-user faa-float ")
    @RequestMapping(value = {"/accounts", "accounts/{page}"})
    @PermissionVerify(name = "/authorize/accounts_read", value = "查看组织人员")
    public ModelAndView accounts(HttpServletRequest request,@Valid  @ModelAttribute("criteria") AccountCriteria criteria,BindingResult result) {

        logger.debug("criteria.getOrder().size() = {}",criteria.getOrder().size());
        logger.debug("{}",criteria);
        logger.debug("criteria.getSdate() {}",criteria.getSdate());
        if (criteria.getSdate() != null) {
            logger.debug("{}", DateFormatUtils.format(criteria.getSdate(),"yyyy-MM-dd"));
        }

        if (result.hasErrors()) {

            return  incorrect(request,result,view);
        }
        criteria.setContainerId(AppConstant.ALL_OPOTION_INT);
        reliable(request, criteria);
        ResultMap resultMap = authorizeService.loadAccount(criteria);
        return view(request, view, resultMap);
    }

    @RequestMapping(value = {"/container/{containerId}/accounts", "/container/{containerId}/accounts/{page}"})
    @PermissionVerify(name = "/authorize/accounts_read", value = "查看组织人员")
    //@ResourceVerify(value = ResourceVerifyContainerService.VERIF_NAME, permissionName = "查看组织人员")
    @ResourceVerify(value = ResourceVerifyContainerService.VERIF_NAME)
    public ModelAndView containersAccounts(HttpServletRequest request, @Valid @ModelAttribute("criteria") AccountCriteria criteria, BindingResult validResult) {
        if (validResult.hasErrors()) {
            return formatIncorrect(request, validResult, "authorize/contarier");
        }
        logger.debug("criteria.getOrder().size() = {}",criteria.getOrder().size());
        reliable(request, criteria);
        ResultMap resultMap = authorizeService.loadAccount(criteria);
        return view(request, "authorize/account", resultMap);
    }

    @RequestMapping(value = "container/{containerId}/account", method = RequestMethod.GET)
    public ModelAndView readAccount(HttpServletRequest request, @ModelAttribute("criteria") AccountCreateCriteria criteria) {

        return view(request, "authorize/accountCreate");
    }

    @PermissionVerify(value = "创建账号")
    @RequestMapping(value = "/container/{containerId}/account", method = RequestMethod.POST)
    @ResourceVerify(value =ResourceVerifyContainerService.VERIF_NAME )
    public ModelAndView createAccount(HttpServletRequest request,
                                      @Valid @ModelAttribute("criteria") AccountCreateCriteria criteria, BindingResult validResult) {
        if (validResult.hasErrors()) {
            return formatIncorrect(request, validResult, "authorize/accountCreate");
        }

        ResultMap resultMap = authorizeService.createAccount(criteria);
        return result(request, "authorize/accountCreate", resultMap);
    }

    @PermissionVerify(value = "查看账号角色")
    @RequestMapping(value = {"/account/{accountId}/roles"})
    @ResourceVerify(ResourceVerifyAccountService.VERIF_NAME)
    public ModelAndView accountHasRole(HttpServletRequest request,
                                       @PathVariable int accountId) {


        return view(request, "authorize/accountRole", authorizeService.hasRole(accountId));
    }

    @PermissionVerify(value = "修改账号角色")
    @RequestMapping(value = "/account/{accountId}/role/{roleId}", method = RequestMethod.POST)
    @ResourceVerify(ResourceVerifyAccountService.VERIF_NAME)
    @ResourceVerify(value = ResourceVerifyRoleService.VERIF_NAME,offset = 2)
    public ModelAndView updateAccountRole(HttpServletRequest request,
                                         @PathVariable int accountId, @PathVariable int roleId, boolean award) {
//        LoginedAccount account = Http.getSubject(request);
//        if (!resourcesVerifyService.verify(ResourceVerifyRoleService.VERIF_NAME, account.getId(), roleId + "")) {
//            return dim(request);
//        }
//        if (!resourcesVerifyService.verify(ResourceVerifyAccountService.VERIF_NAME, account.getId(), accountId + "")) {
//            return dim(request);
//        }
        authorizeService.accountRole(accountId, roleId, award);
        return success(request, "authorize/accountRole");
    }

}
