package com.senpure.base.controller;

import com.senpure.base.menu.MenuGenerator;
import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.annotation.ResourceVerify;
import com.senpure.base.criterion.CREATE;
import com.senpure.base.criterion.ContainerCriteria;
import com.senpure.base.result.ResultMap;
import com.senpure.base.service.AuthorizeService;
import com.senpure.base.service.ResourceVerifyContainerService;
import com.senpure.base.service.ResourceVerifyPermissionService;
import com.senpure.base.service.ResourcesVerifyService;
import com.senpure.base.spring.BaseController;
import com.senpure.base.struct.LoginedAccount;
import com.senpure.base.util.Http;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * Created by 罗中正 on 2017/5/16.
 */
@Controller
@RequestMapping("/authorize")
public class ContainerController extends BaseController {
    @Autowired
    private AuthorizeService authorizeService;

    private String view = "authorize/container";
    @Autowired
    private ResourcesVerifyService resourcesVerifyService;



    @MenuGenerator(text = "组织管理",id = 10,parentId = 1)
    @PermissionVerify("查看组织")
    @RequestMapping(value = {"/containers","/containers/{page}"})
    public ModelAndView container(HttpServletRequest request,
                                  @Valid @ModelAttribute("criteria") ContainerCriteria criteria, BindingResult validResult) {

       logger.info("criteria page :" + criteria.getPage());
       logger.info("criteria page :" + criteria.getPage());
        if (validResult.hasErrors()) {
            return incorrect(request, validResult, view);
        }

        //int pageNumber = pasePage(page);
        LoginedAccount account = Http.getSubject(request);
        //criteria.setPage(pageNumber);
        criteria.setParentId(account.getContainerId());
        ResultMap resultMap = authorizeService.loadContainer(criteria);
        return view(request, "authorize/container", resultMap);
    }

    @PermissionVerify(value = "创建组织")
    @RequestMapping(value = "/container", method = RequestMethod.POST)
    public ModelAndView createContainer(HttpServletRequest request, @Validated(CREATE.class) @ModelAttribute("criteria") ContainerCriteria criteria, BindingResult validResult) {
        if (validResult.hasErrors()) {
            return formatIncorrect(request, validResult, "authorize/container");
        }
        LoginedAccount account = Http.getSubject(request);
        int containerId = account.getContainerId();
        authorizeService.createContaier(criteria, account.getId(), containerId);
        if (Http.isAjaxRequest(request)) {
            return success(request, view);
        }
        criteria.setParentId(containerId);
        ResultMap resultMap = authorizeService.loadContainer(criteria);

        return result(request, view, resultMap);

    }

    @PermissionVerify(value = "查看组织权限")
    @RequestMapping(value = "/container/{containerId}/permissions",method = RequestMethod.GET)
    @ResourceVerify(value = ResourceVerifyContainerService.VERIF_NAME)
    public ModelAndView containerHasPermission(HttpServletRequest request, @PathVariable int containerId) {
        ResultMap resultMap = authorizeService.hasPermissionContainer(containerId);
        return view(request, "authorize/containerPermission", resultMap);
    }

    @PermissionVerify(value = "修改组织权限")
    @RequestMapping(value = "/container/{containerId}/permission/{permissionId}", method = RequestMethod.POST)
    @ResourceVerify(value = ResourceVerifyContainerService.VERIF_NAME)
    @ResourceVerify(value = ResourceVerifyPermissionService.VERIF_NAME,permissionName = "修改组织权限",offset = 2)
    public ModelAndView updateContainerPermission(HttpServletRequest request, @PathVariable int containerId,  @PathVariable int permissionId, boolean award) {
        LoginedAccount account = Http.getSubject(request);
//        if (!resourcesVerifyService.verify(ResourceVerifyContainerService.VERIF_NAME, account.getId(), containerId + "")) {
//            return dim(request);
//        }
//        if (!resourcesVerifyService.verify(ResourceVerifyPermissionService.VERIF_NAME, account.getId(), permissionId + "")) {
//            return dim(request);
//        }
        authorizeService.containerPermission(containerId,permissionId,award);

        return success(request,"authorize/containerPermission");
    }
}
