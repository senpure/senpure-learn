package com.senpure.base.controller;

import com.senpure.base.annotation.PermissionVerify;
import com.senpure.base.annotation.ResourceVerify;
import com.senpure.base.criterion.RoleCreateCriteria;
import com.senpure.base.criterion.RoleCriteria;
import com.senpure.base.criterion.RolePermissionCriteria;
import com.senpure.base.service.*;
import com.senpure.base.spring.BaseController;
import com.senpure.base.struct.LoginedAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * Created by 罗中正 on 2017/5/18.
 */
@Controller
@RequestMapping("/authorize")
public class RoleController extends BaseController {
    @Autowired
    private AuthorizeService authorizeService;
    @Autowired
    private ResourcesVerifyService resourcesVerifyService;

    @RequestMapping(value = "container/{containerId}/role", method = RequestMethod.GET)
    public ModelAndView role(HttpServletRequest request,  @ModelAttribute("criteria") RoleCreateCriteria criteria) {


        return view(request, "authorize/roleCreate");
    }

    @PermissionVerify(value = "创建角色")
    @RequestMapping(value = "container/{containerId}/role", method = RequestMethod.POST)
    @ResourceVerify(ResourceVerifyContainerService.VERIF_NAME)
    public ModelAndView createRole(HttpServletRequest request,
                                   @Valid @ModelAttribute("criteria") RoleCreateCriteria criteria, BindingResult validReslut) {

        if (validReslut.hasErrors()) {
            return view(request, "authorize/roleCreate");
        }
        authorizeService.createRole(criteria);
        return success(request, "authorize/roleCreate");
    }

    public void reliable(LoginedAccount account, RoleCriteria criteria) {

    }



    @PermissionVerify(value = "查看角色")
    @RequestMapping(value = {"container/{containerId}/roles","container/{containerId}/roles/{page}"})
    @ResourceVerify(ResourceVerifyContainerService.VERIF_NAME)
    public ModelAndView role(HttpServletRequest request,
                             @Valid @ModelAttribute("criteria") RoleCriteria criteria, BindingResult validReslut) {

        if (validReslut.hasErrors()) {
            return view(request, "authorize/role");
        }
        return view(request, "authorize/role", authorizeService.loadRole(criteria));
    }

    @PermissionVerify(value = "查看角色权限页面")
    @RequestMapping(value = {"/role/{roleId}/permissions"})
    @ResourceVerify(ResourceVerifyRoleService.VERIF_NAME)
    public ModelAndView roleHasPermission(HttpServletRequest request,

                                          @ModelAttribute("criteria") RolePermissionCriteria criteria) {

        logger.debug(criteria.getRoleId()+"--------------------------------------------");
        return view(request, "authorize/rolePermission", authorizeService.hasPermissionRole(criteria.getRoleId()));
    }

    @PermissionVerify(value = "修改角色权限")
    @RequestMapping(value = "/role/{roleId}/permission/{permissionId}", method = RequestMethod.POST)
    @ResourceVerify(ResourceVerifyRoleService.VERIF_NAME)
    @ResourceVerify(ResourceVerifyPermissionService.VERIF_NAME)
    public ModelAndView updateRolePermission(HttpServletRequest request, @PathVariable int roleId,  @PathVariable int permissionId, boolean award) {
//        LoginedAccount account = Http.getSubject(request);
//        if (!resourcesVerifyService.verify(ResourceVerifyRoleService.VERIF_NAME, account.getId(), roleId + "")) {
//            return dim(request);
//        }
//        if (!resourcesVerifyService.verify(ResourceVerifyPermissionService.VERIF_NAME, account.getId(), permissionId + "")) {
//            return dim(request);
//        }
        authorizeService.rolePermission(roleId, permissionId, award);

        return success(request, "authorize/containerPermission");
    }
}
