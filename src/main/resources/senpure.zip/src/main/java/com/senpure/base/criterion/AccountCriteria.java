package com.senpure.base.criterion;

import com.senpure.AppConstant;

import java.util.List;

/**
 * Created by 罗中正 on 2017/5/15.
 */
public class AccountCriteria extends Criteria {
    private String name;
    private int containerId= AppConstant.ALL_OPOTION_INT;
    private int createTimeOrder = 0;
    private int accountOrder = 0;
    private List<Integer> containers;
    private int parentId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getContainerId() {
        return containerId;
    }

    public void setContainerId(int containerId) {
        this.containerId = containerId;
    }

    public int getCreateTimeOrder() {
        return createTimeOrder;
    }

    public void setCreateTimeOrder(int createTimeOrder) {
        this.createTimeOrder = createTimeOrder;
        putSort("createTime", createTimeOrder);
    }

    public int getAccountOrder() {
        return accountOrder;
    }

    public void setAccountOrder(int accountOrder) {
        this.accountOrder = accountOrder;
        putSort("account", accountOrder);
    }

    public List<Integer> getContainers() {
        return containers;
    }

    public void setContainers(List<Integer> containers) {
        this.containers = containers;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }



    /**
     * 确保不会使用客户端的值
     */
    public void reliable() {
        parentId = 0;
    }

    @Override
    public String toString() {
        return "AccountCriteria{" +
                "name='" + name + '\'' +
                ", containerId=" + containerId +
                ", createTimeOrder=" + createTimeOrder +
                ", start" + getSdate() +
                ", containers=" + containers +
                ", parentId=" + parentId +
                "} " + super.toString();
    }
}
