package com.senpure.base.criterion;

import com.senpure.AppConstant;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by 罗中正 on 2017/5/10.
 */
public class ContainerCriteria extends Criteria {

    @NotEmpty(message = "{not.blank}", groups = CREATE.class)
    private String name;
    private String description;
    private int parentId;
    private int level = AppConstant.CONTAINER_LEVEL_DEPARTMENT;
    private int createTimeOrder = 0;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public int getCreateTimeOrder() {
        return createTimeOrder;
    }

    public void setCreateTimeOrder(int createTimeOrder) {
        this.createTimeOrder = createTimeOrder;
        putSort("createTime", createTimeOrder);

    }
}
