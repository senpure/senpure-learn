package com.senpure.base.criterion;

import com.senpure.AppConstant;
import com.senpure.base.struct.PatternDate;
import com.senpure.base.validator.DynamicDate;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by 罗中正 on 2017/5/15.
 */
public class Criteria implements Serializable {
    private static final long serialVersionUID = 1L;

    private String startDate, endDate;

    private int page = 1;
    private int pageSize = 15;

    protected Map<String, Integer> order = new LinkedHashMap<>();
    @DynamicDate
    private PatternDate startTime = new PatternDate(), endTime = new PatternDate();
    private String datePattern;
  //  private Date sdate, edate;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
        startTime.setDateStr(startDate);
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
        endTime.setDateStr(endDate);
    }

    public Date getSdate() {
        return startTime.getDate();
    }

    public Date getEdate() {
        return endTime.getDate();
    }

    public String getDatePattern() {
        return datePattern;
    }

    public void setDatePattern(String datePattern) {
        this.datePattern = datePattern;

        startTime.setPattern(datePattern);
        endTime.setPattern(datePattern);

    }

    public int getPage() {
        return page;
    }

    public void setPage(String page) {
        try {
            int intPage = Integer.parseInt(page);
            setPageInt(intPage);
        } catch (NumberFormatException e) {

        }

    }

    public   void setPageInt(int page) {
        if (page < 1) {
            page = 1;
        }
        this.page = page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        if (pageSize < 5) {
            pageSize = 5;
        }
        if (pageSize > 200) {
            pageSize = 200;
        }
        this.pageSize = pageSize;
    }



    public  Map<String, Integer> getOrder() {
        return new LinkedHashMap<>(order);
        //return order;
    }
    public boolean isOrder2()
    {
        return true;
    }
    protected void putSort(String name, int sort) {
        if (sort == AppConstant.ORDER_ASC || sort == AppConstant.ORDER_DESC) {
            order.remove(name);
            order.put(name, sort);

        } else {
            order.remove(name);
        }

    }

    @Override
    public String toString() {
        return "Criteria{" +
                "startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", page=" + page +
                ", pageSize=" + pageSize +
                ", order=" + order +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", datePattern='" + datePattern + '\'' +
                '}';
    }
}
