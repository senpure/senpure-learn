package com.senpure.base.criterion;

/**
 * Created by 罗中正 on 2017/5/17.
 */
public interface READ {
}
