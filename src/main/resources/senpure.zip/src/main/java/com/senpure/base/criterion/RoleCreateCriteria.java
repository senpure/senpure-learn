package com.senpure.base.criterion;

import org.hibernate.validator.constraints.Length;

/**
 * Created by 罗中正 on 2017/5/18.
 */
public class RoleCreateCriteria extends  Criteria {
  private int   containerId;
    @Length(min=2,max=12,message="{name.length.error}")
  private String name;
    @Length(max=255,message="{name.length.error}")
    private String description;
    public int getContainerId() {
        return containerId;
    }

    public void setContainerId(int containerId) {
        this.containerId = containerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "RoleCreateCriteria{" +
                "containerId=" + containerId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
