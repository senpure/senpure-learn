package com.senpure.base.criterion;

/**
 * Created by 罗中正 on 2017/5/19.
 */
public class RoleCriteria extends  Criteria {
    private int   containerId;
    private int   createTimeOrder;
    public int getContainerId() {
        return containerId;
    }

    public void setContainerId(int containerId) {
        this.containerId = containerId;
    }

    public int getCreateTimeOrder() {
        return createTimeOrder;
    }

    public void setCreateTimeOrder(int createTimeOrder) {
        this.createTimeOrder = createTimeOrder;
    }
}
