package com.senpure.base.dao;

import com.senpure.base.entity.ContainerPermission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/2/7.
 */
@Repository
public interface ContainerPermissionDao extends JpaRepository<ContainerPermission,Integer> {


       public ContainerPermission findByContainerIdAndPermissionId(int containerId,int PermissionId);

    
}
