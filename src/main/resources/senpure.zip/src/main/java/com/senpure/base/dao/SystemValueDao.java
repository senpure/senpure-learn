package com.senpure.base.dao;

import com.senpure.base.entity.SystemValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by Administrator on 2017/2/7.
 */
@Repository
public interface SystemValueDao extends JpaRepository<SystemValue, Integer> {


    SystemValue findByKey(String key);

    List<SystemValue> findByType(String type);


}
