package com.senpure.base.em;

public enum SEX {
MALE,FEMALE,SECRECT
}
