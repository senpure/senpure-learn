package com.senpure.base.entity;


import com.senpure.AppConstant;

import javax.persistence.*;
import java.util.Date;
import java.util.List;


@Entity
@Table(name = AppConstant.DB_BASE_PREFIX + "_ROLE")
public class Role extends IntEntity {
    private static final long serialVersionUID = -7767418310648447445L;

    public Role() {
        createDate = new Date();
        createTime = createDate.getTime();
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "containerId")
    private Container container;

    @OneToMany(mappedBy = "role")
    private List<RolePermission> rolePermissions;

    private Date createDate;
    private Long createTime;
    @Column(nullable = false, length = 32)
    private String name;
    private String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Container getContainer() {
        return container;
    }

    public void setContainer(Container container) {
        this.container = container;
    }

    public List<RolePermission> getRolePermissions() {
        return rolePermissions;
    }

    public void setRolePermissions(List<RolePermission> rolePermissions) {
        this.rolePermissions = rolePermissions;
    }


    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

       Role that = (Role) o;

        return getId()==null?false:that.getId()==null?false:getId()==that.getId();
    }

    @Override
    public int hashCode() {
        return getId()==null?0:getId().hashCode();
    }
}
