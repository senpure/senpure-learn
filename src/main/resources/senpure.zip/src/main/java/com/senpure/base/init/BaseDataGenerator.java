package com.senpure.base.init;

import com.senpure.AppConstant;
import com.senpure.base.dao.*;
import com.senpure.base.entity.*;
import com.senpure.base.service.AccountService;
import com.senpure.base.service.AuthorizeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2017/3/1.
 */
@Component
@Order(value = 2)
public class BaseDataGenerator implements ApplicationListener<ContextRefreshedEvent> {
    private static Logger logger = LoggerFactory.getLogger(BaseDataGenerator.class);


    @Autowired
    private AccountService accountService;
    @Autowired
    private AuthorizeService authorizeService;

    @Autowired
    private AccountDao accountDao;
    @Autowired
    private ContainerDao containerDao;

    @Autowired
    private PermissionDao permissionDao;
    @Autowired
    private RoleDao roleDao;
    @Autowired
    private RolePermissionDao rolePermissionDao;
    @Autowired
    private ContainerPermissionDao containerPermissionDao;
    @Autowired
    private SystemValueDao systemValueDao;

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        Account account = accountDao.findByAccount("senpure");
        if (account == null) {
            logger.debug("准备生产系统账号");
            account = new Account();
            account.setAccount("senpure");
            account.setPassword("senpure");
            Date now = new Date();
            account.setVersion(0);
            account.setCreateDate(now);
            account.setCreateTime(now.getTime());
            account.setAccountState(AppConstant.ACCOUNT_STATE_NORMAL);
            account.setName(AppConstant.PROJECT_NAME);
            Container
                    container = new Container();
            container.setLevel(AppConstant.CONTAINER_LEVEL_TOP);
            container.setName(AppConstant.PROJECT_NAME);
            container.setContainerStructure("");
            container.setRelation(0);
            container.setDescription("系统最高容器");
            containerDao.save(container);
            account.setContainer(container);
            Role role = new Role();
            role.setContainer(container);
            role.setDescription("系统最高角色");
            role.setName(AppConstant.PROJECT_NAME);
            roleDao.save(role);
            List<Permission> permissions = permissionDao.findAll();
            List<RolePermission> rolePermissions = new ArrayList<>();
            List<ContainerPermission> containerPermissions = new ArrayList<>();
            permissions.forEach(permission -> {
                RolePermission rolePermission = new RolePermission();
                rolePermission.setRole(role);
                rolePermission.setPermission(permission);
                rolePermissions.add(rolePermission);
                ContainerPermission containerPermission = new ContainerPermission();
                containerPermission.setContainer(container);
                containerPermission.setPermission(permission);
                containerPermissions.add(containerPermission);
            });
            role.setRolePermissions(rolePermissions);
            container.setContainerPermissions(containerPermissions);
            containerPermissionDao.save(containerPermissions);
            rolePermissionDao.save(rolePermissions);
            AccountRole accountRole = new AccountRole();
            accountRole.setAccount(account);
            accountRole.setRole(role);
            List<AccountRole> accountRoles = new ArrayList<>();
            accountRoles.add(accountRole);
            account.setAccountRoles(accountRoles);
            accountDao.save(account);

            List<SystemValue>
                    systemValues = new ArrayList<>();
            SystemValue roleId = systemValueDao.findByKey("top.role.id");

            if (roleId == null) {
                roleId = new SystemValue();
            }
            roleId.setKey("top.role.id");
            roleId.setValue(role.getId().toString());
            systemValues.add(roleId);
            SystemValue contaierId = systemValueDao.findByKey("top.container.id");

            if (contaierId  == null) {
                contaierId = new SystemValue();

            }
            contaierId.setKey("top.container.id");
            contaierId.setValue(container.getId().toString());
            systemValues.add(contaierId);
            systemValueDao.save(systemValues);

          generatorDefaultValue();
        }
    }

    private void generatorDefaultValue()
    {
        List<SystemValue> systemValues=new ArrayList<>();
        SystemValue dateFormat=new SystemValue();
        dateFormat.setType(AppConstant.VALUE_TYPE_ACCOUNT_DEFAULT);
        dateFormat.setKey(AppConstant.DATE_FORMAT_KEY);
        dateFormat.setValue("yyyy-MM-dd");
        dateFormat.setDescription("例如:2017-05-06");
        systemValues.add(dateFormat);

        SystemValue systemValue=new SystemValue();
        systemValue.setType(AppConstant.VALUE_TYPE_ACCOUNT_DEFAULT);
        systemValue.setKey(AppConstant.TIME_FORMAT_KEY);
        systemValue.setValue("yyyy-MM-dd HH:mm:ss");
        systemValue.setDescription("例如:2017-05-06 17:55:99");
        systemValues.add(systemValue);


        systemValue=new SystemValue();
        systemValue.setType(AppConstant.VALUE_TYPE_ACCOUNT_DEFAULT);
        systemValue.setKey(AppConstant.ONLY_TIME_FORMAT_KEY);
        systemValue.setValue("HH:mm:ss");
        systemValue.setDescription("例如:17:55:99");
        systemValues.add(systemValue);

        systemValueDao.save(systemValues);
    }

}
