package com.senpure.base.init;

import com.senpure.AppConstant;
import com.senpure.base.dao.SystemValueDao;
import com.senpure.base.entity.SystemValue;
import com.senpure.base.spring.MultipleInterceptor;
import com.senpure.base.struct.KeyValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/5/12.
 */
public class LoadValueService implements ApplicationListener<ContextRefreshedEvent>  {
    @Autowired
    private MultipleInterceptor multipleInterceptor;
    @Autowired
    private SystemValueDao systemValueDao;
    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {

      List<SystemValue> systemValues= systemValueDao.findByType(AppConstant.VALUE_TYPE_ACCOUNT_DEFAULT);
      List<KeyValue<String,String>> keyValues=new ArrayList<>();

      systemValues.forEach(systemValue -> {

          KeyValue<String,String> keyValue=new KeyValue<>();
          keyValue.setKey(systemValue.getKey());
          keyValue.setValue(systemValue.getValue());
          keyValues.add(keyValue);
      });
      multipleInterceptor.setAccountValus(keyValues);
    }
}
