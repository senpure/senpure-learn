package com.senpure.base.init;

import com.senpure.base.dao.*;
import com.senpure.base.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Repository
@Order(value = 3)
public class PermissionCompleteGenerator implements
        ApplicationListener<ContextRefreshedEvent> {



    @Autowired
    PermissionDao permissionDao;
    @Autowired
    ContainerPermissionDao containerPermissionDao;
    @Autowired
    RolePermissionDao rolePermissionDao;
    @Autowired
    RoleDao roleDao;
    @Autowired
    ContainerDao containerDao;

    @Autowired
    SystemValueDao systemValueDao;

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        List<Permission> permissions = permissionDao.findAll();
        SystemValue systemValue = systemValueDao.findByKey("top.role.id");
        SystemValue cintainer = systemValueDao.findByKey("top.container.id");
        Role role = roleDao.findOne(Integer.parseInt(systemValue.getValue()));
        Container container = containerDao.findOne(Integer.parseInt(cintainer.getValue()));
        List<RolePermission> rolePermissions = role.getRolePermissions();
        List<ContainerPermission> containerPermissions = container.getContainerPermissions();

        int aSize = permissions.size();
        List<RolePermission> saves = new ArrayList<>();
        List<ContainerPermission> saves2 = new ArrayList<>();
        for (int i = 0; i < aSize; i++) {
            Permission permission = permissions.get(i);
            int rs = rolePermissions.size();
            int cs = containerPermissions.size();
            boolean addrp = true;
            for (int j = 0; j < rs; j++) {

                if (rolePermissions.get(j).getPermission().getId().intValue() == permission.getId()) {
                    addrp = false;
                    break;
                }
            }
            if (addrp) {
                RolePermission rolePermission = new RolePermission();
                rolePermission.setPermission(permission);
                rolePermission.setRole(role);
                saves.add(rolePermission);
            }
            boolean addcp = true;
            for (int j = 0; j < cs; j++) {
                if (rolePermissions.get(j).getPermission().getId().intValue() == permission.getId()) {

                    addcp = false;
                    break;
                }
            }
            if (addcp) {
                ContainerPermission containerPermission = new ContainerPermission();
                containerPermission.setPermission(permission);
                containerPermission.setContainer(container);
                saves2.add(containerPermission);
            }
        }
        if (saves.size() > 0)
        {
            rolePermissionDao.save(saves);

        }

        if (saves2.size() > 0) {

            containerPermissionDao.save(saves2);
        }
    }


    public static void main(String[] args) {

    }
}
