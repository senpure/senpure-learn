package com.senpure.base.init;

import com.senpure.Boot;
import com.senpure.base.spring.SpringContextRefreshEvent;
import org.dom4j.dom.DOMText;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.security.ProtectionDomain;

/**
 * Created by 罗中正 on 2017/7/27.
 */
@Component
@Order(1024)
public class SystemInfoPrinter extends SpringContextRefreshEvent {
    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        ProtectionDomain p=getClass().getProtectionDomain();
        ProtectionDomain Main= Boot.class.getProtectionDomain();
        ProtectionDomain third=DOMText.class.getProtectionDomain();
        logger.debug("SystemInfoPrinter {}",p);
        logger.debug("Main {}",Main);
        logger.debug("third {}",third);
    }
}
