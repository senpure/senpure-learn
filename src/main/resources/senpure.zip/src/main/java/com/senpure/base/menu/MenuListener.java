package com.senpure.base.menu;


public interface MenuListener {
	void execute(Menu menu);

}
