package com.senpure.base.redis;

import com.senpure.base.util.BannerShow;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot {

    public String home() {


        return "Hello World!";
    }

    public static void main(String[] args) throws Exception {
        //开启控制台颜色日志
       // AnsiOutput.setEnabled(AnsiOutput.Enabled.ALWAYS);
        AnsiConsole.systemInstall();
        AnsiConsole.systemUninstall();
        SpringApplication.run(Boot.class, args);
        BannerShow.show();


    }
}
