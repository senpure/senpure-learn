package com.senpure.base.redis;

import com.senpure.base.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;
import org.springframework.stereotype.Component;

/**
 * Created by 罗中正 on 2017/7/3.
 */
@Component

public class RedisClient extends BaseService {


    @Autowired
    RedisTemplate<String, String> redisTemplate;

    public void set(String key, String value) {



        long result = redisTemplate.execute((RedisCallback<Long>) connection -> {

            RedisSerializer<String> serializer = redisTemplate.getStringSerializer();
            long count = connection.rPush(serializer.serialize(key), serializer.serialize(value));
            return count;
        });

        logger.debug("result {}", result);

    }

    public String get(final String key) {
        String result = redisTemplate.execute((RedisCallback<String>) connection -> {
            RedisSerializer<String> serializer = redisTemplate.getStringSerializer();
            byte[] value = connection.get(serializer.serialize(key));
            return serializer.deserialize(value);
        });
        return result;
    }


}
