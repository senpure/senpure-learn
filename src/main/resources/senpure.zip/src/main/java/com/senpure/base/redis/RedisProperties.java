package com.senpure.base.redis;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Created by 罗中正 on 2017/7/4.
 */
@ConfigurationProperties(
        prefix = "spring.redis"
)
public class RedisProperties {
    private int port;
    private String host;
    private String password;
    private int dataBase;

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getDataBase() {
        return dataBase;
    }

    public void setDataBase(int dataBase) {
        this.dataBase = dataBase;
    }
}
