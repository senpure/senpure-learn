package com.senpure.base.result;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/8/23.
 */
public class FieldAndInstance {
  protected   List<Field> fields=new ArrayList<>();
  protected   Object instance;
}
