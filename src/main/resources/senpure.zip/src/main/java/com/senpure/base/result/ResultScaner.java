package com.senpure.base.result;

/**
 * Created by 罗中正 on 2017/8/2.
 */
public class ResultScaner {
}
