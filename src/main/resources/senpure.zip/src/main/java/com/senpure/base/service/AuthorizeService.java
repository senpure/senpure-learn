package com.senpure.base.service;

import com.senpure.AppConstant;
import com.senpure.base.criterion.*;
import com.senpure.base.dao.*;
import com.senpure.base.entity.*;
import com.senpure.base.menu.Menu;
import com.senpure.base.result.Result;
import com.senpure.base.result.ResultMap;
import com.senpure.base.struct.*;
import com.senpure.base.util.ConvertUtil;
import com.senpure.base.vo.AccountVo;
import com.senpure.base.vo.ContainerVo;
import com.senpure.base.vo.RoleVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.Predicate;
import java.util.*;

/**
 * Created by Administrator on 2017/2/7.
 */
@Service
@Transactional
public class AuthorizeService extends BaseService {
    @Autowired
    private AccountDao accountDao;
    @Autowired
    private ContainerDao containerDao;
    @Autowired
    private SystemValueDao systemValueDao;
    @Autowired
    private RoleDao roleDao;
    @Autowired
    private PermissionDao permissionDao;
    @Autowired
    private ContainerPermissionDao containerPermissionDao;
    @Autowired
    private RolePermissionDao rolePermissionDao;
    @Autowired
    private AccountRoleDao accountRoleDao;
    @Autowired
    private PermissionMenuDao permissionMenuDao;
    @Autowired
    private MenuDao menuDao;

    public void updatePassword(int accountId,String password)
    {

        Account account = accountDao.findOne(accountId);
        account.setPassword(password);
        accountDao.save(account);
    }

    public AccountVo loadAccount(Integer id) {
        Account a = accountDao.findOne(id);
        logger.debug(a.getContainer().getContainerStructure());
        if (a != null) {
            return ConvertUtil.convert(a);
        }
        return null;
    }

    public AccountVo loadAccount(String account) {
        Account a = accountDao.findByAccount(account);
        if (a != null) {
            return ConvertUtil.convert(a);
        }
        return null;
    }

    public ResultMap createAccount(AccountCreateCriteria criteria) {


        Account o = accountDao.findByAccount(criteria.getAccount());
        if (o != null) {

            return ResultMap.getResult(Result.ACCOUNT_ALREADY_EXISTS);
        }

        Container container = containerDao.getOne(criteria.getContainerId());
        Account account = new Account();
        account.setAccount(criteria.getAccount());
        account.setPassword(criteria.getPassword());
        Date now = new Date();

        account.setCreateDate(now);
        account.setCreateTime(now.getTime());
        account.setAccountState(AppConstant.ACCOUNT_STATE_NORMAL);
        account.setName(criteria.getName());
        account.setContainer(container);
        accountDao.save(account);
        return ResultMap.getSuccessResult();
    }


    public ResultMap loadAccount(AccountCriteria criteria) {
        Pageable pageable = getPage(criteria);
        Page<Account> page = accountDao.findAll((root, criteriaQuery, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            Predicate container = null;
            if (criteria.getContainerId() > 0) {
                container = criteriaBuilder.equal(root.get("container").get("id"), criteria.getContainerId());
            } else if (criteria.getParentId() > 0) {
                container = criteriaBuilder.equal(root.get("container").get("parent").get("id"), criteria.getParentId());
            } else if (criteria.getContainers() != null) {
                if (criteria.getContainers().size() == 1) {
                    container = criteriaBuilder.equal(root.get("container").get("id"), criteria.getContainers().get(0));
                } else {
                    container = criteriaBuilder.in(root.get("container").get("id")).in(criteria.getContainers());
                }
            }
            return criteriaBuilder.and(container);
        }, pageable);
        Page<AccountVo> pageVo = page.map(entity -> ConvertUtil.convert(entity));

        ResultMap resultMap = pageResult(pageVo);
        return resultMap;
    }

    public ResultMap hasRole(int accountId) {

        List<HasRole> hasRoles = new ArrayList<>();
        Account account = accountDao.findOne(accountId);

        Set<Role> myrole = new HashSet<>();
        account.getAccountRoles().forEach(ar -> {

            if (ar.getExpiry() == null || ar.getExpiry() == 0 || ar.getExpiry() > System.currentTimeMillis()) {
                myrole.add(ar.getRole());
            }
        });
        account.getContainer().getRoles().forEach(role -> {

            HasRole hasRole = new HasRole();

            ConvertUtil.convert(role, hasRole);
            if (
                    myrole.contains(role)
                    ) {
                hasRole.setHas(true);
            }
            hasRoles.add(hasRole);
        });


        return ResultMap.getSuccessResult().putItems(hasRoles);
    }

    public void accountRole(int accountId, int roleId, boolean award) {
        AccountRole accountRole = accountRoleDao.findByAccountIdAndRoleId(accountId, roleId);

        if (award) {
            if (accountRole == null) {
                accountRole = new AccountRole();

                Role role = roleDao.getOne(roleId);
                Account account = accountDao.getOne(accountId);
                accountRole.setRole(role);
                accountRole.setAccount(account);
                accountRoleDao.save(accountRole);
            }
        } else {
            if (accountRole != null) {

                accountRoleDao.delete(accountRole);
            }
        }
    }

    public List<Integer> secondaryContainer(int accountId) {
        List<Integer> containers = new ArrayList<>();
        accountDao.findOne(accountId).getContainer().getChildren()
                .forEach(container -> containers.add(container.getId()));
        return containers;

    }

    public List<ContainerVo> loadContainer(int parentId) {

        List<ContainerVo> containerVos = new ArrayList<>();
        Container container = containerDao.findOne(parentId);
        container.getChildren()
                .forEach(c ->
                        containerVos.add(ConvertUtil.convert(c))
                );

        return containerVos;
    }

    public ResultMap loadContainer(ContainerCriteria criteria) {
        Pageable pageable = getPage(criteria);
        Page<Container> containers = containerDao.findAll((root, criteriaQuery, criteriaBuilder) -> {
            Predicate container = criteriaBuilder.equal(root.get("parent").get("id"), criteria.getParentId());
            return criteriaBuilder.and(container);
        }, pageable);
        Page<ContainerVo> page = containers.map(container -> ConvertUtil.convert(container));
        ResultMap resultMap = pageResult(page);
        return resultMap;
    }

    public void createContaier(ContainerCriteria criteria, int createrId, int parentId) {
        Container parent = containerDao.findOne(parentId);
        Container container = new Container();
        container.setName(criteria.getName());
        container.setDescription(criteria.getDescription());
        container.setLevel(criteria.getLevel());
        container.setParent(parent);
        container.setRelation(parent.getRelation());
        container.setContainerStructure(parent.getContainerStructure() + AppConstant.CONTAINER_SEPARTOR + parent.getId() + AppConstant.CONTAINER_SEPARTOR);
        containerDao.save(container);

    }

    public void createRole(RoleCreateCriteria criteria) {
        Container container = containerDao.getOne(criteria.getContainerId());
        Role role = new Role();
        role.setContainer(container);
        role.setName(criteria.getName());
        role.setDescription(criteria.getDescription());
        roleDao.save(role);
    }

    public ResultMap loadRole(RoleCriteria criteria) {
        Pageable pageable = getPage(criteria);
        Page<Role> roles = roleDao.findAll((root, criteriaQuery, criteriaBuilder) -> {

            Predicate container = criteriaBuilder.equal(root.get("container").get("id"), criteria.getContainerId());
            return criteriaBuilder.and(container);
        }, pageable);
        Page<RoleVo> pageVo = roles.map(entity -> ConvertUtil.convert(entity));

        ResultMap resultMap = pageResult(pageVo);
        return resultMap;
    }

    public ResultMap hasPermissionContainer(int contaienrId) {

        List<HasPermission> hasPermissions = new ArrayList<>();

        Container container = containerDao.getOne(contaienrId);
        Set<Permission> myPermission = new HashSet<>();
        container.getContainerPermissions().forEach(cp -> {
            if (cp.getExpiry() == null || cp.getExpiry() == 0 || cp.getExpiry() > System.currentTimeMillis()) {
                myPermission.add(cp.getPermission());
            }
        });
        container.getParent().getContainerPermissions().forEach(cp -> {
            if (cp.getExpiry() == null || cp.getExpiry() == 0 || cp.getExpiry() > System.currentTimeMillis()) {
                HasPermission hasPermission = new HasPermission();
                Permission permission = cp.getPermission();
                ConvertUtil.convert(permission, hasPermission);
                if (myPermission.contains(permission)) {
                    hasPermission.setHas(true);
                }
                hasPermissions.add(hasPermission);
            }
        });
        Collections.sort(hasPermissions);
        return ResultMap.getSuccessResult().putItems(hasPermissions);
    }

    public void containerPermission(int containerId, int permissionId, boolean award) {

        ContainerPermission cp = containerPermissionDao.findByContainerIdAndPermissionId(containerId, permissionId);
        if (award) {
            if (cp == null) {
                cp = new ContainerPermission();
                Container c = containerDao.getOne(containerId);
                Permission p = permissionDao.getOne(permissionId);
                cp.setContainer(c);
                cp.setPermission(p);
                containerPermissionDao.save(cp);
            }
        } else {

            if (cp != null) {
                containerPermissionDao.delete(cp);
            }
        }

    }


    public ResultMap hasPermissionRole(int roleId) {
        Role role = roleDao.getOne(roleId);

        List<HasPermission> hasPermissions = new ArrayList<>();

        Set<Permission> myPermission = new HashSet<>();
        role.getRolePermissions().forEach(rp -> {
            if (rp.getExpiry() == null || rp.getExpiry() == 0 || rp.getExpiry() > System.currentTimeMillis()) {
                myPermission.add(rp.getPermission());
            }
        });
        role.getContainer().getContainerPermissions().forEach(cp -> {
            {
                if (cp.getExpiry() == null || cp.getExpiry() == 0 || cp.getExpiry() > System.currentTimeMillis()) {
                    HasPermission hasPermission = new HasPermission();
                    Permission permission = cp.getPermission();
                    ConvertUtil.convert(permission, hasPermission);
                    if (!myPermission.contains(permission)) {
                    } else {
                        hasPermission.setHas(true);
                    }
                    hasPermissions.add(hasPermission);
                }
            }

        });
        return ResultMap.getSuccessResult().putItems(hasPermissions);
    }

    public void rolePermission(int roleId, int permissionId, boolean award) {
        RolePermission rolePermission = rolePermissionDao.findByRoleIdAndPermissionId(roleId, permissionId);
        if (award) {
            if (rolePermission == null) {
                rolePermission = new RolePermission();
                Role role = roleDao.findOne(roleId);
                Permission p = permissionDao.findOne(permissionId);
                rolePermission.setRole(role);
                rolePermission.setPermission(p);
                rolePermissionDao.save(rolePermission);
            }
        } else {
            if (rolePermission != null) {
                rolePermissionDao.delete(rolePermission);

            }
        }


    }

    public ResultMap login(LoginCriteria criteria) {

        Account account = accountDao.findByAccount(criteria.getAccount());
        if (account == null) {
            return ResultMap.getResult(Result.ACCOUNT_NOT_EXIST);
        }

        if (!account.getPassword().equals(criteria.getPassword())) {
            return ResultMap.getResult(Result.PASSWORD_INCORRECT);
        }

        long now = System.currentTimeMillis();
        account.setLoginTime(now);
        accountDao.save(account);
        LoginedAccount loginedAccount = new LoginedAccount();


        Map<Integer, Menu> viewMenus = new HashMap<>();
        Collection<MergePermission> mergePermissions = loadPermission(account, viewMenus);
        Collection<KeyValue<String, String>> config = loadConfig(account);
        loginedAccount.getConfig().addAll(config);
        loginedAccount.getPermissions().addAll(mergePermissions);
        loginedAccount.getViewMenus().addAll(viewMenus.values());
        loginedAccount.setId(account.getId());
        loginedAccount.setContainerId(account.getContainer().getId());
        loginedAccount.setAccount(account.getAccount());
        loginedAccount.setName(account.getName());
        loginedAccount.setLoginIP(criteria.getLoginIP());
        loginedAccount.setLoginTime(now);
        return ResultMap.getSuccessResult().put("account", loginedAccount);

    }

    private void put() {
    }

    private Collection<KeyValue<String, String>> loadConfig(Account account) {
        Map<String, KeyValue<String, String>> map = new HashMap<>();
        List<SystemValue> systemValues = systemValueDao.findByType(AppConstant.VALUE_TYPE_ACCOUNT_DEFAULT);
        systemValues.forEach(systemValue ->
                {
                    KeyValue<String, String> keyValue = new KeyValue<>();
                    keyValue.setKey(systemValue.getKey());
                    keyValue.setValue(systemValue.getValue());
                    map.put(systemValue.getKey(), keyValue);
                }
        );
        account.getAccountValues().forEach(accountValue -> {
            KeyValue<String, String> keyValue = new KeyValue<>();
            keyValue.setValue(accountValue.getKey());
            keyValue.setValue(accountValue.getValue());
            map.put(keyValue.getKey(), keyValue);
        });
        return map.values();
    }

    private Collection<MergePermission> loadPermission(Account account, Map<Integer, Menu> viewMenus) {
        long now = System.currentTimeMillis();
        List<AccountRole> accountRoles = account.getAccountRoles();
        Map<Integer, MergePermission> mergePermissionMap = new HashMap<>();
        int arsize = accountRoles.size();
        for (int i = 0; i < arsize; i++) {
            AccountRole accountRole = accountRoles.get(i);
            Long arExpiry = accountRole.getExpiry();
            arExpiry = arExpiry == null ? 0 : arExpiry;
            if (arExpiry > 0 && arExpiry < now) {
                continue;
            }
            List<RolePermission> rolePermissions = accountRole.getRole().getRolePermissions();
            int rpsize = rolePermissions.size();
            for (int j = 0; j < rpsize; j++) {
                RolePermission rolePermission = rolePermissions.get(j);
                Long rpExpiry = rolePermission.getExpiry();
                rpExpiry = rpExpiry == null ? 0 : rpExpiry;
                if (rpExpiry > 0 && rpExpiry < now) {
                    continue;
                }
                Permission permission = rolePermission.getPermission();
                long lessExpiry = arExpiry < rpExpiry ? arExpiry : rpExpiry;
                MergePermission old = mergePermissionMap.get(permission.getId());
                if (old != null) {
                    if (old.getExpiry() == 0) {
                    } else {
                        if (lessExpiry == 0) {
                            old.setExpiry(0);
                        } else {
                            old.setExpiry(old.getExpiry() > lessExpiry ? old.getExpiry() : lessExpiry);
                        }
                    }
                } else {
                    MergePermission
                            mergePermission = new MergePermission();
                    mergePermission.setId(permission.getId());
                    mergePermission.setName(permission.getName());
                    mergePermission.setExpiry(lessExpiry);
                    mergePermission.setType(permission.getType());
                    mergePermissionMap.put(permission.getId(), mergePermission);
                    needMenu(permission.getName(), viewMenus);

                }

            }

        }

        return mergePermissionMap.values();
    }

    private void needMenu(String permissionName, Map<Integer, Menu> viewMenus) {

        PermissionMenu permissionMenu = permissionMenuDao.findByPermissionName(permissionName);
        if (permissionMenu != null) {
            mergeMenu(permissionMenu.getMenuId(), viewMenus);
        }

    }

    private void mergeMenu(int menuId, Map<Integer, Menu> viewMenus) {

        if (!viewMenus.containsKey(menuId)) {

            com.senpure.base.entity.Menu m = menuDao.findOne(menuId);
            Menu menu = new Menu();
            menu.setIcon(m.getIcon());
            menu.setId(m.getId());
            menu.setText(m.getText());
            menu.setUri(m.getUri());
            viewMenus.put(menuId, menu);
            if (m.getParentId() == null) {
                menu.setParentId(0);
            } else {
                menu.setParentId(m.getParentId());
                mergeMenu(m.getParentId(), viewMenus);
            }
        }
    }


}
