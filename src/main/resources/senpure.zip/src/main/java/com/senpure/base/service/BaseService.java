package com.senpure.base.service;


import com.senpure.AppConstant;
import com.senpure.base.criterion.Criteria;
import com.senpure.base.result.ResultMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.Iterator;
import java.util.Map;


/**
 * Created by Administrator on 2017/2/7.
 */
public class BaseService {
    protected Logger logger;

    public BaseService() {

        logger = LoggerFactory.getLogger(getClass());
    }

    protected Pageable getPage(Criteria criteria) {
        Sort sort = null;
        try {
            Iterator<Map.Entry<String, Integer>> iterator = criteria.getOrder().entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, Integer> entry = iterator.next();
                if (sort == null) {
                    sort = new Sort(entry.getValue() == AppConstant.ORDER_ASC ? Sort.Direction.ASC : Sort.Direction.DESC, entry.getKey());
                } else {
                    sort = sort.and(new Sort(entry.getValue() == AppConstant.ORDER_ASC ? Sort.Direction.ASC : Sort.Direction.DESC, entry.getKey()));
                }
            }
        } catch (Exception e) {
            logger.error("创建分页信息出错", e);
        }
        return new PageRequest(criteria.getPage() - 1, criteria.getPageSize(), sort);
    }

    protected ResultMap pageResult(Page<?> page) {
        ResultMap resultMap = ResultMap.getSuccessResult();
        resultMap.put(ResultMap.ITEMS_KEY, page.getContent());
        resultMap.put(ResultMap.TOTAL_KEY, page.getTotalElements());
       // resultMap.put(ResultMap.PAGE_KEY,page.getNumber());
        return resultMap;
    }

}
