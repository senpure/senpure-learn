package com.senpure.base.service;

import com.senpure.AppConstant;
import com.senpure.base.dao.AccountDao;
import com.senpure.base.dao.ContainerDao;
import com.senpure.base.entity.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/2/6.
 */
@Service
public class ResourceVerifyAccountService extends ResourceVerifySupportService {

    public static final String VERIF_NAME = "accountResource";
    @Autowired
    private ContainerDao containerDao;
    @Autowired
    private AccountDao accountDao;

    @Override
    public String getName() {
        return VERIF_NAME;
    }

    @Override
    public boolean verify(int accountId, String resourceId) {

        Integer checkId = Integer.valueOf(resourceId);
        if (checkId.intValue() == accountId) {
            return true;
        }
        Account account = accountDao.findOne(accountId);
        Account checkAccount = accountDao.findOne(checkId);
        if (checkAccount == null) {
            return false;
        }
        return checkAccount.getContainer().getContainerStructure().contains(AppConstant.CONTAINER_SEPARTOR + account.getContainer().getId());
    }
}
