package com.senpure.base.spring;


import com.senpure.AppConstant;
import com.senpure.base.result.Result;
import com.senpure.base.result.ResultHelper;
import com.senpure.base.result.ResultMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseController {
    //    HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
//
//    HttpServletResponse response = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getResponse();
//
//    HttpServletResponse response = ((ServletWebRequest)RequestContextHolder.getRequestAttributes()).getResponse();
//
//    ServletContext context = ContextLoader.getCurrentWebApplicationContext().getServletContext();
    protected Logger logger;

    public BaseController() {
        logger = LoggerFactory.getLogger(getClass());
    }

    protected LocaleResolver localeResolver;

    public LocaleResolver getLocaleResolver() {
        return localeResolver;
    }

    @Autowired
    @Qualifier("localeResolver")
    public void setLocaleResolver(LocaleResolver localeResolver) {
        this.localeResolver = localeResolver;
    }

    protected ModelAndView addActionResult(HttpServletRequest request, ModelAndView modelAndView, ResultMap result) {

        return addActionResult(request, modelAndView, result, true);
    }


    protected ModelAndView addActionResult(HttpServletRequest request, ModelAndView modelAndView, ResultMap result,
                                           boolean i18n) {

        if (i18n) {
            logger.debug("localeRsolver" + localeResolver);
            ResultHelper.wrapMessage(result, localeResolver.resolveLocale(request));
        }

        return modelAndView.addObject(AppConstant.ACTION_RESULT_MODEL_VIEW_KEY, result);
    }

    protected ModelAndView view(HttpServletRequest request, String view) {

        return addActionResult(request, new ModelAndView(view), ResultMap.getSuccessResult(), false);
    }

    protected ModelAndView view(HttpServletRequest request, String view, ResultMap result) {

        return addActionResult(request, new ModelAndView(view), result, false);
    }

    protected ModelAndView result(HttpServletRequest request, String view, ResultMap result) {

        return addActionResult(request, new ModelAndView(view), result, true);
    }

    protected ModelAndView success(HttpServletRequest request, String view) {

        return addActionResult(request, new ModelAndView(view), ResultMap.getSuccessResult(), true);
    }
    protected ModelAndView  dim(HttpServletRequest request, String view) {

        return addActionResult(request, new ModelAndView(view), ResultMap.getDimResult(), true);
    }
    protected ModelAndView  dim(HttpServletRequest request) {

        return addActionResult(request, new ModelAndView("dim"), ResultMap.getDimResult(), true);
    }
    protected ModelAndView incorrect(HttpServletRequest request, BindingResult result,
                                                    String view) {
        // LocaleContextHolder.getLocale();
        return addFormatIncorrectResult(request,result,new ModelAndView(view));
    }
    protected ModelAndView addFormatIncorrectResult(HttpServletRequest request, BindingResult result,
                                                    ModelAndView modelAndView) {
        // LocaleContextHolder.getLocale();
        return modelAndView.addObject(AppConstant.ACTION_RESULT_MODEL_VIEW_KEY, formatIncorrectResult(request, result));
    }

    private ResultMap formatIncorrectResult(HttpServletRequest request, BindingResult result) {
        List<ObjectError> es = result.getAllErrors();
        List<Map<String, String>> validators = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (int i = 0, l = es.size(), t = l - 1; i < l; i++) {
            ObjectError e = es.get(i);
            Object[] args = e.getArguments();
            MessageSourceResolvable sr = (MessageSourceResolvable) args[0];
            String codes[] = sr.getCodes();
            Map<String, String> validator = new HashMap();
            String key = codes[codes.length - 1];
            if (key.endsWith("Time")) {
                key = key.replace("Time", "Date");
                codes[codes.length - 1] = key;
            }
            validator.put(key, e.getDefaultMessage());
            validators.add(validator);
            logger.trace(e.toString());
            sb.append(e.getDefaultMessage());
            if (i < t) {
                sb.append("\n");
            }
        }
        ResultMap rm = ResultMap.getResult(Result.FORMAT_INCORRECT);
        rm.put(ResultMap.VALIDATOR_KEY, validators);
        ResultHelper.wrapMessage(rm, localeResolver.resolveLocale(request));
        return rm;
    }

    protected ModelAndView formatIncorrect(HttpServletRequest request, BindingResult validResult, String view) {
        logger.warn("验证不通过");
        return addFormatIncorrectResult(request, validResult, new ModelAndView(view));
    }

    protected int pasePage(String page) {
        try {
            return Integer.parseInt(page);
        } catch (NumberFormatException e) {

        }
        return 1;
    }
}
