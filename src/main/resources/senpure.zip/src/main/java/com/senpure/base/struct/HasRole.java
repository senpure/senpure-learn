package com.senpure.base.struct;

import com.senpure.base.vo.RoleVo;

/**
 * Created by 罗中正 on 2017/5/23.
 */
public class HasRole extends RoleVo {
    private boolean has;

    public boolean isHas() {
        return has;
    }

    public void setHas(boolean has) {
        this.has = has;
    }
}
