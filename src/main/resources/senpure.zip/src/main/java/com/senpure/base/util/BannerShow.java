package com.senpure.base.util;


import com.senpure.AppContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ansi.AnsiColor;
import org.springframework.boot.ansi.AnsiOutput;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/4/28.
 */

public class BannerShow {
    private static Logger logger = LoggerFactory.getLogger(BannerShow.class);

    static String bannerTxt = " _______               _______    _______    _______    _______    _______\n" +
            "(  ____ \\  |\\     /|  (  ____ \\  (  ____ \\  (  ____ \\  (  ____ \\  (  ____ \\\n" +
            "| (    \\/  | )   ( |  | (    \\/  | (    \\/  | (    \\/  | (    \\/  | (    \\/\n" +
            "| (_____   | |   | |  | |        | |        | (__      | (_____   | (_____\n" +
            "(_____  )  | |   | |  | |        | |        |  __)     (_____  )  (_____  )\n" +
            "      ) |  | |   | |  | |        | |        | (              ) |        ) |\n" +
            "/\\____) |  | (___) |  | (____/\\  | (____/\\  | (____/\\  /\\____) |  /\\____) |\n" +
            "\\_______)  (_______)  (_______/  (_______/  (_______/  \\_______)  \\_______)";

    public static void show2() {

        AnsiOutput.setEnabled(AnsiOutput.Enabled.ALWAYS);
        StringBuilder banner = new StringBuilder();

        bannerTxt = AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_CYAN, bannerTxt});
        banner.append(bannerTxt);
        banner.append("\n");
        logger.debug("\n{}", banner);
    }

    public static void show() {
        // logger.debug(AppContext.getClassRootPath());
        try {
            //  File file= ResourceUtils.getFile("classpath:showbanner.txt");
            //Resource show = new ClassPathResource("showbanner.txt");
            InputStream inputStream = BannerShow.class.getClassLoader().getResourceAsStream("showbanner.txt");
            InputStreamReader reader = new InputStreamReader(
                    inputStream); // 建立一个输入流对象reader
            BufferedReader br = new BufferedReader(reader); // 建立一个对象，它把文件内容转成计算机能读懂的语言
            List<String> strs = new ArrayList<>();
            while (br.ready()) {
                String line = br.readLine(); // 一次读入一行数据
                strs.add(line);
            }
            br.close();
            int length = 0;
            for (int i = 0; i < strs.size(); i++) {

                int tl = strs.get(i).length();
                length = tl > length ? tl : length;
            }
            if (length % 2 != 0) {
                length++;
            }
            int realLength = length;

            if (AppContext.isWindowsOS()) {

            }
            length >>= 1;
            //  System.out.println("length=" + length);
            StringBuilder banner = new StringBuilder();

            //String top = "╔══════════════════════════════════════╗";
            String top = "";
            top = getStr("═", length);
            top = "╔" + top + "╗";
            top = AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_RED, top});
            banner.append(top);
            banner.append("\n");
            String empty;
            //empty = "║
            //
            if (AppContext.isWindowsOS()) {
                empty = getStr("  ", length);
            } else {
                empty = getStr(" ", length);
            }
            empty = getStr(" ", realLength);

            empty = "║" + empty + "║";
            empty = AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_RED, empty});
            // banner.append(empty);
            //  banner.append("\n");
            for (int i = 0; i < strs.size(); i++) {
                banner.append(AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_RED, "║"}));
                banner.append(AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_CYAN, strs.get(i)}));
                int l = strs.get(i).length();
                String temp = getStr(" ", realLength - l);
                banner.append(AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_RED, temp + "║"}));
                banner.append("\n");
            }
            banner.append(empty);
            banner.append("\n");
            String
                    //down = "╚══════════════════════════════════════╝";
                    down = getStr("═", length);
            down = "╚" + down + "╝";
            down = AnsiOutput.toString(new Object[]{AnsiColor.BRIGHT_RED, down});
            banner.append(down);
            banner.append("\n");
            logger.debug("\n\n{}", banner);

            //logger.debug(AppContext.getRootPath());
        } catch (IOException e) {
            logger.error("",e);
            show2();
        }


    }

    public static String getStr(String ch, int num) {

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < num; i++) {
            sb.append(ch);

        }
        return sb.toString();
    }

    public static void main(String[] args) {
        show();
        // System.out.println("═".length());
    }
}
