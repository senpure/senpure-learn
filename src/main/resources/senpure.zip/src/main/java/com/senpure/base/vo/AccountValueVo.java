package com.senpure.base.vo;

import java.io.Serializable;

public class AccountValueVo implements Serializable {
	private static final long serialVersionUID = 1495001167976L;


	private	Integer id;
	private	Integer accountId;
	private	String key;
	private	String value;
	private	String description;
	private	Integer version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public Integer getAccountId() {
		return accountId;
	}


	public	void setAccountId(Integer accountId) {
		this.accountId=accountId ;
	}

	public String getKey() {
		return key;
	}


	public	void setKey(String key) {
		this.key=key ;
	}

	public String getValue() {
		return value;
	}


	public	void setValue(String value) {
		this.value=value ;
	}

	public String getDescription() {
		return description;
	}


	public	void setDescription(String description) {
		this.description=description ;
	}

	public Integer getVersion() {
		return version;
	}


	public	void setVersion(Integer version) {
		this.version=version ;
	}

}