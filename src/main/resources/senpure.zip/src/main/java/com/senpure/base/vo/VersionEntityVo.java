package com.senpure.base.vo;

import java.io.Serializable;

public class VersionEntityVo implements Serializable {
	private static final long serialVersionUID = 1495001168497L;


	private	Integer id;
	private	int version;

	public Integer getId() {
		return id;
	}


	public	void setId(Integer id) {
		this.id=id ;
	}

	public int getVersion() {
		return version;
	}


	public	void setVersion(int version) {
		this.version=version ;
	}

}