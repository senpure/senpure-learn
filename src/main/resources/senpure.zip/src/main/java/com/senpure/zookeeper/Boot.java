package com.senpure.zookeeper;

import com.senpure.base.util.BannerShow;
import org.fusesource.jansi.AnsiConsole;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Boot {


    public static void main(String[] args) throws Exception {
        //开启控制台颜色日志
       // AnsiOutput.setEnabled(AnsiOutput.Enabled.ALWAYS);
        AnsiConsole.systemInstall();
        AnsiConsole.systemUninstall();
        SpringApplication.run(Boot.class, args);

        BannerShow.show();


    }
}
