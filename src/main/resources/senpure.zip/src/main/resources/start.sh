#!/usr/bin/env bash
nohup java -jar senpure.jar > /dev/null &
sh outToshell.sh