package com.senpure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by 罗中正 on 2017/6/26.
 */
public class TestSupport {
    protected Logger logger;

    public TestSupport() {
        logger = LoggerFactory.getLogger(getClass());
    }
}
