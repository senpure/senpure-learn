package com.senpure.base.calculate;

import com.senpure.TestSupport;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 罗中正 on 2017/6/26.
 */
public class ExpressionTreeTest extends TestSupport {

    @Test
    public void createTree() throws Exception {
        List<String> expressList=new ArrayList<>();
        List<ExpressionTree> trees =new ArrayList<>();
        expressList.add("1+2+3-5");
        expressList.add("1+2*3-5");
        expressList.add("1+2*(3.4-5)");
        expressList.add("1+2*(3+5*5)*7");


        for(String express:expressList)
        {
            ExpressionTree tree=ExpressionTree.build(express);
            trees.add(tree);
        }

        for (int i = 0; i < expressList.size(); i++) {
            logger.trace("----------------------------");
            logger.trace(expressList.get(i));
            logger.trace(trees.get(i).caluate()+"");
            logger.trace("\n{}",trees.get(i).treeStr(i%2==0));
            logger.trace("----------------------------");
        }
    }

    @Test
    public void re()
    {

        String str="aaaabbcc";

        System.out.println(str.replace("aa","j"));
        System.out.println(str.replaceAll("aa","1j"));
    }

}