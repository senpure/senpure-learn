package com.senpure.base.calculate;

import com.greenpineyu.fel.FelEngine;
import com.greenpineyu.fel.context.FelContext;
import com.senpure.TestSupport;
import org.junit.Test;

/**
 * Created by 罗中正 on 2017/6/26.
 */
public class FelTest extends TestSupport {

    private int count = 100000;

    @Test
    public void caulte() {
        FelEngine felEngine = FelEngine.instance;
        long now = System.currentTimeMillis();

        FelContext context = felEngine.getContext();
        context.set("a", 3);
        context.set("b", 5);
        context.set("c", 6);
        context.set("d", 12);


        for (int i = 0; i < 10; i++) {
            Object o = felEngine.eval("10+5--5" );
            logger.info(o.toString());
        }

        logger.info("fel  耗时 {}", (System.currentTimeMillis() - now));

    }

    @Test
    public void ex() {

        long now = System.currentTimeMillis();

        for (int i = 0; i < count; i++) {
            ExpressionTree.build("3*(5+6)+12" + i).caluate();
        }

        logger.info("express  耗时 {}", (System.currentTimeMillis() - now));
    }
}
