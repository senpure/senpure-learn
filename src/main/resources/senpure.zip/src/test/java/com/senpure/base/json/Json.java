package com.senpure.base.json;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

/**
 * Created by 罗中正 on 2017/5/12.
 */
public class Json {

    @Test
    public void testjson() {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("jkl.j", "value");
        jsonObject.put("lll.j", "value22");

        System.out.println(jsonObject.toJSONString());
        String str="123";
        System.out.println(StringUtils.rightPad(str,7)+"777");
        //StringUtils.
    }
}
