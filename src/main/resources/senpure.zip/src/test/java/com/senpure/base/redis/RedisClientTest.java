package com.senpure.base.redis;

import com.senpure.TestSupport;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by 罗中正 on 2017/7/4.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = com.senpure.base.redis.Boot.class)
public class RedisClientTest extends TestSupport{

    @Autowired
    private RedisClient client;
    @Test
    public void set() throws Exception {

        client.set("rediskey","redisvalu11e");

        client.get("key");
      // String str= client.get("rediskey");
    //logger.debug(str);

    }


}