package com.senpure.base.service;

import com.senpure.SpringBootTestSupport;
import com.senpure.base.vo.AccountVo;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by 罗中正 on 2017/5/4.
 */
public class AccountServiceTest extends SpringBootTestSupport {

    @Autowired
    private AccountService accountService;
    @Test
    public void createAccount() throws Exception {
        accountService.createAccount(new AccountVo(),1,1);
    }

}