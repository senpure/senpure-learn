package com.senpure.base.service;

import com.senpure.SpringBootTestSupport;
import com.senpure.base.criterion.AccountCriteria;
import com.senpure.base.criterion.ContainerCriteria;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by 罗中正 on 2017/5/15.
 */
public class AuthorizeServiceTest extends SpringBootTestSupport {


    @Autowired
    private AuthorizeService authorizeService;
    @Autowired
    private ResourceVerifyContainerService resourceVerifyContainerService;
    @Test
    public void loadAccount() throws Exception {
        AccountCriteria criteria = new AccountCriteria();
        resourceVerifyContainerService.check(1,criteria.getContainers());
        criteria.setParentId(1);
       // criteria.setContainerId(2);
        System.out.println(authorizeService.loadAccount(criteria));
    }

    @Test
    public void loadContainer() {
        ContainerCriteria criteria = new ContainerCriteria();
        criteria.setPageInt(2);
        criteria.setParentId(1);
        System.out.println(authorizeService.loadContainer(criteria));
        criteria.setPageInt(1);

        System.out.println(authorizeService.loadContainer(criteria));
    }

}