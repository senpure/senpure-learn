package com.senpure.base.util;

import org.junit.Test;

import java.io.File;

/**
 * Created by 罗中正 on 2017/5/11.
 */
public class CompressTest {

    @Test
    public void compressTest() {

        File source = new File("E:\\data\\compress\\Logger.java");

        File source2 = new File("E:\\data\\compress\\protoc.exe");
        File source3= new File("E:\\data\\compress\\msg");
        File target = new File("E:\\data\\compress\\compres78910.zip");
        File [] s=new File[3];
        int i=0;
        s[i++]=source;
        s[i++]=source3;
        s[i++]=source2;
        ZipUtil.compressZip(s, target);

    }
    @Test
    public void compressFilesTest() {

        File source = new File("E:\\data\\compress\\msg");
        File target = new File("E:\\data\\compress\\456.zip");
        ZipUtil.compressZip(source, target);

    }
    @Test
    public void decompressTest() {

        File source = new File("E:\\data\\compress\\compres78910.zip");
        File target = new File("E:\\data\\compress\\un");

        ZipUtil.decompressZip(source, target);

    }
    @Test
    public void compressAddTest() {

        File source = new File("E:\\data\\compress\\login.zip");
        File target = new File("E:\\data\\compress\\protoc.zip");
        File merger = new File("E:\\data\\compress\\merger.zip");
       // File target = new File("E:\\data\\compress\\protoc.exe");

        File [] s=new File[2];
        int i=0;
        s[i++]=source;
        s[i++]=target;

        ZipUtil.mergeZip(merger,s);

    }
    @Test
    public void compressAddzipTest() {
        //compressAddTest();
        File source = new File("E:\\data\\compress\\456.zip");
        File target = new File("E:\\data\\compress\\protoc.zip");

        File merger = new File("E:\\data\\compress\\merger.zip");
        ZipUtil.addzip2zip(source,merger);

    }
}