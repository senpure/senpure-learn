package com.senpure.base.util;

import com.senpure.base.result.ResultMap;
import org.junit.Test;

/**
 * Created by 罗中正 on 2017/5/16.
 */
public class ResultMapTest {
    @Test
    public void total()
    {

        ResultMap resultMap=ResultMap.getSuccessResult();
        Integer total=5;
        resultMap.put(ResultMap.TOTAL_KEY,total);
        System.out.println(resultMap.getTotal());
    }
}
