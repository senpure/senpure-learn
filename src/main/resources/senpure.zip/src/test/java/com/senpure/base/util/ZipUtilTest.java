package com.senpure.base.util;

import org.junit.Test;

import java.io.File;

/**
 * Created by 罗中正 on 2017/5/11.
 */
public class ZipUtilTest {
    @Test
    public void compressZip() throws Exception {
    }

    @Test
    public void compressZip1() throws Exception {
    }

    @Test
    public void decompressZip() throws Exception {
    }

    @Test
    public void mergeZip() throws Exception {

        File file2 = new File("E:\\data\\compress\\2.zip");
        File file3 = new File("E:\\data\\compress\\3.zip");
        File file4 = new File("E:\\data\\compress\\4.zip");
        File file = new File("E:\\data\\compress\\哈哈.zip");
        File[] files = new File[3];
        int i = 0;
        files[i++] = file2;
        files[i++] = file3;
        files[i++] = file4;
        ZipUtil.mergeZip(file, files);

    }

    @Test
    public void addzip2zip() throws Exception {
    }

    @Test
    public void add2zip() throws Exception {

        File file2 = new File("E:\\data\\compress\\2.zip");
        File file = new File("E:\\data\\compress\\2_4.zip");

        ZipUtil.add2zip(file2,file);
    }

}